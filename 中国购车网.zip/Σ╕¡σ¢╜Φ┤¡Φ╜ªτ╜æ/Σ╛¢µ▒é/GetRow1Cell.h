//
//  GetRow1Cell.h
//  中国购车网
//
//  Created by qianfeng on 13-3-20.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GetRow1Cell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *titlelable;
@property (retain, nonatomic) IBOutlet UILabel *dateLable;

@end
