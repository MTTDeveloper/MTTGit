//
//  StringItem.m
//  中国购车网
//
//  Created by qianfeng on 13-3-20.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "StringItem.h"

@implementation StringItem
@synthesize content,telContact,title,addTime,imageStr;
-(void)dealloc{
    self.content=nil;
    self.telContact=nil;
    self.title=nil;
    self.addTime=nil;
    self.imageStr=nil;
    [super dealloc];
}
@end
