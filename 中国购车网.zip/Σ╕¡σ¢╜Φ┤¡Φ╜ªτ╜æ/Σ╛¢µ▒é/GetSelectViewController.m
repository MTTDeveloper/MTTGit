//
//  GetSelectViewController.m
//  中国购车网
//
//  Created by qianfeng on 13-3-20.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "GetSelectViewController.h"
#import "HttpDownload.h"
#import "SBJson.h"
#import "GetRow1Cell.h"
#import "GetRow2imageCell.h"
#import "StringItem.h"
#import "UIImageView+WebCache.h"
#import "SearchViewController.h"
#import "PingLunViewController.h"

@implementation GetSelectViewController
@synthesize downloadId;
@synthesize changeCell;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)downloadComplete:(HttpDownload *)hd{
    NSString *str=[[NSString alloc]initWithData:hd.mData encoding:NSUTF8StringEncoding];
    str=[str substringFromIndex:1];
    str=[str substringToIndex:str.length-1];
    NSDictionary *dict=[str JSONValue];
    if (dict) {
        NSArray *itemArray=[dict objectForKey:@"items"];
        for (NSDictionary *subdict in itemArray) {
            StringItem *item=[[StringItem alloc]init];
            item.title=[subdict objectForKey:@"title"];
            item.addTime=[subdict objectForKey:@"addTime"];
            NSString *telcontact=[NSString stringWithFormat:@"联系人: %@ %@",[subdict objectForKey:@"contact"],[subdict objectForKey:@"tel"]];
            item.telContact=[NSString stringWithFormat:telcontact];
            NSString *con=[[NSString alloc]initWithFormat:[subdict objectForKey:@"content"]];
            con=[con substringToIndex:con.length-4];
            item.content=con;
            item.imageStr=[NSString stringWithFormat:@"http://app.caeac.cn/929d8f5835561f252553617ab8ac26d4//%@",[subdict objectForKey:@"thumbnail"]];
            [dataArray addObject:item];
            [item release];
        }
    }
    [self.view addSubview:myTableView];

}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */

-(void)backToTop{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIButton *leftButton=[UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame=CGRectMake(0, 0, 50, 30);
    [leftButton addTarget:self action:@selector(backToTop) forControlEvents:UIControlEventTouchUpInside];
    [leftButton setImage:[UIImage imageNamed:@"head_03.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *lefBarButton=[[UIBarButtonItem alloc]initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem=lefBarButton;
    [lefBarButton release];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    
    dataArray=[[NSMutableArray alloc]init];
    NSString *urlTopStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexbuy.php?w=90&d=%@",downloadId];
    NSURL *urlTop=[NSURL URLWithString:urlTopStr];
    HttpDownload *httpdownload=[[HttpDownload alloc]init];
    httpdownload.delegate=self;
    [httpdownload downloadFormUrlWithAsi:urlTop];
    if (changeCell==YES) {
        myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-44) style:UITableViewStylePlain];
    }else{
        myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-44) style:UITableViewStylePlain];
    }
    myTableView.dataSource=self;
    myTableView.delegate=self;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 4;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        return 75;
    }else if(indexPath.row==1){
        if (changeCell==YES) {
            return 150;
        }else{
            return 70;
        }
    }else if(indexPath.row==2){
        return 44;
    }else{
        return 44;
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    StringItem *item=[dataArray objectAtIndex:0];
    if (indexPath.row==0) {
        GetRow1Cell *cell=[tableView dequeueReusableCellWithIdentifier:@"GetRow1Cell"];
        if (cell==nil) {
            cell=[[[NSBundle mainBundle]loadNibNamed:@"GetRow1Cell" owner:nil options:nil]lastObject];
        }
        
        cell.titlelable.text=item.title;
        cell.titlelable.textAlignment=UITextAlignmentCenter;
        cell.dateLable.text=item.addTime;
        cell.dateLable.textAlignment=UITextAlignmentRight;
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        return cell;
    }else if(indexPath.row==1){
        if (changeCell==YES) {
            GetRow2imageCell *cell=[tableView dequeueReusableCellWithIdentifier:@"GetRow2imageCell"];
            if (cell==nil) {
                cell=[[[NSBundle mainBundle]loadNibNamed:@"GetRow2imageCell" owner:nil options:nil]lastObject];
            }
            [cell.imageCell setImageWithURL:[NSURL URLWithString:item.imageStr]];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            return cell;
        }else{
            UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
            if (cell==nil) {
                cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
            }
            cell.textLabel.text=item.content;
            cell.textLabel.numberOfLines=0;
            cell.textLabel.font=[UIFont boldSystemFontOfSize:17];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            return cell;
        }
    }else{
        UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        }
        if (indexPath.row==2) {
            cell.textLabel.text=item.telContact;
            cell.textLabel.font=[UIFont boldSystemFontOfSize:17];
        }else{
            cell.textLabel.text=@"发表评论";
            cell.textLabel.font=[UIFont boldSystemFontOfSize:17];
        }
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        return cell;
    }

}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==3) {
        PingLunViewController *pvc=[[PingLunViewController alloc]initWithNibName:@"PingLunViewController" bundle:nil];
        [self.navigationController pushViewController:pvc animated:YES];
        [pvc release];

    }
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)dealloc{
    self.downloadId=nil;
    [super dealloc];
}

@end
