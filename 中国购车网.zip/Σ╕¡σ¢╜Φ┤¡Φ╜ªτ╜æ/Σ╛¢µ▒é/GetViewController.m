//
//  GetViewController.m
//  中国购车网
//
//  Created by qianfeng on 13-3-8.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "GetViewController.h"
#import "UIImage+UIImageExtras.h"
#import "HttpDownload.h"
#import "SBJson.h"
#import "ButtonCell.h"
#import "ButtonItem.h"
#import "LoginViewController.h"
#import "GetSelectViewController.h"
#import "SearchViewController.h"

@implementation GetViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        UIImage *tabimage=[UIImage imageNamed:@"h4.png"];
        UIImage *tabUnimage=[UIImage imageNamed:@"k4.png"];
        CGSize size=CGSizeMake(30, 30);
        self.tabBarItem =[[UITabBarItem alloc]initWithTitle:@"供求" image:[tabimage imageByScalingToSize:size] tag:4];
        [self.tabBarItem setFinishedSelectedImage:[tabUnimage imageByScalingToSize:size] withFinishedUnselectedImage:[tabimage imageByScalingToSize:size]];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)pressButton:(UIButton *)sender{
    if (sender.tag==0) {
        if (isTop==NO) {
            NSString *urlTopStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexbuy.php?w=90&p=0&n=15&t=4"];
            NSURL *urlTop=[NSURL URLWithString:urlTopStr];
            HttpDownload *httpdownload=[[HttpDownload alloc]init];
            httpdownload.delegate=self;
            isTop=YES;
            [httpdownload downloadFormUrlWithAsi:urlTop];
        }
    }else if(sender.tag==1){
        if (isTop==YES) {
            NSString *urlTopStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexbuy.php?w=90&p=0&n=15&t=5"];
            NSURL *urlTop=[NSURL URLWithString:urlTopStr];
            HttpDownload *httpdownload=[[HttpDownload alloc]init];
            httpdownload.delegate=self;
            isTop=NO;
            [httpdownload downloadFormUrlWithAsi:urlTop];
        }
    }else{
        isTop=NO;
        LoginViewController *Lvc=[[LoginViewController alloc]init];
        [self.navigationController pushViewController:Lvc animated:YES];
        [Lvc release];
    }
}


-(void)downloadComplete:(HttpDownload *)hd{
    [getDataArray removeAllObjects];
    NSString *str=[[NSString alloc]initWithData:hd.mData encoding:NSUTF8StringEncoding];
    str=[str substringFromIndex:1];
    str=[str substringToIndex:str.length-1];
    NSDictionary *dict=[str JSONValue];
    if (dict) {
        NSArray *itemArray=[dict objectForKey:@"items"];
        for (NSDictionary *subdict in itemArray) {
            ButtonItem *item=[[ButtonItem alloc]init];
            item.telItem=[NSString stringWithFormat:@"%@ %@",[subdict objectForKey:@"contact"],[subdict objectForKey:@"tel"]];
            item.titleItem=[subdict objectForKey:@"title"];
            item.IdItem=[subdict objectForKey:@"id"];
            [getDataArray addObject:item];
        }
    }
    [myTableView reloadData];
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */
-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    getDataArray=[[NSMutableArray alloc]init];
    UIImage *navimage=[UIImage imageNamed:@"bg_top.jpg"];
    CGSize imagesize=CGSizeMake(320, 44);
    [self.navigationController.navigationBar setBackgroundImage:[navimage imageByScalingToSize:imagesize] forBarMetrics:UIBarMetricsDefault];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    
    UIView *buttonView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    [self.view addSubview:buttonView];
    NSArray *nameArray=[[NSArray alloc]initWithObjects:@"最新供求",@"最新求购",@"发布供求", nil];
    for (int i=0; i<3; i++) {
        UIButton *oneButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        oneButton.frame=CGRectMake(0+320/3*i, 0, 320/3, 44);
        [oneButton setTitle:[nameArray objectAtIndex:i] forState:UIControlStateNormal];
        oneButton.tag=i;
        //[oneButton setBackgroundImage:[UIImage imageNamed:@"img_bg_1,jpg"] forState:UIControlStateNormal];
        [oneButton addTarget:self action:@selector(pressButton:) forControlEvents:UIControlEventTouchUpInside];
        [buttonView addSubview:oneButton];
    }
    
    NSString *urlTopStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexbuy.php?w=90&p=0&n=15&t=4"];
    NSURL *urlTop=[NSURL URLWithString:urlTopStr];
    HttpDownload *httpdownload=[[HttpDownload alloc]init];
    httpdownload.delegate=self;
    isTop=YES;
    [httpdownload downloadFormUrlWithAsi:urlTop];

    myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 44, 320, 416-88) style:UITableViewStylePlain];
    myTableView.dataSource=self;
    myTableView.delegate=self;
    [self.view addSubview:myTableView];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return getDataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 65;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ButtonCell *cell=[tableView dequeueReusableCellWithIdentifier:@"ButtonCell"];
    if (cell==nil) {
        cell=[[[NSBundle mainBundle]loadNibNamed:@"ButtonCell" owner:nil options:nil]lastObject];
    }
    ButtonItem *item=[getDataArray objectAtIndex:indexPath.row];
    cell.titleCell.text=item.titleItem;
    cell.telCell.text=item.telItem;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    GetSelectViewController *gtvc=[[GetSelectViewController alloc]init];
    gtvc.changeCell=isTop;
    ButtonItem *item=[getDataArray objectAtIndex:indexPath.row];
    gtvc.downloadId=item.IdItem;
    [self.navigationController pushViewController:gtvc animated:YES];
    [gtvc release];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
