//
//  ButtonItem.m
//  中国购车网
//
//  Created by qianfeng on 13-3-20.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "ButtonItem.h"

@implementation ButtonItem
@synthesize telItem,titleItem,IdItem;
-(void)dealloc{
    self.titleItem=nil;
    self.telItem=nil;
    self.IdItem=nil;
    [super dealloc];
}
@end
