//
//  GetViewController.h
//  中国购车网
//
//  Created by qianfeng on 13-3-8.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface GetViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,HttpDownloadDelegate>
{
    NSMutableArray *getDataArray;
    UITableView *myTableView;
    BOOL isTop;
}
@end
