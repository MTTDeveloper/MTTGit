//
//  GetRow2imageCell.h
//  中国购车网
//
//  Created by qianfeng on 13-3-20.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GetRow2imageCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UIImageView *imageCell;

@end
