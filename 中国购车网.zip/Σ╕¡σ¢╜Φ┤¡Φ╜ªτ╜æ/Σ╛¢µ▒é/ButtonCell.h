//
//  ButtonCell.h
//  中国购车网
//
//  Created by qianfeng on 13-3-20.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ButtonCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *titleCell;
@property (retain, nonatomic) IBOutlet UILabel *telCell;

@end
