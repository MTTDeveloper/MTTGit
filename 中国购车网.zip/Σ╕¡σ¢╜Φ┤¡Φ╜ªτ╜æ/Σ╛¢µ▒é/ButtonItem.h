//
//  ButtonItem.h
//  中国购车网
//
//  Created by qianfeng on 13-3-20.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ButtonItem : NSObject
@property (nonatomic,retain)NSString *titleItem;
@property (nonatomic,retain)NSString *telItem;
@property (nonatomic,retain)NSString *IdItem;
@end
