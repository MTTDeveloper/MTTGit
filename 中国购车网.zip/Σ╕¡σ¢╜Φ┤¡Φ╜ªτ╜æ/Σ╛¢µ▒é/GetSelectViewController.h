//
//  GetSelectViewController.h
//  中国购车网
//
//  Created by qianfeng on 13-3-20.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface GetSelectViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,HttpDownloadDelegate>
{
    UITableView *myTableView;
    NSMutableArray *dataArray;
}
@property (nonatomic,retain)NSString *downloadId;
@property (nonatomic,assign)BOOL changeCell;
@end
