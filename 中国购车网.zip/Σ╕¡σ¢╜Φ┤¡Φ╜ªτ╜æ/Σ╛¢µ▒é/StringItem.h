//
//  StringItem.h
//  中国购车网
//
//  Created by qianfeng on 13-3-20.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StringItem : NSObject
@property (nonatomic,retain)NSString *title;
@property (nonatomic,retain)NSString *imageStr;
@property (nonatomic,retain)NSString *telContact;
@property (nonatomic,retain)NSString *addTime;
@property (nonatomic,retain)NSString *content;
@end
