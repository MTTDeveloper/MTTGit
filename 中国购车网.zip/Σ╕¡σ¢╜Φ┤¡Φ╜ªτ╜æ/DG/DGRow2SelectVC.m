//
//  DGRow2SelectVC.m
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "DGRow2SelectVC.h"
#import "HttpDownload.h"
#import "SBJson.h"
#import "SearchViewController.h"

@implementation DGRow2SelectVC
@synthesize DGRow2SelectId,DGRow2SelectDate,DGRow2SelectTitle,DGRow2SelectMessage;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)downloadComplete:(HttpDownload *)hd{
    NSString *str=[[NSString alloc]initWithData:hd.mData encoding:NSUTF8StringEncoding];
    str=[str substringFromIndex:1];
    str=[str substringToIndex:str.length-1];
    NSDictionary *dict=[str JSONValue];
    if (dict) {
        NSArray *itemArray=[dict objectForKey:@"items"];
        for (NSDictionary *subdict in itemArray) {
            self.DGRow2SelectTitle=[subdict objectForKey:@"title"];
            self.DGRow2SelectDate=[subdict objectForKey:@"addTime"];
            
            self.DGRow2SelectMessage=[subdict objectForKey:@"content"];
        }
        if (self.DGRow2SelectMessage) {
            myTableView.frame=CGRectMake(0, 0, 320, 130);
        }else{
            myTableView.frame=CGRectMake(0, 0, 320, 416-44);
        }
        [self.view addSubview:myTableView];
    }
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */

-(void)backToTop{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIButton *leftButton=[UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame=CGRectMake(0, 0, 50, 30);
    [leftButton addTarget:self action:@selector(backToTop) forControlEvents:UIControlEventTouchUpInside];
    [leftButton setImage:[UIImage imageNamed:@"head_03.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *lefBarButton=[[UIBarButtonItem alloc]initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem=lefBarButton;
    [lefBarButton release];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    NSString *DGselecturlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexarticlec.php?w=90&d=%@&n=5&p=0&t=1",DGRow2SelectId];
    NSURL *DGselectUrl=[NSURL URLWithString:DGselecturlStr];
    HttpDownload *DGselectDownload=[[HttpDownload alloc]init];
    DGselectDownload.delegate=self;
    [DGselectDownload downloadFormUrlWithAsi:DGselectUrl];
    
    myTableView=[[UITableView alloc]init];
    myTableView.dataSource=self;
    myTableView.delegate=self;

}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        return 60;
    }
    else if(indexPath.row==1){
        if (self.DGRow2SelectMessage) {
            return 30;
        }else{
            return 270;
        }
    }else{
        return 40;
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 3;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row!=2) {
        [tableView deselectRowAtIndexPath:indexPath animated:NO];
    }else{
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        UITableViewCell*cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        UILabel *titleLable=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 320, 35)];
        titleLable.textAlignment=UITextAlignmentCenter;
        if (self.DGRow2SelectTitle) {
            titleLable.text=@"null";
        }
        titleLable.font=[UIFont boldSystemFontOfSize:18];
        UILabel *timeLable=[[UILabel alloc]initWithFrame:CGRectMake(0, 35, 320, 25)];
        timeLable.textAlignment=UITextAlignmentCenter;
        timeLable.text=[NSString stringWithFormat:self.DGRow2SelectDate];
        timeLable.font=[UIFont boldSystemFontOfSize:14];
        timeLable.textColor=[UIColor grayColor];
        
        [cell addSubview:titleLable];
        [cell addSubview:timeLable];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        return cell;
    }else if(indexPath.row==1){
        UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"];
        if (self.DGRow2SelectMessage) {
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            return cell;
        }else{
            view=[[UIWebView alloc]initWithFrame:CGRectMake(0, 0, 320, 270)];
            view.delegate=self;
            NSString *urlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexarticlec.php?w=90&d=%d&n=5&p=0&t=1",DGRow2SelectId];
            NSURL *url=[NSURL URLWithString:urlStr];
            [view loadHTMLString:self.DGRow2SelectMessage baseURL:url];
            [(UIScrollView *)[[view subviews] objectAtIndex:0] setBounces:NO];
            [cell.contentView addSubview:view];
            [view release];
            cell.selectionStyle=UITableViewCellSelectionStyleNone;
            return cell;
        }
       
    }else{
        UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"DB"];
        cell.textLabel.text=@"发表评论";
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        return cell;
    }
}



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)dealloc{
    self.DGRow2SelectId=nil;
    self.DGRow2SelectDate=nil;
    self.DGRow2SelectMessage=nil;
    self.DGRow2SelectTitle=nil;
    [super dealloc];
}

@end
