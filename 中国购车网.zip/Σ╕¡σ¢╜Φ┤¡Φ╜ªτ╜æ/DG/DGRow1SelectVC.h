//
//  DGRow1SelectVC.h
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface DGRow1SelectVC : UIViewController<UITableViewDataSource,UITableViewDelegate,HttpDownloadDelegate,UIWebViewDelegate>
{
    UITableView *myTableView;
    UIWebView *view;
}
@property (nonatomic,retain)NSString *DGRow1SelectId;
@property (nonatomic,retain)NSString *DGRow1SelectTitle;
@property (nonatomic,retain)NSString *DGRow1SelectDate;
@property (nonatomic,retain)NSString *DGRow1SelectMessage;
@end
