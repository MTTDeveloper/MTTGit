//
//  DGRow2ViewItem.h
//  中国购车网
//
//  Created by qianfeng on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DGRow2ViewItem : NSObject
@property (nonatomic,retain)NSString *Dgrow2Image;
@property (nonatomic,retain)NSString *Dgrow2Titletext;
@property (nonatomic,retain)NSString *Dgrow2Messagetext;
@property (nonatomic,retain)NSString *Dgrow2Id;
@end
