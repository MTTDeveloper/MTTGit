//
//  DGFirstViewCell.m
//  中国购车网
//
//  Created by qianfeng on 13-3-11.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "DGFirstViewCell.h"

@implementation DGFirstViewCell
@synthesize DGFirstCellImage;
@synthesize DGFirstCellLable;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [DGFirstCellImage release];
    [DGFirstCellLable release];
    [super dealloc];
}
@end
