//
//  DGSecondRow1VC.m
//  中国购车网
//
//  Created by qianfeng on 13-3-11.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "DGSecondRow1VC.h"
#import "HttpDownload.h"
#import "SBJson.h"
#import "DGRow1ViewCell.h"
#import "DGRow1ViewItem.h"
#import "UIImageView+WebCache.h"
#import "DGRow1SelectVC.h"
#import "SearchViewController.h"

@implementation DGSecondRow1VC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)downloadComplete:(HttpDownload *)hd{
    NSString *str=[[NSString alloc]initWithData:hd.mData encoding:NSUTF8StringEncoding];
    str=[str substringFromIndex:1];
    str=[str substringToIndex:str.length-1];
    NSDictionary *dictRow1=[str JSONValue];
    if (dictRow1) {
        NSArray *itemArray=[dictRow1 objectForKey:@"items"];
        for (NSDictionary *subdict in itemArray) {
            DGRow1ViewItem *item=[[DGRow1ViewItem alloc]init];
            item.Dgrow1Titletext=[subdict objectForKey:@"title"];
            item.Dgrow1Messagetext=[subdict objectForKey:@"digest"];
            item.Dgrow1Image=[subdict objectForKey:@"thumbnail"];
            item.Dgrow1Id=[subdict objectForKey:@"id"];
            [DGRow1DataArray addObject:item];
            [item release];
        }
        [myTableView reloadData];
    }
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return DGRow1DataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 85;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    DGRow1ViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell==nil) {
        cell=[[[NSBundle mainBundle]loadNibNamed:@"DGRow1ViewCell" owner:nil options:nil]lastObject];
    }
    DGRow1ViewItem *item=[DGRow1DataArray objectAtIndex:indexPath.row];
    cell.dgRow1Titlelable.text=item.Dgrow1Titletext;
    cell.dgRow1MessageLable.text=item.Dgrow1Messagetext;
    cell.dgRow1MessageLable.numberOfLines=0;
    [cell.dgRow1image setImageWithURL:[NSURL URLWithString:item.Dgrow1Image]];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    DGRow1SelectVC *dgrsvc=[[DGRow1SelectVC alloc]init];
    DGRow1ViewItem *item=[DGRow1DataArray objectAtIndex:indexPath.row];
    dgrsvc.DGRow1SelectId=item.Dgrow1Id;
    [self.navigationController pushViewController:dgrsvc animated:YES];
    [dgrsvc release];
}

-(void)backToTop{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIButton *leftButton=[UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame=CGRectMake(0, 0, 50, 30);
    [leftButton addTarget:self action:@selector(backToTop) forControlEvents:UIControlEventTouchUpInside];
    [leftButton setImage:[UIImage imageNamed:@"head_03.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *lefBarButton=[[UIBarButtonItem alloc]initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem=lefBarButton;
    [lefBarButton release];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    
    DGRow1DataArray=[[NSMutableArray alloc]init];
    NSString *dgRow1urlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexindexdt.php?w=90&p=0&n=15&t=11"];
    NSURL *row1Url=[NSURL URLWithString:dgRow1urlStr];
    HttpDownload *dgRow1Download=[[HttpDownload alloc]init];
    dgRow1Download.delegate=self;
    [dgRow1Download downloadFormUrlWithAsi:row1Url];
    
    myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-44) style:UITableViewStylePlain];
    myTableView.delegate=self;
    myTableView.dataSource=self;
    [self.view addSubview:myTableView];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
