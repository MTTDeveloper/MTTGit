//
//  DGRow2ViewItem.m
//  中国购车网
//
//  Created by qianfeng on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "DGRow2ViewItem.h"

@implementation DGRow2ViewItem
@synthesize Dgrow2Image,Dgrow2Titletext,Dgrow2Messagetext,Dgrow2Id;

-(void)dealloc{
    self.Dgrow2Image=nil;
    self.Dgrow2Titletext=nil;
    self.Dgrow2Messagetext=nil;
    self.Dgrow2Id=nil;
    [super dealloc];
}
@end
