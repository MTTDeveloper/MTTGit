//
//  DGViewController.m
//  中国购车网
//
//  Created by qianfeng on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "DGViewController.h"
#import "DGSecondRow1VC.h"
#import "DGSecondRow2VC.h"
#import "DGFirstViewCell.h"
#import "SearchViewController.h"

@implementation DGViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */

-(void)backToTop{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIButton *leftButton=[UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame=CGRectMake(0, 0, 50, 30);
    [leftButton addTarget:self action:@selector(backToTop) forControlEvents:UIControlEventTouchUpInside];
    [leftButton setImage:[UIImage imageNamed:@"head_03.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *lefBarButton=[[UIBarButtonItem alloc]initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem=lefBarButton;
    [lefBarButton release];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    
    UITableView *myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 100) style:UITableViewStylePlain];
    myTableView.dataSource=self;
    myTableView.delegate=self;
    [self.view addSubview:myTableView];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 2;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    DGFirstViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell==nil) {
        cell=[[[NSBundle mainBundle]loadNibNamed:@"DGFirstViewCell" owner:nil options:nil]lastObject];
    }
    if (indexPath.row==0) {
        cell.DGFirstCellLable.text=@"初步海选";
        //[cell.DGFirstCellImage setImage:[UIImage imageNamed:@""]];
    }else{
        cell.DGFirstCellLable.text=@"购物手册";
        //[cell.DGFirstCellImage setImage:[UIImage imageNamed:@""]];
    }
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath  animated:YES];
    if (indexPath.row==0) {
        DGSecondRow1VC *dsr1=[[DGSecondRow1VC alloc]init];
        [self.navigationController pushViewController:dsr1 animated:YES];
    }else{
        DGSecondRow2VC *dsr2=[[DGSecondRow2VC alloc]init];
        [self.navigationController pushViewController:dsr2 animated:YES];
    }
}



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
