//
//  DGRow1ViewItem.h
//  中国购车网
//
//  Created by qianfeng on 13-3-11.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DGRow1ViewItem : NSObject
@property (nonatomic,retain)NSString *Dgrow1Image;
@property (nonatomic,retain)NSString *Dgrow1Titletext;
@property (nonatomic,retain)NSString *Dgrow1Messagetext;
@property (nonatomic,retain)NSString *Dgrow1Id;
@end
