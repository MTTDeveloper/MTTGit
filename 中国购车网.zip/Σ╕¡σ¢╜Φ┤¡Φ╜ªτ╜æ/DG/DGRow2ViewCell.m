//
//  DGRow2ViewCell.m
//  中国购车网
//
//  Created by qianfeng on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "DGRow2ViewCell.h"

@implementation DGRow2ViewCell
@synthesize dgRow2imge;
@synthesize dgRow2Titlelable;
@synthesize dgRow2Messagelable;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [dgRow2imge release];
    [dgRow2Titlelable release];
    [dgRow2Messagelable release];
    [super dealloc];
}
@end
