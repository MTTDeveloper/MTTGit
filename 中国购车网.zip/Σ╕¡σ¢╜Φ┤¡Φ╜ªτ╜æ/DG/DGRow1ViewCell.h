//
//  DGRow1ViewCell.h
//  中国购车网
//
//  Created by qianfeng on 13-3-11.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DGRow1ViewCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UIImageView *dgRow1image;
@property (retain, nonatomic) IBOutlet UILabel *dgRow1Titlelable;
@property (retain, nonatomic) IBOutlet UILabel *dgRow1MessageLable;

@end
