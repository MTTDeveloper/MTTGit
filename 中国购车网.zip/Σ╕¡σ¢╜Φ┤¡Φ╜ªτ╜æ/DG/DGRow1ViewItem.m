//
//  DGRow1ViewItem.m
//  中国购车网
//
//  Created by qianfeng on 13-3-11.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "DGRow1ViewItem.h"

@implementation DGRow1ViewItem
@synthesize Dgrow1Image,Dgrow1Titletext,Dgrow1Messagetext,Dgrow1Id;

-(void)dealloc{
    self.Dgrow1Image=nil;
    self.Dgrow1Titletext=nil;
    self.Dgrow1Messagetext=nil;
    self.Dgrow1Id=nil;
    [super dealloc];
}
@end
