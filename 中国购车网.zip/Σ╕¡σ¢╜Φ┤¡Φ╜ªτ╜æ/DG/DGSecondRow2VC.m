//
//  DGSecondRow2VC.m
//  中国购车网
//
//  Created by qianfeng on 13-3-11.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "DGSecondRow2VC.h"
#import "HttpDownload.h"
#import "SBJson.h"
#import "DGRow2ViewCell.h"
#import "DGRow2ViewItem.h"
#import "UIImageView+WebCache.h"
#import "DGRow2SelectVC.h"
#import "SearchViewController.h"

@implementation DGSecondRow2VC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)downloadComplete:(HttpDownload *)hd{
    NSString *str=[[NSString alloc]initWithData:hd.mData encoding:NSUTF8StringEncoding];
    str=[str substringFromIndex:1];
    str=[str substringToIndex:str.length-1];
    NSDictionary *dictRow1=[str JSONValue];
    if (dictRow1) {
        NSArray *itemArray=[dictRow1 objectForKey:@"items"];
        for (NSDictionary *subdict in itemArray) {
            DGRow2ViewItem *item=[[DGRow2ViewItem alloc]init];
            item.Dgrow2Titletext=[subdict objectForKey:@"title"];
            item.Dgrow2Messagetext=[subdict objectForKey:@"digest"];
            item.Dgrow2Image=[subdict objectForKey:@"thumbnail"];
            item.Dgrow2Id=[subdict objectForKey:@"id"];
            [DGRow2DataArray addObject:item];
            [item release];
        }
        [myTableView reloadData];
    }
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return DGRow2DataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 85;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    DGRow2ViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell==nil) {
        cell=[[[NSBundle mainBundle]loadNibNamed:@"DGRow2ViewCell" owner:nil options:nil]lastObject];
    }
    DGRow2ViewItem *item=[DGRow2DataArray objectAtIndex:indexPath.row];
    cell.dgRow2Titlelable.text=item.Dgrow2Titletext;
    cell.dgRow2Messagelable.text=item.Dgrow2Messagetext;
    cell.dgRow2Messagelable.numberOfLines=0;
    [cell.dgRow2imge setImageWithURL:[NSURL URLWithString:item.Dgrow2Image]];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    DGRow2SelectVC *dgrsvc=[[DGRow2SelectVC alloc]init];
    DGRow2ViewItem *item=[DGRow2DataArray objectAtIndex:indexPath.row];
    dgrsvc.DGRow2SelectId=item.Dgrow2Id;
    [self.navigationController pushViewController:dgrsvc animated:YES];
    [dgrsvc release];
}

-(void)backToTop{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIButton *leftButton=[UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame=CGRectMake(0, 0, 50, 30);
    [leftButton addTarget:self action:@selector(backToTop) forControlEvents:UIControlEventTouchUpInside];
    [leftButton setImage:[UIImage imageNamed:@"head_03.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *lefBarButton=[[UIBarButtonItem alloc]initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem=lefBarButton;
    [lefBarButton release];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    DGRow2DataArray=[[NSMutableArray alloc]init];
    NSString *dgRow2urlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexindexdt.php?w=90&p=0&n=15&t=15"];
    NSURL *row2Url=[NSURL URLWithString:dgRow2urlStr];
    HttpDownload *dgRow2Download=[[HttpDownload alloc]init];
    dgRow2Download.delegate=self;
    [dgRow2Download downloadFormUrlWithAsi:row2Url];
    
    myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-44) style:UITableViewStylePlain];
    myTableView.delegate=self;
    myTableView.dataSource=self;
    [self.view addSubview:myTableView];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
