//
//  DGRow2SelectVC.h
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface DGRow2SelectVC : UIViewController<UITableViewDataSource,UITableViewDelegate,HttpDownloadDelegate,UIWebViewDelegate>
{
    UITableView *myTableView;
    UIWebView *view;
}
@property (nonatomic,retain)NSString *DGRow2SelectId;
@property (nonatomic,retain)NSString *DGRow2SelectTitle;
@property (nonatomic,retain)NSString *DGRow2SelectDate;
@property (nonatomic,retain)NSString *DGRow2SelectMessage;
@end
