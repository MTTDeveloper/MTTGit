//
//  DGFirstViewCell.h
//  中国购车网
//
//  Created by qianfeng on 13-3-11.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DGFirstViewCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UIImageView *DGFirstCellImage;
@property (retain, nonatomic) IBOutlet UILabel *DGFirstCellLable;

@end
