//
//  DGSecondRow2VC.h
//  中国购车网
//
//  Created by qianfeng on 13-3-11.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface DGSecondRow2VC : UIViewController<UITableViewDataSource,UITableViewDelegate,HttpDownloadDelegate>
{
    NSMutableArray *DGRow2DataArray;
    UITableView *myTableView;
}
@end
