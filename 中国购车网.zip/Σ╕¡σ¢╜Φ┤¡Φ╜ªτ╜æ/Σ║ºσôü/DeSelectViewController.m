//
//  DeSelectViewController.m
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "DeSelectViewController.h"
#import "HttpDownload.h"
#import "SBJson.h"
#import "DeSelectViewCell.h"
#import "DeSelectViewItem.h"
#import "UIImageView+WebCache.h"
#import "DeselectSegment4Cell.h"
#import "DeselectSegment4Item.h"
#import "TableViewSelect.h"
#import "SearchViewController.h"
#import "DeselectSegment5Item.h"
#import "Deselectsegment5Cell.h"

@implementation DeSelectViewController
@synthesize keyMuArray;
@synthesize numberOfSelect,numberOfSegment;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)downloadComplete:(HttpDownload *)hd{
    
    NSString *str=[[NSString alloc]initWithData:hd.mData encoding:NSUTF8StringEncoding];
    str=[str substringFromIndex:1];
    str=[str substringToIndex:str.length-1];
    NSDictionary *dict=[str JSONValue];
    if (dict) {
        NSArray *itemArray=[dict objectForKey:@"items"];
        for (NSDictionary *subdict in itemArray) {
            if (numberOfSegment==0) {
                for (NSString *str in keyMuArray) {
                    NSRange range=[[subdict objectForKey:@"title"] rangeOfString:str];
                    DeSelectViewItem *item=[[DeSelectViewItem alloc]init];
                    if (range.location!=NSNotFound) {
                        item.DeSelectId=[subdict objectForKey:@"id"];
                        item.DeSelectTitleText=[subdict objectForKey:@"title"];
                        item.DeSelectMessageText=[subdict objectForKey:@""];
                        item.DeSelectImage=[subdict objectForKey:@"thumbnail"];
                        [dataItemArray addObject:item];
                    }else if (numberOfSelect==0&&numberOfSegment==0) {
                        if ([[subdict objectForKey:@"title"] isEqualToString:@"1"]) {
                            item.DeSelectId=[subdict objectForKey:@"id"];
                            item.DeSelectTitleText=[subdict objectForKey:@"title"];
                            item.DeSelectMessageText=[subdict objectForKey:@""];
                            item.DeSelectImage=[subdict objectForKey:@"thumbnail"];
                            [dataItemArray addObject:item];
                        }
                    }
                    
                }
            }else if(numberOfSegment==1){
                DeSelectViewItem *item=[[DeSelectViewItem alloc]init];
                item.DeSelectId=[subdict objectForKey:@"id"];
                item.DeSelectTitleText=[subdict objectForKey:@"title"];
                item.DeSelectMessageText=[subdict objectForKey:@""];
                item.DeSelectImage=[subdict objectForKey:@"thumbnail"];
                [dataItemArray addObject:item];
            }
            else if(numberOfSegment==4){
                DeselectSegment4Item *item=[[DeselectSegment4Item alloc]init];
                item.DeSelectId=[subdict objectForKey:@"id"];
                item.DeSelectImage=[subdict objectForKey:@"thumbnail"];
                item.DeSelectAddress=[subdict objectForKey:@"address"];
                item.DeSelectTel=[subdict objectForKey:@"tel"];
                item.DeSelectMobile=[subdict objectForKey:@"mobile"];
                item.DeSelectTitleText=[subdict objectForKey:@"company"];
                [dataItemArray addObject:item];
            }else if(numberOfSegment==5){
                DeselectSegment5Item *item=[[DeselectSegment5Item alloc]init];
                item.imageItem=[subdict objectForKey:@"thumbnail"];
                item.addressItem=[subdict objectForKey:@"address"];
                item.telItem=[subdict objectForKey:@"tel"];
                item.companyItem=[subdict objectForKey:@"company"];
                [dataItemArray addObject:item];
            }
            
        }
        [myTableView reloadData];
    }
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */

-(void)backToTop{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIButton *leftButton=[UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame=CGRectMake(0, 0, 50, 30);
    [leftButton addTarget:self action:@selector(backToTop) forControlEvents:UIControlEventTouchUpInside];
    [leftButton setImage:[UIImage imageNamed:@"head_03.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *lefBarButton=[[UIBarButtonItem alloc]initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem=lefBarButton;
    [lefBarButton release];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    
    dataItemArray=[[NSMutableArray alloc]init];
    keyMuArray=[[NSMutableArray alloc]init];
    if (numberOfSegment==0) {
        for (int i=0;i<3;i++) {
            DeselecturlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexproduct.php?w=90&p=%d",i];
            NSURL *DeselectUrl=[NSURL URLWithString:DeselecturlStr];
            HttpDownload *DeselectDownload=[[HttpDownload alloc]init];
            DeselectDownload.delegate=self;
            [DeselectDownload downloadFormUrlWithAsi:DeselectUrl];
        }
    }else if(numberOfSegment==1){
        DeselecturlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexproduct.php?w=90&p=%d",numberOfSelect];
        NSURL *DeselectUrl=[NSURL URLWithString:DeselecturlStr];
        HttpDownload *DeselectDownload=[[HttpDownload alloc]init];
        DeselectDownload.delegate=self;
        [DeselectDownload downloadFormUrlWithAsi:DeselectUrl];
    }else if(numberOfSegment==4){
        DeselecturlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexmember.php?w=90&p=0&n=15&ct=1&s=145"];
        NSURL *DeselectUrl=[NSURL URLWithString:DeselecturlStr];
        HttpDownload *DeselectDownload=[[HttpDownload alloc]init];
        DeselectDownload.delegate=self;
        [DeselectDownload downloadFormUrlWithAsi:DeselectUrl];
    }else if(numberOfSegment==5){
        DeselecturlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexmember.php?w=90&p=0&n=15&ct=1&s=%d",numberOfSelect+72];
        NSURL *DeselectUrl=[NSURL URLWithString:DeselecturlStr];
        HttpDownload *DeselectDownload=[[HttpDownload alloc]init];
        DeselectDownload.delegate=self;
        [DeselectDownload downloadFormUrlWithAsi:DeselectUrl];
    }
    
    if (numberOfSegment==5) {
        myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 65) style:UITableViewStylePlain];

    }else{
        myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-44) style:UITableViewStylePlain];
    }
    myTableView.dataSource=self;
    myTableView.delegate=self;
    [self.view addSubview:myTableView];
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return dataItemArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (numberOfSegment==5) {
        return 65;
    }else{
        return 80;
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (numberOfSegment==4) {
        DeselectSegment4Cell *cell=[tableView dequeueReusableCellWithIdentifier:@"DeselectSegment4Cell"];
        if (cell==nil) {
            cell=[[[NSBundle mainBundle]loadNibNamed:@"DeselectSegment4Cell" owner:nil options:nil]lastObject];
        }
        DeselectSegment4Item *item=[dataItemArray objectAtIndex:indexPath.row];
        cell.deselectCompany.text=item.DeSelectTitleText;
        cell.deselectTel.text=item.DeSelectTel;
        cell.deselectMobile.text=item.DeSelectMobile;
        cell.deselectAdress.text=item.DeSelectAddress;
        [cell.deselectImage setImageWithURL:[NSURL URLWithString:item.DeSelectImage]];
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        return cell;
    }else if(numberOfSegment==5){
        Deselectsegment5Cell *cell=[tableView dequeueReusableCellWithIdentifier:@"Deselectsegment5Cell"];
        if (cell==nil) {
            cell=[[[NSBundle mainBundle]loadNibNamed:@"Deselectsegment5Cell" owner:nil options:nil]lastObject];
        }
        DeselectSegment5Item *item=[dataItemArray objectAtIndex:0];
        cell.cell5companyLable.text=item.companyItem;
        cell.cell5telLable.text=item.telItem;
        cell.cell5addressLable.text=item.addressItem;
        [cell.cell5Image setImageWithURL:[NSURL URLWithString:item.imageItem]];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    return cell;
    }else{
            DeSelectViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"DeSelectViewCell"];
            if (cell==nil) {
                cell=[[[NSBundle mainBundle]loadNibNamed:@"DeSelectViewCell" owner:nil options:nil]lastObject];
            }
            DeSelectViewItem *item=[dataItemArray objectAtIndex:indexPath.row];
            cell.deSelectTitlelable.text=item.DeSelectTitleText;
            cell.deSelectMessagelable.text=item.DeSelectMessageText;
            [cell.deSelectimage setImageWithURL:[NSURL URLWithString:item.DeSelectImage]];
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        return cell;
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (numberOfSegment==5) {
        NSLog(@"dgsdg");
    }else{
        TableViewSelect *tbVC=[[TableViewSelect alloc]init];
        DeSelectViewItem *item=[dataItemArray objectAtIndex:indexPath.row];
        tbVC.downloadId=item.DeSelectId;
        tbVC.showImage=item.DeSelectImage;
        [self.navigationController pushViewController:tbVC animated:YES];
        [tbVC release];
    }
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)dealloc{
    [keyMuArray release];
    [super dealloc];
}


@end
