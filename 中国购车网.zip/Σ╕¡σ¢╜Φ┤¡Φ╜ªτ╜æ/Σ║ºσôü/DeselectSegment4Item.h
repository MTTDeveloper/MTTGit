//
//  DeselectSegment4Item.h
//  中国购车网
//
//  Created by qianfeng on 13-3-19.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DeselectSegment4Item : NSObject
@property (nonatomic,retain)NSString *DeSelectImage;
@property (nonatomic,retain)NSString *DeSelectTitleText;
@property (nonatomic,retain)NSString *DeSelectTel;
@property (nonatomic,retain)NSString *DeSelectMobile;
@property (nonatomic,retain)NSString *DeSelectAddress;
@property (nonatomic,retain)NSString *DeSelectId;
@end
