//
//  TableViewSelect.m
//  中国购车网
//
//  Created by qianfeng on 13-3-21.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "TableViewSelect.h"
#import "SearchViewController.h"
#import "HttpDownload.h"
#import "SBJson.h"
#import "ViewselectItem.h"
#import "viewselectCell.h"
#import "imageCell.h"
#import "image2Cell.h"
#import "UIImageView+WebCache.h"
#import "PingLunViewController.h"

@implementation TableViewSelect
@synthesize downloadId;
@synthesize showImage;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)downloadComplete:(HttpDownload *)hd{
    NSString *str=[[NSString alloc]initWithData:hd.mData encoding:NSUTF8StringEncoding];
    str=[str substringFromIndex:1];
    str=[str substringToIndex:str.length-1];
    NSDictionary *dict=[str JSONValue];
    if (dict) {
        NSArray *itemArray=[dict objectForKey:@"items"];
        for (NSDictionary *subdict in itemArray) {
            ViewselectItem *item=[[ViewselectItem alloc]init];
            item.titleItem=[subdict objectForKey:@"title"];
            item.addtimeItem=[subdict objectForKey:@"addTime"];
            item.imageItem=[subdict objectForKey:@"thumbnail"];
            item.companyItem=[NSString stringWithFormat:@"公司:%@",[dict objectForKey:@"gsName"]];
            item.priceItem=[subdict objectForKey:@"price"];
            item.contentItem=[subdict objectForKey:@"content"];
            [itemDataArray addObject:item];
            [item release];
        }
    }
    [self.view addSubview:myTableView];
    //[myTableView reloadData];
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */

-(void)backToTop{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    itemDataArray=[[NSMutableArray alloc]init];
    UIButton *leftButton=[UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame=CGRectMake(0, 0, 50, 30);
    [leftButton addTarget:self action:@selector(backToTop) forControlEvents:UIControlEventTouchUpInside];
    [leftButton setImage:[UIImage imageNamed:@"head_03.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *lefBarButton=[[UIBarButtonItem alloc]initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem=lefBarButton;
    [lefBarButton release];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    
    NSString *urlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexproduct.php?w=90&d=%@",downloadId];
    NSURL *url=[NSURL URLWithString:urlStr];
    HttpDownload *Download=[[HttpDownload alloc]init];
    Download.delegate=self;
    [Download downloadFormUrlWithAsi:url];
    
    myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-44) style:UITableViewStylePlain];
    myTableView.dataSource=self;
    myTableView.delegate=self;
    
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 5;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        return 70;
    }else if(indexPath.row==1){
        return 200;
    }else if(indexPath.row==2||indexPath.row==3){
        return 44;
    }else{
        return 416-44;
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        viewselectCell *cell=[tableView dequeueReusableCellWithIdentifier:@"viewselectCell"];
        if (cell==nil) {
            cell=[[[NSBundle mainBundle]loadNibNamed:@"viewselectCell" owner:nil options:nil]lastObject];
        }
        ViewselectItem *item=[itemDataArray objectAtIndex:0];
        cell.titleLable.text=item.titleItem;
        cell.titleLable.textAlignment=UITextAlignmentCenter;
        cell.addTimeLable.text=item.addtimeItem;
        cell.addTimeLable.textAlignment=UITextAlignmentRight;
        cell.selectionStyle=UITableViewCellSelectionStyleNone;

        return cell;
    }else if(indexPath.row==1){
        imageCell *cell=[tableView dequeueReusableCellWithIdentifier:@"imageCell"];
        if (cell==nil) {
            cell=[[[NSBundle mainBundle]loadNibNamed:@"imageCell" owner:nil options:nil]lastObject];
        }
        ViewselectItem *item=[itemDataArray objectAtIndex:0];
        [cell.imageShow setImageWithURL:[NSURL URLWithString:showImage]];
        cell.priceLable.text=item.priceItem;
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        return cell;
    }else if(indexPath.row==2){
        UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        }
        ViewselectItem *item=[itemDataArray objectAtIndex:0];
        cell.textLabel.text=item.companyItem;
        cell.textLabel.font=[UIFont boldSystemFontOfSize:17];
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        return cell;
    }else if(indexPath.row==3){
        UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"pingcell"];
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"pingcell"];
        }
        cell.textLabel.text=@"发表评论";
        cell.textLabel.font=[UIFont boldSystemFontOfSize:17];
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
        return cell;
    }else{
        UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"];
        view=[[UIWebView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-44)];
        view.delegate=self;
        NSString *urlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexproduct.php?w=90&d=%@",downloadId];
        NSURL *url=[NSURL URLWithString:urlStr];
        ViewselectItem *item=[itemDataArray objectAtIndex:0];
        [view loadHTMLString:item.contentItem baseURL:url];
        [(UIScrollView *)[[view subviews] objectAtIndex:0] setBounces:NO];
        [cell.contentView addSubview:view];
        [view release];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        return cell;
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row==2) {
        PingLunViewController *pvc=[[PingLunViewController alloc]initWithNibName:@"PingLunViewController" bundle:nil];
        [self.navigationController pushViewController:pvc animated:YES];
        [pvc release];

    }
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)dealloc{
    self.downloadId=nil;
    self.showImage=nil;
    [super dealloc];
}

@end
