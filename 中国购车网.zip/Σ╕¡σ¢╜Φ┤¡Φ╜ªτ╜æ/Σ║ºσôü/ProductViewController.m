//
//  ProductViewController.m
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "ProductViewController.h"
#import "UIImage+UIImageExtras.h"
#import "DeSelectViewController.h"
#import "SearchViewController.h"

@implementation ProductViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        UIImage *tabimage=[UIImage imageNamed:@"h2.png"];
        UIImage *tabUnimage=[UIImage imageNamed:@"k2.png"];
        CGSize size=CGSizeMake(30, 30);
        self.tabBarItem =[[UITabBarItem alloc]initWithTitle:@"产品" image:[tabimage imageByScalingToSize:size] tag:2];
        [self.tabBarItem setFinishedSelectedImage:[tabUnimage imageByScalingToSize:size] withFinishedUnselectedImage:[tabimage imageByScalingToSize:size]];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */
-(void)pressSegment:(UISegmentedControl *)sender{
    switch (sender.selectedSegmentIndex) {
        case 0:
            [nameDataArray removeAllObjects];
            NSArray *arr0=[[NSArray alloc]initWithObjects:@"北京现代",@"比亚迪",@"奔驰",@"宝马",@"奥迪",@"本田",@"大众",@"丰田",@"海马", nil];
            [nameDataArray addObjectsFromArray:arr0];
            segmentIndex=0;
            break;
        case 1:
            [nameDataArray removeAllObjects];
            NSArray *arr1=[[NSArray alloc]initWithObjects:@"轿车",@"SUV",@"MPV", nil];
            [nameDataArray addObjectsFromArray:arr1];
            segmentIndex=1;
            break;
        case 2:
            [nameDataArray removeAllObjects];
            NSArray *arr2=[[NSArray alloc]initWithObjects:@"德系",@"日系",@"美系", nil];
            [nameDataArray addObjectsFromArray:arr2];
            segmentIndex=2;
            break;
        case 3:
            [nameDataArray removeAllObjects];
            NSArray *arr3=[[NSArray alloc]initWithObjects:@"20~30",@"30~50",@"50~100",@"100~300", nil];
            [nameDataArray addObjectsFromArray:arr3];
            segmentIndex=3;
            break;
        case 4:
            [nameDataArray removeAllObjects];
            NSArray *arr4=[[NSArray alloc]initWithObjects:@"北京",@"黑龙江",@"吉林",@"河南",@"新疆",@"重庆",@"上海",@"天津",@"广州",@"深圳",@"武汉",@"成都",@"南京",@"杭州",@"苏州", nil];
            [nameDataArray addObjectsFromArray:arr4];
            segmentIndex=4;
            break;
        case 5:
            [nameDataArray removeAllObjects];
            NSArray *arr5=[[NSArray alloc]initWithObjects:@"华北",@"东北",@"华东",@"华中"@"华南",@"西南",@"西北", nil];
            [nameDataArray addObjectsFromArray:arr5];
            segmentIndex=5;
            break;
        default:
            break;
    }
    [myTableView reloadData];
}

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    nameDataArray=[[NSMutableArray alloc]init];
    NSArray *arr=[[NSArray alloc]initWithObjects:@"北京现代",@"比亚迪",@"奔驰",@"宝马",@"奥迪",@"本田",@"大众",@"丰田", nil];
    [nameDataArray addObjectsFromArray:arr];
    UIImage *navimage=[UIImage imageNamed:@"bg_top.jpg"];
    CGSize imagesize=CGSizeMake(320, 44);
    [self.navigationController.navigationBar setBackgroundImage:[navimage imageByScalingToSize:imagesize] forBarMetrics:UIBarMetricsDefault];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    
    NSArray *nameArray=[[NSArray alloc]initWithObjects:@"品牌",@"类型",@"车系",@"价格",@"城市",@"区域", nil];
    UISegmentedControl *mySegment=[[UISegmentedControl alloc]initWithItems:nameArray];
    mySegment.frame=CGRectMake(10, 5, 300, 35);
    mySegment.tintColor=[UIColor blackColor];
    mySegment.segmentedControlStyle=UISegmentedControlStyleBordered;
    [mySegment addTarget:self action:@selector(pressSegment:) forControlEvents:UIControlEventValueChanged];
    UIView *myView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 45)];
    [myView addSubview:mySegment];
    [mySegment release];
    myView.backgroundColor=[UIColor grayColor];
    [self.view addSubview:myView];
    [myView release];
    
    myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 45, 320, 416-44-45) style:UITableViewStylePlain];
    myTableView.dataSource=self;
    myTableView.delegate=self;
    [self.view addSubview:myTableView];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return nameDataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 45;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.textLabel.text=[nameDataArray objectAtIndex:indexPath.row];
    cell.textLabel.font=[UIFont boldSystemFontOfSize:17];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    DeSelectViewController *dsvc=[[DeSelectViewController alloc]init];
    dsvc.numberOfSelect=indexPath.row;
    dsvc.numberOfSegment=segmentIndex;
    if (segmentIndex==0) {
        switch (indexPath.row) {
            case 0:{
                keyArray=[[NSArray alloc]initWithObjects:@"现代", nil];
                break;
            }  
            case 1:{
                keyArray=[[NSArray alloc]initWithObjects:@"比亚迪", nil];
                break;
            }
            case 2:{
                keyArray=[[NSArray alloc]initWithObjects:@"奔驰", nil];
                break;
            }
            case 3:{
                keyArray=[[NSArray alloc]initWithObjects:@"宝马", nil];
                break;
            }
            case 4:{
                keyArray=[[NSArray alloc]initWithObjects:@"奥迪", nil];
                break;
            }
            case 5:{
                keyArray=[[NSArray alloc]initWithObjects:@"本田", nil];
                break;
            }
            case 6:{
                keyArray=[[NSArray alloc]initWithObjects:@"大众", nil];
                break;
            }
            case 7:{
                keyArray=[[NSArray alloc]initWithObjects:@"丰田", nil];
                break;
            }
            case 8:{
                keyArray=[[NSArray alloc]initWithObjects:@"海马", nil];
                break;
            }
            default:
                break;
        }

    }else if(segmentIndex==1){
        switch (indexPath.row) {
            case 0:
                keyArray=[[NSArray alloc]initWithObjects:@"0", nil];
                break;
            case 1:
                keyArray=[[NSArray alloc]initWithObjects:@"1", nil];
                break;
            case 2:
                keyArray=[[NSArray alloc]initWithObjects:@"2", nil];
                break;
                
            default:
                break;
        }
    }else if(segmentIndex==5){
        
    }
    [self.navigationController pushViewController:dsvc animated:YES];
    [dsvc.keyMuArray addObjectsFromArray:keyArray];

    [dsvc release];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
