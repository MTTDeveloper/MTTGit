//
//  DeselectSegment4Cell.h
//  中国购车网
//
//  Created by qianfeng on 13-3-19.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeselectSegment4Cell : UITableViewCell
@property (retain, nonatomic) IBOutlet UIImageView *deselectImage;
@property (retain, nonatomic) IBOutlet UILabel *deselectCompany;
@property (retain, nonatomic) IBOutlet UILabel *deselectTel;
@property (retain, nonatomic) IBOutlet UILabel *deselectMobile;
@property (retain, nonatomic) IBOutlet UILabel *deselectAdress;

@end
