//
//  DeSelectViewItem.h
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DeSelectViewItem : NSObject
@property (nonatomic,retain)NSString *DeSelectImage;
@property (nonatomic,retain)NSString *DeSelectTitleText;
@property (nonatomic,retain)NSString *DeSelectMessageText;
@property (nonatomic,retain)NSString *DeSelectId;
@end
