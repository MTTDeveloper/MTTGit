//
//  DeSelectViewCell.m
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "DeSelectViewCell.h"

@implementation DeSelectViewCell
@synthesize deSelectimage;
@synthesize deSelectTitlelable;
@synthesize deSelectMessagelable;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [deSelectimage release];
    [deSelectTitlelable release];
    [deSelectMessagelable release];
    [super dealloc];
}
@end
