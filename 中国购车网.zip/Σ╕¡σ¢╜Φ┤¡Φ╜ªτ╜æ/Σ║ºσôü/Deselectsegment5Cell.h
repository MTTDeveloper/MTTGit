//
//  Deselectsegment5Cell.h
//  中国购车网
//
//  Created by qianfeng on 13-3-22.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Deselectsegment5Cell : UITableViewCell
@property (retain, nonatomic) IBOutlet UIImageView *cell5Image;
@property (retain, nonatomic) IBOutlet UILabel *cell5companyLable;
@property (retain, nonatomic) IBOutlet UILabel *cell5telLable;
@property (retain, nonatomic) IBOutlet UILabel *cell5addressLable;

@end
