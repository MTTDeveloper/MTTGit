//
//  DeSelectViewItem.m
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "DeSelectViewItem.h"

@implementation DeSelectViewItem
@synthesize DeSelectId,DeSelectImage,DeSelectTitleText,DeSelectMessageText;
-(void)dealloc{
    self.DeSelectId=nil;
    self.DeSelectImage=nil;
    self.DeSelectMessageText=nil;
    self.DeSelectTitleText=nil;
    [super dealloc];
}
@end
