//
//  ViewselectItem.h
//  中国购车网
//
//  Created by qianfeng on 13-3-21.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ViewselectItem : NSObject
@property (nonatomic,retain)NSString *titleItem;
@property (nonatomic,retain)NSString *addtimeItem;
@property (nonatomic,retain)NSString *imageItem;
@property (nonatomic,retain)NSString *companyItem;
@property (nonatomic,retain)NSString *priceItem;
@property (nonatomic,retain)NSString *contentItem;
@end
