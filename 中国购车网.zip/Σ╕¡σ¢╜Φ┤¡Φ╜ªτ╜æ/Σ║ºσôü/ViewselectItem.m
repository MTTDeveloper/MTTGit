//
//  ViewselectItem.m
//  中国购车网
//
//  Created by qianfeng on 13-3-21.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "ViewselectItem.h"

@implementation ViewselectItem
@synthesize titleItem,addtimeItem,imageItem,companyItem,priceItem,contentItem;
-(void)dealloc{
    self.titleItem=nil;
    self.addtimeItem=nil;
    self.imageItem=nil;
    self.companyItem=nil;
    self.priceItem=nil;
    self.contentItem=nil;
    [super dealloc];
}
@end
