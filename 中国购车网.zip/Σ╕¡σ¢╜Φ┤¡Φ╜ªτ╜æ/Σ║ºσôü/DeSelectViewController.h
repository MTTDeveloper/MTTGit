//
//  DeSelectViewController.h
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface DeSelectViewController : UIViewController<HttpDownloadDelegate,UITableViewDataSource,UITableViewDelegate>
{
    UITableView *myTableView;
    NSMutableArray *dataItemArray;
    NSString *DeselecturlStr;
}
@property (nonatomic,assign)int numberOfSegment;
@property (nonatomic,assign)int numberOfSelect;
@property (nonatomic,retain)NSMutableArray *keyMuArray;
@end
