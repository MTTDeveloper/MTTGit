//
//  viewselectCell.m
//  中国购车网
//
//  Created by qianfeng on 13-3-21.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "viewselectCell.h"

@implementation viewselectCell
@synthesize titleLable;
@synthesize addTimeLable;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [titleLable release];
    [addTimeLable release];
    [super dealloc];
}
@end
