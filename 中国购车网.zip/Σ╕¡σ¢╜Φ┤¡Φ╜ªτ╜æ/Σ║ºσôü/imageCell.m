//
//  imageCell.m
//  中国购车网
//
//  Created by qianfeng on 13-3-21.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "imageCell.h"
#import "JSONKit.h"

#define kAppKey          @"4051265541"
#define kAppSecret       @"1073947d124bdac344ea52f4e0c42c98"
#define kAppRedirectURI  @"http://www.1000phone.com"

@implementation imageCell
@synthesize imageShow;
@synthesize priceLable;
@synthesize sinaWeibo;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [imageShow release];
    [priceLable release];
    [super dealloc];
}

- (IBAction)weiBo:(id)sender {
    sinaWeibo=[[SinaWeibo alloc]initWithAppKey:kAppKey appSecret:kAppSecret appRedirectURI:kAppRedirectURI andDelegate:_viewController];
    [sinaWeibo logIn];
}

-(BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
    return [self.sinaWeibo handleOpenURL:url];
}
-(BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    return [self.sinaWeibo handleOpenURL:url];
}

-(void)sinaweiboDidLogIn:(SinaWeibo *)sinaweibo
{
    //打印
    NSLog(@"sinaweiboDidLogIn userID=%@ accesstoken=%@ expirationDate=%@ refresh_token=%@",sinaweibo.userID,sinaweibo.accessToken,sinaweibo.expirationDate,sinaweibo.refreshToken);
}

@end
