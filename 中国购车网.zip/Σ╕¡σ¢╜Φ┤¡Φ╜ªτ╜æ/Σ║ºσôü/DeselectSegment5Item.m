//
//  DeselectSegment5Item.m
//  中国购车网
//
//  Created by qianfeng on 13-3-22.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "DeselectSegment5Item.h"

@implementation DeselectSegment5Item
@synthesize telItem,companyItem,imageItem,addressItem;
-(void)dealloc{
    self.telItem=nil;
    self.companyItem=nil;
    self.imageItem=nil;
    self.addressItem=nil;
    [super dealloc];
}
@end
