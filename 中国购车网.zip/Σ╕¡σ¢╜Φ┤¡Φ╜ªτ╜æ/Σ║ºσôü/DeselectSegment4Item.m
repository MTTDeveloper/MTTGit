//
//  DeselectSegment4Item.m
//  中国购车网
//
//  Created by qianfeng on 13-3-19.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "DeselectSegment4Item.h"

@implementation DeselectSegment4Item
@synthesize DeSelectImage,DeSelectId,DeSelectTitleText,DeSelectTel,DeSelectMobile,DeSelectAddress;
-(void)dealloc{
    self.DeSelectAddress=nil;
    self.DeSelectId=nil;
    self.DeSelectImage=nil;
    self.DeSelectMobile=nil;
    self.DeSelectTel=nil;
    self.DeSelectTitleText=nil;
    [super dealloc];
}
@end
