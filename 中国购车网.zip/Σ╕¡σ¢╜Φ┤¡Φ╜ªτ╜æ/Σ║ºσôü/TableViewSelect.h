//
//  TableViewSelect.h
//  中国购车网
//
//  Created by qianfeng on 13-3-21.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface TableViewSelect : UIViewController<HttpDownloadDelegate,UITableViewDataSource,UITableViewDelegate,UIWebViewDelegate>
{
    UITableView *myTableView;
    NSMutableArray *itemDataArray;
    UIWebView *view;
}
@property (nonatomic,retain)NSString *showImage;
@property (nonatomic,retain)NSString *downloadId;
@end
