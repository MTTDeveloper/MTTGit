//
//  image2Cell.h
//  中国购车网
//
//  Created by qianfeng on 13-3-21.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface image2Cell : UITableViewCell
@property (retain, nonatomic) IBOutlet UIImageView *imageShow2;

@end
