//
//  Deselectsegment5Cell.m
//  中国购车网
//
//  Created by qianfeng on 13-3-22.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "Deselectsegment5Cell.h"

@implementation Deselectsegment5Cell
@synthesize cell5Image;
@synthesize cell5companyLable;
@synthesize cell5telLable;
@synthesize cell5addressLable;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [cell5Image release];
    [cell5companyLable release];
    [cell5telLable release];
    [cell5addressLable release];
    [super dealloc];
}
@end
