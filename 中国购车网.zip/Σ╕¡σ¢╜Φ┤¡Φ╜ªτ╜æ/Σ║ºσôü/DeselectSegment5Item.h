//
//  DeselectSegment5Item.h
//  中国购车网
//
//  Created by qianfeng on 13-3-22.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DeselectSegment5Item : NSObject
@property (nonatomic,retain)NSString *companyItem;
@property (nonatomic,retain)NSString *addressItem;
@property (nonatomic,retain)NSString *imageItem;
@property (nonatomic,retain)NSString *telItem;
@end
