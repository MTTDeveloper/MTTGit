//
//  imageCell.h
//  中国购车网
//
//  Created by qianfeng on 13-3-21.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SinaWeibo.h"
#import "SinaWeiboRequest.h"

@interface imageCell : UITableViewCell<SinaWeiboDelegate,SinaWeiboRequestDelegate>
{
    id<SinaWeiboDelegate>_viewController;
}
@property (nonatomic, retain)SinaWeibo *  sinaWeibo;
@property (retain, nonatomic) IBOutlet UIImageView *imageShow;
@property (retain, nonatomic) IBOutlet UILabel *priceLable;
- (IBAction)weiBo:(id)sender;

@end
