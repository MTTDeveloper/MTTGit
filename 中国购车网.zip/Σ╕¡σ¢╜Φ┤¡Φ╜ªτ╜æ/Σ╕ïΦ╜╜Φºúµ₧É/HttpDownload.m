//
//  HttpDownload.m
//  中国购车网
//
//  Created by qianfeng on 13-3-8.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "HttpDownload.h"

@implementation HttpDownload
@synthesize mData;
@synthesize delegate;
@synthesize tag;

-(void)downloadFormUrlWithAsi:(NSURL *)url{
    mData =[[NSMutableData alloc]init];
    ASIHTTPRequest *request=[ASIHTTPRequest requestWithURL:url];
    request.delegate=self;
    [request startAsynchronous];
}
-(void)requestFinished:(ASIHTTPRequest *)request{
    [mData appendData:[request responseData]];
    if ([delegate respondsToSelector:@selector(downloadComplete:)]) {
        [delegate downloadComplete:self];
    }
}
-(void)requestFailed:(ASIHTTPRequest *)request{
    NSLog(@"tag:%d  系在失败",tag);
}

@end
