//
//  HttpDownload.h
//  中国购车网
//
//  Created by qianfeng on 13-3-8.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequest.h"
#import "HttpDownloadDelegate.h"

@interface HttpDownload : NSObject<ASIHTTPRequestDelegate>
@property (nonatomic,readonly)NSMutableData *mData;
@property (nonatomic,assign)id<HttpDownloadDelegate>delegate;
@property (nonatomic,assign)int tag;
-(void)downloadFormUrlWithAsi:(NSURL *)url;
@end
