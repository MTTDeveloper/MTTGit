//
//  HttpDownloadDelegate.h
//  中国购车网
//
//  Created by qianfeng on 13-3-8.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class HttpDownload;

@protocol HttpDownloadDelegate <NSObject>

-(void)downloadComplete:(HttpDownload *)hd;

@end
