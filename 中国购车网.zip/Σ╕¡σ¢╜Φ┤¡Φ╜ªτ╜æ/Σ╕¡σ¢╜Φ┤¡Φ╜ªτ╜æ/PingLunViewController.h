//
//  PingLunViewController.h
//  中国购车网
//
//  Created by qianfeng on 13-3-24.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PingLunDelegate.h"

@interface PingLunViewController : UIViewController
{
    NSString *path;
}
@property (nonatomic,assign)id<PingLunDelegate>delegate;
@property (retain, nonatomic) IBOutlet UITextField *pinglunText;
- (IBAction)FabiaoPingLun:(id)sender;

@end
