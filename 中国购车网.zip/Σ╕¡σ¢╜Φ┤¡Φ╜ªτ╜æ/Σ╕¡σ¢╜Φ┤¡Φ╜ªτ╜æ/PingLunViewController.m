//
//  PingLunViewController.m
//  中国购车网
//
//  Created by qianfeng on 13-3-24.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "PingLunViewController.h"
#import "FMDatabase.h"

@implementation PingLunViewController
@synthesize pinglunText;
@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    path=NSHomeDirectory();
    NSLog(@"%@",path);
    path=[path stringByAppendingPathComponent:@"Documents/PingLun.db"];
    
}

- (void)viewDidUnload
{
    [self setPinglunText:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [pinglunText release];
    [super dealloc];
}
- (IBAction)FabiaoPingLun:(id)sender {
    NSString *lable=pinglunText.text;
    NSLog(@"%@",lable);
    FMDatabase *db=[FMDatabase databaseWithPath:path];
    BOOL res=[db open];
    if (res==NO) {
        NSLog(@"open error");
        return;
    }
    res=[db executeUpdate:@"create table if not exists Pinglun(message)"];
    if (res==NO) {
        NSLog(@"create error");
        [db close];
        return;
    }
    res=[db executeUpdate:@"insert into Pinglun values(?)",lable];
    if (res==NO) {
        NSLog(@"insert error");
    }
    [db close];
    [delegate changeTableViewFormPingLun:self];
}
@end
