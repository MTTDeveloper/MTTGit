//
//  PingLunDelegate.h
//  中国购车网
//
//  Created by qianfeng on 13-3-24.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
@class PingLunViewController;

@protocol PingLunDelegate <NSObject>
-(void)changeTableViewFormPingLun:(PingLunViewController *)pvc;
@end
