//
//  MoreViewController.h
//  中国购车网
//
//  Created by qianfeng on 13-3-8.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoreViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *nameArray;
    UIView *myView;
}
@end
