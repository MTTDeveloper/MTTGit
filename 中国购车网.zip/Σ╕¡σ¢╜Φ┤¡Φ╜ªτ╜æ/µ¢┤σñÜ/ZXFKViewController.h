//
//  ZXFKViewController.h
//  中国购车网
//
//  Created by qianfeng on 13-3-20.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZXFKViewController : UIViewController
@property (retain, nonatomic) IBOutlet UITextField *LXRTextField;
@property (retain, nonatomic) IBOutlet UITextField *DHTextField;
@property (retain, nonatomic) IBOutlet UITextField *YXTextField;
@property (retain, nonatomic) IBOutlet UITextField *FKNRTextField;
- (IBAction)TJButton:(id)sender;

@end
