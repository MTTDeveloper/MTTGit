//
//  LoginViewController.h
//  中国购车网
//
//  Created by qianfeng on 13-3-20.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
@property (retain, nonatomic) IBOutlet UITextField *ZHTextField;
@property (retain, nonatomic) IBOutlet UITextField *MMTextField;
- (IBAction)LoginButton:(id)sender;
- (IBAction)QXButton:(id)sender;

@end
