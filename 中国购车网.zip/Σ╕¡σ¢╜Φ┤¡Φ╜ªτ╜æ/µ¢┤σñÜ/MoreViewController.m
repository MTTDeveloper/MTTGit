//
//  MoreViewController.m
//  中国购车网
//
//  Created by qianfeng on 13-3-8.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "MoreViewController.h"
#import "UIImage+UIImageExtras.h"
#import "WithOurViewController.h"
#import "LoginViewController.h"
#import "ZCViewController.h"
#import "ZXFKViewController.h"
#import "SearchViewController.h"

@implementation MoreViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        UIImage *tabimage=[UIImage imageNamed:@"h5.png"];
        UIImage *tabUnimage=[UIImage imageNamed:@"k5.png"];
        CGSize size=CGSizeMake(30, 30);
        self.tabBarItem =[[UITabBarItem alloc]initWithTitle:@"更多" image:[tabimage imageByScalingToSize:size] tag:5];
        [self.tabBarItem setFinishedSelectedImage:[tabUnimage imageByScalingToSize:size] withFinishedUnselectedImage:[tabimage imageByScalingToSize:size]];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)pressButton:(UIButton *)sender{
     [myView removeFromSuperview]; 
    LoginViewController *Lvc=[[LoginViewController alloc]init];
    [self.navigationController pushViewController:Lvc animated:YES];
    [Lvc release];
}

-(void)TSViewCreate{
    
    UIView *TSView=[[UIView alloc]initWithFrame:CGRectMake(35, 130, 250, 90)];
    UILabel *tsLable=[[UILabel alloc]initWithFrame:CGRectMake(50, 0, 150, 25)];
    tsLable.text=@"提示";
    tsLable.textAlignment=UITextAlignmentCenter;
    tsLable.textColor=[UIColor whiteColor];
    tsLable.backgroundColor=[UIColor clearColor];
    UIImageView *myimageView=[[UIImageView alloc]initWithFrame:CGRectMake(230, 5, 15, 15)];
    myimageView.image=[UIImage imageNamed:@"false.png"];
    [TSView addSubview:myimageView];
    
    [myimageView release];
    UIView *topView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 250, 25)];
    [topView addSubview:tsLable];
    [tsLable release];
    topView.backgroundColor=[UIColor blueColor];
    [TSView addSubview:topView];
    UILabel *myLable=[[UILabel alloc]initWithFrame:CGRectMake(0, 25, 250, 65)];
    myLable.text=@"登录后才能添加产品";
    myLable.textAlignment=UITextAlignmentCenter;
    myLable.textColor=[UIColor blackColor];
    myLable.backgroundColor=[UIColor whiteColor];
    [TSView addSubview:myLable];
    [myLable release];
    UIButton *myButton =[UIButton buttonWithType:UIButtonTypeCustom];
    myButton.frame=CGRectMake(0, 0, 320, 380);
    myButton.backgroundColor=[UIColor clearColor];
    [myButton addTarget:self action:@selector(pressButton:) forControlEvents:UIControlEventTouchUpInside];
    
    myView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320,380)];
    myView.backgroundColor=[UIColor clearColor];
    [self.view addSubview:myView];
    [myView addSubview:TSView];
    [myView addSubview:myButton];
    [myView release];
    [TSView release];
     
    
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIImage *navimage=[UIImage imageNamed:@"bg_top.jpg"];
    CGSize imagesize=CGSizeMake(320, 44);
    [self.navigationController.navigationBar setBackgroundImage:[navimage imageByScalingToSize:imagesize] forBarMetrics:UIBarMetricsDefault];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    
    NSMutableArray *loginArray=[[NSMutableArray alloc]initWithObjects:@"登陆",@"注册", nil];
    NSMutableArray *addArray=[[NSMutableArray alloc]initWithObjects:@"添加产品",@"在线反馈", nil];
    NSMutableArray *ourArray=[[NSMutableArray alloc]initWithObjects:@"关于我们", nil];
    NSMutableArray *callArray=[[NSMutableArray alloc]initWithObjects:@"联系我们",@"客服中心", nil];
    nameArray =[NSMutableArray arrayWithObjects:loginArray,addArray,ourArray,callArray, nil];
    UITableView *myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-44) style:UITableViewStyleGrouped];
    myTableView.dataSource=self;
    myTableView.delegate=self;
    myTableView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:myTableView];
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return nameArray.count;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [[nameArray objectAtIndex:section] count];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section==0) {
        if (indexPath.row==0) {
            LoginViewController *Lvc=[[LoginViewController alloc]init];
            [self.navigationController pushViewController:Lvc animated:YES];
            [Lvc release];
        }else{
            ZCViewController *ZCvc=[[ZCViewController alloc]init];
            [self.navigationController pushViewController:ZCvc animated:YES];
            [ZCvc release];
        }
    }else if(indexPath.section==1){
        if (indexPath.row==0) {
            [self TSViewCreate];
        }else{
            ZXFKViewController *ZXFKvc=[[ZXFKViewController alloc]init];
            [self.navigationController pushViewController:ZXFKvc animated:YES];
            [ZXFKvc release];
        }
    }else if (indexPath.section==2) {
        WithOurViewController *wovc=[[WithOurViewController alloc]init];
        wovc.downloadId=1;
        [self.navigationController pushViewController:wovc animated:YES];
        [wovc release];
    }else{
        if (indexPath.row==0) {
            WithOurViewController *wovc=[[WithOurViewController alloc]init];
            wovc.downloadId=2;
            wovc.createButton=1;
            [self.navigationController pushViewController:wovc animated:YES];
            [wovc release];
        }else{
            WithOurViewController *wovc=[[WithOurViewController alloc]init];
            wovc.downloadId=3;
            [self.navigationController pushViewController:wovc animated:YES];
            [wovc release];
        }
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.textLabel.text=[[nameArray objectAtIndex:indexPath.section]objectAtIndex:indexPath.row];
    [cell.textLabel setFont:[UIFont boldSystemFontOfSize:15]];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 30;
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)viewWillDisappear:(BOOL)animated{
  
}

@end
