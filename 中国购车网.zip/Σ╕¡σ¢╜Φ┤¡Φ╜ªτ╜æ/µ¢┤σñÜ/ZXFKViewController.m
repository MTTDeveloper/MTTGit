//
//  ZXFKViewController.m
//  中国购车网
//
//  Created by qianfeng on 13-3-20.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "ZXFKViewController.h"
#import "SearchViewController.h"

@implementation ZXFKViewController
@synthesize LXRTextField;
@synthesize DHTextField;
@synthesize YXTextField;
@synthesize FKNRTextField;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)backToTop{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    UIButton *leftButton=[UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame=CGRectMake(0, 0, 50, 30);
    [leftButton addTarget:self action:@selector(backToTop) forControlEvents:UIControlEventTouchUpInside];
    [leftButton setImage:[UIImage imageNamed:@"head_03.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *lefBarButton=[[UIBarButtonItem alloc]initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem=lefBarButton;
    [lefBarButton release];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
}

- (void)viewDidUnload
{
    [self setLXRTextField:nil];
    [self setDHTextField:nil];
    [self setYXTextField:nil];
    [self setFKNRTextField:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [LXRTextField release];
    [DHTextField release];
    [YXTextField release];
    [FKNRTextField release];
    [super dealloc];
}
- (IBAction)TJButton:(id)sender {
}
@end
