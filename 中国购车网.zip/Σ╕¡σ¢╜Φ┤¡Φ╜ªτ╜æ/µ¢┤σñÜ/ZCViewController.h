//
//  ZCViewController.h
//  中国购车网
//
//  Created by qianfeng on 13-3-20.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCViewController : UIViewController
- (IBAction)changeLocation:(id)sender;
@property (retain, nonatomic) IBOutlet UITextField *ZXTextField;
@property (retain, nonatomic) IBOutlet UITextField *MMTextField;
@property (retain, nonatomic) IBOutlet UITextField *GGTextField;
@property (retain, nonatomic) IBOutlet UITextField *LXRTextField;
@property (retain, nonatomic) IBOutlet UITextField *SJHMTextField;
@property (retain, nonatomic) IBOutlet UITextField *GSJJTextField;
- (IBAction)ZCButton:(id)sender;
- (IBAction)QXButton:(id)sender;

@end
