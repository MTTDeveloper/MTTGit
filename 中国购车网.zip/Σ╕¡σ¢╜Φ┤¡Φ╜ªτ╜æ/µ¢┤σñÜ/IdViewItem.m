//
//  IdViewItem.m
//  中国购车网
//
//  Created by qianfeng on 13-3-19.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "IdViewItem.h"

@implementation IdViewItem
@synthesize IdTitle,IdContent;
-(void)dealloc{
    self.IdTitle=nil;
    self.IdContent=nil;
    [super dealloc];
}
@end
