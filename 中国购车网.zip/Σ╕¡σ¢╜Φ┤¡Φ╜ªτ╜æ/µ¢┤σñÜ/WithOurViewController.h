//
//  WithOurViewController.h
//  中国购车网
//
//  Created by qianfeng on 13-3-19.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface WithOurViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,HttpDownloadDelegate,UIWebViewDelegate,UIAlertViewDelegate>
{
    UITableView *myTableView;
    NSMutableArray *WithourDataArray;
    UIWebView *view;
}
@property (nonatomic,assign)int createButton;
@property (nonatomic,assign)int downloadId;
@end
