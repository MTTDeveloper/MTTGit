//
//  WithOurViewController.m
//  中国购车网
//
//  Created by qianfeng on 13-3-19.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "WithOurViewController.h"
#import "HttpDownload.h"
#import "SBJson.h"
#import "IdViewItem.h"
#import "SearchViewController.h"

@implementation WithOurViewController
@synthesize downloadId;
@synthesize createButton;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)downloadComplete:(HttpDownload *)hd{
    NSString *str=[[NSString alloc]initWithData:hd.mData encoding:NSUTF8StringEncoding];
    str=[str substringFromIndex:1];
    str=[str substringToIndex:str.length-1];
    NSDictionary *dict=[str JSONValue];
    if (dict) {
        NSArray*itemArray=[dict objectForKey:@"items"];
        for (NSDictionary *subdict in itemArray) {
            IdViewItem *item=[[IdViewItem alloc]init];
            item.IdTitle=[subdict objectForKey:@"title"];
            item.IdContent=[subdict objectForKey:@"content"];
            [WithourDataArray addObject:item];
            [item release];
        }
        [self.view addSubview:myTableView];
    }
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */

-(void)backToTop{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIButton *leftButton=[UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame=CGRectMake(0, 0, 50, 30);
    [leftButton addTarget:self action:@selector(backToTop) forControlEvents:UIControlEventTouchUpInside];
    [leftButton setImage:[UIImage imageNamed:@"head_03.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *lefBarButton=[[UIBarButtonItem alloc]initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem=lefBarButton;
    [lefBarButton release];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    
    WithourDataArray=[[NSMutableArray alloc]init];
    NSString *urlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexpage.php?w=90&d=%d",downloadId];
    NSURL *url=[NSURL URLWithString:urlStr];
    HttpDownload *Download=[[HttpDownload alloc]init];
    Download.delegate=self;
    [Download downloadFormUrlWithAsi:url];
    
    myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-44) style:UITableViewStylePlain];
    myTableView.dataSource=self;
    myTableView.delegate=self;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 2;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        return 44; 
    }else{
        if (downloadId==1) {
            return 416-88;
        }else if(downloadId==2){
            return 200;
        }else{
            return 200;
        }
    }
}

-(void)pressHu
{
    UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:@"" message:@"呼叫13570899056" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    [self.view addSubview:myAlertView];
    [myAlertView show];
    [myAlertView release];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1)
    {
        //NSLog(@"call phone");
        UIWebView*callWebview =[[UIWebView alloc] init];
        NSURL *telURL =[NSURL URLWithString:@"tel:13570899056"];
        [callWebview loadRequest:[NSURLRequest requestWithURL:telURL]];
        [self.view addSubview:callWebview];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    if (indexPath.row==0) {
        IdViewItem *item=[WithourDataArray objectAtIndex:0];
        cell.textLabel.text=item.IdTitle;
        cell.textLabel.textAlignment=UITextAlignmentCenter;
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        return cell;
    }else{
        view=[[UIWebView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-88)];
        view.delegate=self;
        NSString *urlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexpage.php?w=90&d=%d",downloadId];
        NSURL *url=[NSURL URLWithString:urlStr];
        IdViewItem *item=[WithourDataArray objectAtIndex:0];
        [view loadHTMLString:item.IdContent baseURL:url];
        [(UIScrollView *)[[view subviews] objectAtIndex:0] setBounces:NO];
        [cell.contentView addSubview:view];
        if (createButton==1) {
            UIButton *myButton=[UIButton buttonWithType:UIButtonTypeCustom];
            myButton.frame=CGRectMake(3, 148, 200, 45);
            [myButton setTitle:@"呼叫" forState:UIControlStateNormal];
            [myButton addTarget:self action:@selector(pressHu) forControlEvents:UIControlEventTouchUpInside];
            [myButton setBackgroundImage:[UIImage imageNamed:@"login_05.jpg"] forState:UIControlStateNormal];
            [view addSubview:myButton];
        }
        [view release];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;

        return cell;
    }
}

/*
- (IBAction)buttonPress:(id) sender
{
    [textField resignFirstResponder]; 
    [self loadWebPageWithString:textField.text];
    
}*/


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
