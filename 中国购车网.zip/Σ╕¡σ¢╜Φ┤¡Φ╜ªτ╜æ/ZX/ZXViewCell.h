//
//  ZXViewCell.h
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZXViewCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UIImageView *ZXImage;
@property (retain, nonatomic) IBOutlet UILabel *zxViewTitleLable;
@property (retain, nonatomic) IBOutlet UILabel *zxViewmessageLable;

@end
