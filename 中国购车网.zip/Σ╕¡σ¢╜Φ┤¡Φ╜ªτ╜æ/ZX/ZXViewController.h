//
//  ZXViewController.h
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface ZXViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,HttpDownloadDelegate>
{
    UITableView *myTableView;
    NSMutableArray *ZXDataArray;
}


@end
