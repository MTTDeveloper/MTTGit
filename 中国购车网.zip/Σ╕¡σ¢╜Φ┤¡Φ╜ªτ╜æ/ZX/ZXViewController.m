//
//  ZXViewController.m
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "ZXViewController.h"
#import "HttpDownload.h"
#import "SBJson.h"
#import "ZXViewCell.h"
#import "ZXViewItem.h"
#import "UIImageView+WebCache.h"
#import "ZXSelectVC.h"
#import "SearchViewController.h"

@implementation ZXViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)downloadComplete:(HttpDownload *)hd{
    NSString *str=[[NSString alloc]initWithData:hd.mData encoding:NSUTF8StringEncoding];
    str=[str substringFromIndex:1];
    str=[str substringToIndex:str.length-1];
    NSDictionary *dict=[str JSONValue];
    if (dict) {
        NSArray *itemArray=[dict objectForKey:@"items"];
        for (NSDictionary *subdict in itemArray) {
            ZXViewItem *item=[[ZXViewItem alloc]init];
            item.ZXTitleText=[subdict objectForKey:@"title"];
            item.ZXMessageText=[subdict objectForKey:@"digest"];
            item.ZXImage=[subdict objectForKey:@"thumbnail"];
            item.ZXId=[subdict objectForKey:@"id"];
            [ZXDataArray addObject:item];
            [item release];
        }
        [myTableView reloadData];
    }
    
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */

-(void)backToTop{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIButton *leftButton=[UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame=CGRectMake(0, 0, 50, 30);
    [leftButton addTarget:self action:@selector(backToTop) forControlEvents:UIControlEventTouchUpInside];
    [leftButton setImage:[UIImage imageNamed:@"head_03.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *lefBarButton=[[UIBarButtonItem alloc]initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem=lefBarButton;
    [lefBarButton release];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    
    ZXDataArray=[[NSMutableArray alloc]init];
    NSString *ZXViewurlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexindexdt.php?w=90&p=0&n=15&t=10"];
    NSURL *ZXviewurl=[NSURL URLWithString:ZXViewurlStr];
    HttpDownload *ZXDownload=[[HttpDownload alloc]init];
    ZXDownload.delegate=self;
    [ZXDownload downloadFormUrlWithAsi:ZXviewurl];
    
    myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-44) style:UITableViewStylePlain];
    myTableView.dataSource=self;
    myTableView.delegate=self;
    [self.view addSubview:myTableView];
    [myTableView release];

}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return ZXDataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 85;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ZXViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell==nil) {
        cell=[[[NSBundle mainBundle]loadNibNamed:@"ZXViewCell" owner:nil options:nil]lastObject];
    }
    ZXViewItem *item=[ZXDataArray objectAtIndex:indexPath.row];
    cell.zxViewTitleLable.text=item.ZXTitleText;
    cell.zxViewmessageLable.text=item.ZXMessageText;
    cell.zxViewmessageLable.numberOfLines=0;
    [cell.ZXImage setImageWithURL:[NSURL URLWithString:item.ZXImage]];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    ZXSelectVC *zxsvc=[[ZXSelectVC alloc]init];
    ZXViewItem *item=[ZXDataArray objectAtIndex:indexPath.row];
    zxsvc.ZXSelectId=item.ZXId;
    [self.navigationController pushViewController:zxsvc animated:YES];
    [zxsvc release];
}



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
