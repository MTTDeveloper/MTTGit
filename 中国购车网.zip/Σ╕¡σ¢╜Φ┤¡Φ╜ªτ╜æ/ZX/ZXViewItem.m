//
//  ZXViewItem.m
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "ZXViewItem.h"

@implementation ZXViewItem
@synthesize ZXImage,ZXTitleText,ZXMessageText,ZXId;
-(void)dealloc{
    self.ZXImage=nil;
    self.ZXMessageText=nil;
    self.ZXTitleText=nil;
    self.ZXId=nil;
    [super dealloc];
}
@end
