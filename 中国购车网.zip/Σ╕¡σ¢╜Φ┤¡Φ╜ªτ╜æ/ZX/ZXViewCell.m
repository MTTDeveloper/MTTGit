//
//  ZXViewCell.m
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "ZXViewCell.h"

@implementation ZXViewCell
@synthesize ZXImage;
@synthesize zxViewTitleLable;
@synthesize zxViewmessageLable;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [ZXImage release];
    [zxViewTitleLable release];
    [zxViewmessageLable release];
    [super dealloc];
}
@end
