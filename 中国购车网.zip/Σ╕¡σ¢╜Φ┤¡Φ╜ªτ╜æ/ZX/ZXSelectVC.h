//
//  ZXSelectVC.h
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface ZXSelectVC : UIViewController<UITableViewDataSource,UITableViewDelegate,HttpDownloadDelegate,UIWebViewDelegate>
{
    UITableView *myTableView;
    UIWebView *view;
}
@property (nonatomic,retain)NSString *ZXSelectId;
@property (nonatomic,retain)NSString *ZXSelectTitle;
@property (nonatomic,retain)NSString *ZXSelectDate;
@property (nonatomic,retain)NSString *ZXSelectMessage;
@end
