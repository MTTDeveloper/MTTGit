//
//  ZXViewItem.h
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZXViewItem : NSObject
@property (nonatomic,retain)NSString *ZXImage;
@property (nonatomic,retain)NSString *ZXTitleText;
@property (nonatomic,retain)NSString *ZXMessageText;
@property (nonatomic,retain)NSString *ZXId;
@end
