//
//  PCViewItem.m
//  中国购车网
//
//  Created by qianfeng on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "PCViewItem.h"

@implementation PCViewItem
@synthesize PCImage,PCTitleText,PCMessageText,PCId;
-(void)dealloc{
    self.PCImage=nil;
    self.PCMessageText=nil;
    self.PCTitleText=nil;
    self.PCId=nil;
    [super dealloc];
}
@end
