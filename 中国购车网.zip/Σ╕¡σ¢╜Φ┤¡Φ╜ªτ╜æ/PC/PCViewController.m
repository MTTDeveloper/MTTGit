//
//  PCViewController.m
//  中国购车网
//
//  Created by qianfeng on 13-3-11.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "PCViewController.h"
#import "HttpDownload.h"
#import "SBJson.h"
#import "PCViewCell.h"
#import "PCViewItem.h"
#import "UIImageView+WebCache.h"
#import "PCSelectVC.h"
#import "SearchViewController.h"

@implementation PCViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)downloadComplete:(HttpDownload *)hd{
    NSString *str=[[NSString alloc]initWithData:hd.mData encoding:NSUTF8StringEncoding];
    str=[str substringFromIndex:1];
    str=[str substringToIndex:str.length-1];
    NSDictionary *dict=[str JSONValue];
    if (dict) {
        NSArray *itemArray=[dict objectForKey:@"items"];
        for (NSDictionary *subdict in itemArray) {
            PCViewItem *item=[[PCViewItem alloc]init];
            item.PCTitleText=[subdict objectForKey:@"title"];
            item.PCMessageText=[subdict objectForKey:@"digest"];
            item.PCImage=[subdict objectForKey:@"thumbnail"];
            item.PCId=[subdict objectForKey:@"id"];
            [PCDataArray addObject:item];
            [item release];
        }
        [myTableView reloadData];
    }

}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */

-(void)backToTop{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIButton *leftButton=[UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame=CGRectMake(0, 0, 50, 30);
    [leftButton addTarget:self action:@selector(backToTop) forControlEvents:UIControlEventTouchUpInside];
    [leftButton setImage:[UIImage imageNamed:@"head_03.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *lefBarButton=[[UIBarButtonItem alloc]initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem=lefBarButton;
    [lefBarButton release];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    
    PCDataArray=[[NSMutableArray alloc]init];
    NSString *PCViewurlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexindexdt.php?w=90&p=0&n=15&t=13"];
    NSURL *PCviewurl=[NSURL URLWithString:PCViewurlStr];
    HttpDownload *PCDownload=[[HttpDownload alloc]init];
    PCDownload.delegate=self;
    [PCDownload downloadFormUrlWithAsi:PCviewurl];
    
    myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-44) style:UITableViewStylePlain];
    myTableView.dataSource=self;
    myTableView.delegate=self;
    [self.view addSubview:myTableView];
    [myTableView release];


}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return PCDataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 85;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    PCViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell==nil) {
        cell=[[[NSBundle mainBundle]loadNibNamed:@"PCViewCell" owner:nil options:nil]lastObject];
    }
    PCViewItem *item=[PCDataArray objectAtIndex:indexPath.row];
    cell.pcViewtitleLable.text=item.PCTitleText;
    cell.pcViewmessageLable.text=item.PCMessageText;
    cell.pcViewmessageLable.numberOfLines=0;
    [cell.pcimage setImageWithURL:[NSURL URLWithString:item.PCImage]];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    PCSelectVC *pcsvc=[[PCSelectVC alloc]init];
    PCViewItem *item=[PCDataArray objectAtIndex:indexPath.row];
    pcsvc.PCSelectId=item.PCId;
    [self.navigationController pushViewController:pcsvc animated:YES];
    [pcsvc release];
}




- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
