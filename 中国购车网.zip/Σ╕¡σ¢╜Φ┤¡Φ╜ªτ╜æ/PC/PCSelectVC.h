//
//  PCSelectVC.h
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface PCSelectVC : UIViewController<UITableViewDataSource,UITableViewDelegate,UIWebViewDelegate,HttpDownloadDelegate>
{
    UITableView *myTableView;
    UIWebView *view;
}
@property (nonatomic,retain)NSString *PCSelectId;
@property (nonatomic,retain)NSString *PCSelectTitle;
@property (nonatomic,retain)NSString *PCSelectDate;
@property (nonatomic,retain)NSString *PCSelectMessage;
@end
