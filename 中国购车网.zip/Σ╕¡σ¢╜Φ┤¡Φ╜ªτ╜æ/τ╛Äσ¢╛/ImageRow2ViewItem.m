//
//  ImageRow2ViewItem.m
//  中国购车网
//
//  Created by qianfeng on 13-3-19.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "ImageRow2ViewItem.h"

@implementation ImageRow2ViewItem
@synthesize imageRow2image,imageRow2Title,imageRow2Id;
-(void)dealloc{
    self.imageRow2Title=nil;
    self.imageRow2image=nil;
    self.imageRow2Id=nil;
    [super dealloc];
}
@end
