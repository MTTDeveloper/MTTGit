//
//  ImageViewController.m
//  中国购车网
//
//  Created by qianfeng on 13-3-8.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "ImageViewController.h"
#import "UIImage+UIImageExtras.h"
#import "ImageRow1VC.h"
#import "ImageRow2VC.h"
#import "ImageRow3VC.h"
#import "ImageViewCell.h"
#import "SearchViewController.h"


@implementation ImageViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        UIImage *tabimage=[UIImage imageNamed:@"h3.png"];
        UIImage *tabUnimage=[UIImage imageNamed:@"k3.png"];
        CGSize size=CGSizeMake(30, 30);
        self.tabBarItem =[[UITabBarItem alloc]initWithTitle:@"美图" image:[tabimage imageByScalingToSize:size] tag:3];
        [self.tabBarItem setFinishedSelectedImage:[tabUnimage imageByScalingToSize:size] withFinishedUnselectedImage:[tabimage imageByScalingToSize:size]];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIImage *navimage=[UIImage imageNamed:@"bg_top.jpg"];
    CGSize imagesize=CGSizeMake(320, 44);
    [self.navigationController.navigationBar setBackgroundImage:[navimage imageByScalingToSize:imagesize] forBarMetrics:UIBarMetricsDefault];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    
    UITableView *myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 150) style:UITableViewStylePlain];
    myTableView.dataSource=self;
    myTableView.delegate=self;
    [self.view addSubview:myTableView];
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 3;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ImageViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell==nil) {
        cell=[[[NSBundle mainBundle]loadNibNamed:@"ImageViewCell" owner:nil options:nil]lastObject];
    }
    if (indexPath.row==0) {
        cell.imageViewlable.text=@"初步海选";
        //[cell.DGFirstCellImage setImage:[UIImage imageNamed:@""]];
    }else if(indexPath.row==1){
        cell.imageViewlable.text=@"购物手册";
        //[cell.DGFirstCellImage setImage:[UIImage imageNamed:@""]];
    }else{
        cell.imageViewlable.text=@"香车壁纸";
        //[cell.imageViewImage setImage:[UIImage imageNamed:@""]];
    }
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath  animated:YES];
    if (indexPath.row==0) {
        ImageRow1VC *dsr1=[[ImageRow1VC alloc]init];
        [self.navigationController pushViewController:dsr1 animated:YES];
    }else if(indexPath.row==1){
        ImageRow2VC *dsr2=[[ImageRow2VC alloc]init];
        [self.navigationController pushViewController:dsr2 animated:YES];
    }else{
        ImageRow3VC *dsr3=[[ImageRow3VC alloc]init];
        [self.navigationController pushViewController:dsr3 animated:YES];
    }
}



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
