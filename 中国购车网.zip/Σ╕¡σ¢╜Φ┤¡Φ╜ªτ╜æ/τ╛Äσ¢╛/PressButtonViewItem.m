//
//  PressButtonViewItem.m
//  中国购车网
//
//  Created by qianfeng on 13-3-19.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "PressButtonViewItem.h"

@implementation PressButtonViewItem
@synthesize pressButtonDate,pressButtonImage,pressButtonTitle;
-(void)dealloc{
    self.pressButtonDate=nil;
    self.pressButtonImage=nil;
    self.pressButtonTitle=nil;
    [super dealloc];
}
@end
