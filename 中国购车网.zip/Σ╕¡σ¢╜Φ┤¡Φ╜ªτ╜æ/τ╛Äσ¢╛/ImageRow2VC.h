//
//  ImageRow2VC.h
//  中国购车网
//
//  Created by qianfeng on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface ImageRow2VC : UIViewController<HttpDownloadDelegate,UIScrollViewDelegate>
{
    NSMutableArray *imageRow2DataArray;
    UIScrollView *myScrollView;
}
@end
