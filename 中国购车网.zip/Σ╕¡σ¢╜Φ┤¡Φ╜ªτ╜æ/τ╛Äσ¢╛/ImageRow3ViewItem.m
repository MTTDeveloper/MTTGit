//
//  ImageRow3ViewItem.m
//  中国购车网
//
//  Created by qianfeng on 13-3-19.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "ImageRow3ViewItem.h"

@implementation ImageRow3ViewItem
@synthesize imageRow3image,imageRow3Title,imageRow3Id;
-(void)dealloc{
    self.imageRow3image=nil;
    self.imageRow3Title=nil;
    self.imageRow3Id=nil;
    [super dealloc];
}
@end
