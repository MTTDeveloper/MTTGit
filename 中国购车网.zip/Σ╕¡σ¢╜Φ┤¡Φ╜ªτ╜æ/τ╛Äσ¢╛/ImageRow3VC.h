//
//  ImageRow3VC.h
//  中国购车网
//
//  Created by qianfeng on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface ImageRow3VC : UIViewController<HttpDownloadDelegate,UIScrollViewDelegate>
{
    NSMutableArray *imageRow3DataArray;
    UIScrollView *myScrollView;
}
@end
