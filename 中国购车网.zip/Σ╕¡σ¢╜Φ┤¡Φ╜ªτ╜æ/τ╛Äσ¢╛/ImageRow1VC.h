//
//  ImageRow1VC.h
//  中国购车网
//
//  Created by qianfeng on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface ImageRow1VC : UIViewController<HttpDownloadDelegate,UIScrollViewDelegate>
{
    NSMutableArray *imageRow1DataArray;
    UIScrollView *myScrollView;
    BOOL isPress;
}
@end
