//
//  ImageRow1ViewItem.m
//  中国购车网
//
//  Created by qianfeng on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "ImageRow1ViewItem.h"

@implementation ImageRow1ViewItem
@synthesize imageRow1image,imageRow1Title,imageRow1Id;
-(void)dealloc{
    self.imageRow1image=nil;
    self.imageRow1Title=nil;
    self.imageRow1Id=nil;
    [super dealloc];
}
@end
