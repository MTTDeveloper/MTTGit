//
//  ImageRow1ViewItem.h
//  中国购车网
//
//  Created by qianfeng on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ImageRow1ViewItem : NSObject
@property (nonatomic,retain)NSString *imageRow1image;
@property (nonatomic,retain)NSString *imageRow1Title;
@property (nonatomic,retain)NSString *imageRow1Id;
@end
