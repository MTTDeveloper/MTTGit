//
//  PressButtonRow1Cell.h
//  中国购车网
//
//  Created by qianfeng on 13-3-19.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PressButtonRow1Cell : UITableViewCell
@property (retain, nonatomic) IBOutlet UILabel *Row1Title;
@property (retain, nonatomic) IBOutlet UILabel *Row1Date;

@end
