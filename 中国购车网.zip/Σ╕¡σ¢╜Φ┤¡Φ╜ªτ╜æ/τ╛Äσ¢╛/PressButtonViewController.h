//
//  PressButtonViewController.h
//  中国购车网
//
//  Created by qianfeng on 13-3-19.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface PressButtonViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,HttpDownloadDelegate>
{
    UITableView *myTableView;
    NSMutableArray *pressButtonDataArray;
}
@property (nonatomic,retain)NSString *downloadId;
@end
