//
//  ImageRow1VC.m
//  中国购车网
//
//  Created by qianfeng on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "ImageRow1VC.h"
#import "HttpDownload.h"
#import "SBJson.h"
#import "UIImageView+WebCache.h"
#import "ImageRow1ViewItem.h"
#import "PressButtonViewController.h"
#import "SearchViewController.h"

@implementation ImageRow1VC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)pressMyButton:(UIButton *)sender{
    isPress=YES;
    NSString *imageRow1urlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexgalleryc.php?w=90&p=1&n=15&t=11"];
    NSURL *imageRow1url=[NSURL URLWithString:imageRow1urlStr];
    HttpDownload *imageRow1Download=[[HttpDownload alloc]init];
    imageRow1Download.delegate=self;
    [imageRow1Download downloadFormUrlWithAsi:imageRow1url];
    
}

-(void)pressOneButton:(UIButton *)sender{
    ImageRow1ViewItem *item=[imageRow1DataArray objectAtIndex:sender.tag];
    PressButtonViewController *pbvc=[[PressButtonViewController alloc]init];
    pbvc.downloadId=item.imageRow1Id;
    [self.navigationController pushViewController:pbvc animated:YES];
    [pbvc release];
}

-(void)pushSecondView{
    [myScrollView removeFromSuperview];
    //myScrollView.hidden=YES;
    UIScrollView *myScrollView2=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-44)];
    
    myScrollView2.contentSize=CGSizeMake(320,imageRow1DataArray.count/3*110+10);
    myScrollView2.delegate=self;
    
    for (int i=0; i<imageRow1DataArray.count; i++) {
        UIView *oneView=[[UIView alloc]initWithFrame:CGRectMake(5+(i%3)*(5+100), 10+(i/3)*110, 100, 110)];
        UIImageView *oneImage=[[UIImageView alloc]init];
        oneImage.frame=CGRectMake(0, 0, 100, 80);
        ImageRow1ViewItem *item=[imageRow1DataArray objectAtIndex:i];
        [oneImage setImageWithURL:[NSURL URLWithString:item.imageRow1image]];
        [oneView addSubview:oneImage];
        UILabel *oneLable=[[UILabel alloc]initWithFrame:CGRectMake(0, 80, 100, 30)];
        oneLable.text=item.imageRow1Title;
        oneLable.textAlignment=UITextAlignmentCenter;
        [oneView addSubview:oneLable];
        
        UIButton *oneButton=[UIButton buttonWithType:UIButtonTypeCustom]; 
        [oneView addSubview:oneButton];
        [oneButton setBackgroundColor:[UIColor clearColor]];
        oneButton.tag=i;
        oneButton.frame=CGRectMake(0, 0, 100, 110);
        //oneButton.frame=CGRectMake(5+(i%3)*(5+100), 10+(i/3)*110, 100, 110);
        [oneButton addTarget:self action:@selector(pressOneButton:) forControlEvents:UIControlEventTouchUpInside];
        [myScrollView2 addSubview:oneView];
    
    }
    [self.view addSubview:myScrollView2];

}

-(void)createButton{
    
    myScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-44)];
   
    myScrollView.contentSize=CGSizeMake(320,imageRow1DataArray.count/3*110+50);
    myScrollView.delegate=self;
   
    for (int i=0; i<imageRow1DataArray.count; i++) {
        UIView *oneView=[[UIView alloc]initWithFrame:CGRectMake(5+(i%3)*(5+100), 10+(i/3)*110, 100, 110)];
        UIImageView *oneImage=[[UIImageView alloc]init];
        oneImage.frame=CGRectMake(0, 0, 100, 80);
        ImageRow1ViewItem *item=[imageRow1DataArray objectAtIndex:i];
        [oneImage setImageWithURL:[NSURL URLWithString:item.imageRow1image]];
        [oneView addSubview:oneImage];
        UILabel *oneLable=[[UILabel alloc]initWithFrame:CGRectMake(0, 80, 100, 30)];
        oneLable.text=item.imageRow1Title;
        oneLable.textAlignment=UITextAlignmentCenter;
        [oneView addSubview:oneLable];
        
        UIButton *oneButton=[UIButton buttonWithType:UIButtonTypeCustom]; 
        [oneView addSubview:oneButton];
        [oneButton setBackgroundColor:[UIColor clearColor]];
        oneButton.tag=i;
        oneButton.frame=CGRectMake(0, 0, 100, 110);
        //oneButton.frame=CGRectMake(5+(i%3)*(5+100), 10+(i/3)*110, 100, 110);
        [oneButton addTarget:self action:@selector(pressOneButton:) forControlEvents:UIControlEventTouchUpInside];
        [myScrollView addSubview:oneView];

        
    
    }
    UILabel *myLable=[[UILabel alloc]initWithFrame:CGRectMake(0, myScrollView.contentSize.height-45, 320, 50)];
    myLable.text=@"点击查看更多...";
    myLable.textColor=[UIColor grayColor];
    [myLable setFont:[UIFont boldSystemFontOfSize:15]];
    myLable.textAlignment=UITextAlignmentCenter;
    
    UIButton *myButton=[UIButton buttonWithType:UIButtonTypeCustom];
    myButton.frame=CGRectMake(0, myScrollView.contentSize.height-45, 320, 50);
    [myScrollView addSubview:myButton];
    [myButton setBackgroundColor:[UIColor clearColor]];
    [myButton addTarget:self action:@selector(pressMyButton:) forControlEvents:UIControlEventTouchUpInside];
    [myScrollView addSubview:myLable];

    [self.view addSubview:myScrollView];
    
}

-(void)downloadComplete:(HttpDownload *)hd{
    NSString *str=[[NSString alloc]initWithData:hd.mData encoding:NSUTF8StringEncoding];
    str=[str substringFromIndex:1];
    str=[str substringToIndex:str.length-1];
    NSDictionary *dict=[str JSONValue];
    if (dict) {
        NSArray*itemArray=[dict objectForKey:@"items"];
        for (NSDictionary *subdict in itemArray) {
            ImageRow1ViewItem *item=[[ImageRow1ViewItem alloc]init];
            item.imageRow1image=[subdict objectForKey:@"thumbnail"];
            item.imageRow1Title=[subdict objectForKey:@"title"];
            item.imageRow1Id=[subdict objectForKey:@"id"];
            [imageRow1DataArray addObject:item];
            [item release];
        }
    }
    
    if (isPress==YES) {
        [self pushSecondView];
    }else{
        [self createButton];
    }
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */

-(void)backToTop{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIButton *leftButton=[UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame=CGRectMake(0, 0, 50, 30);
    [leftButton addTarget:self action:@selector(backToTop) forControlEvents:UIControlEventTouchUpInside];
    [leftButton setImage:[UIImage imageNamed:@"head_03.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *lefBarButton=[[UIBarButtonItem alloc]initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem=lefBarButton;
    [lefBarButton release];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    
    imageRow1DataArray =[[NSMutableArray alloc]init];
    NSString *imageRow1urlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexgalleryc.php?w=90&p=0&n=15&t=11"];
    NSURL *imageRow1url=[NSURL URLWithString:imageRow1urlStr];
    HttpDownload *imageRow1Download=[[HttpDownload alloc]init];
    imageRow1Download.delegate=self;
    [imageRow1Download downloadFormUrlWithAsi:imageRow1url];
    

}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
