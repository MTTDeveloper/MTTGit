//
//  PressButtonViewController.m
//  中国购车网
//
//  Created by qianfeng on 13-3-19.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "PressButtonViewController.h"
#import "HttpDownload.h"
#import "SBJson.h"
#import "UIImageView+WebCache.h"
#import "PressButtonViewItem.h"
#import "PressButtonRow1Cell.h"
#import "PressButtonRow2Cell.h"
#import "SearchViewController.h"

@implementation PressButtonViewController
@synthesize downloadId;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)downloadComplete:(HttpDownload *)hd{
    NSString *str=[[NSString alloc]initWithData:hd.mData encoding:NSUTF8StringEncoding];
    str=[str substringFromIndex:1];
    str=[str substringToIndex:str.length-1];
    NSDictionary *dict=[str JSONValue];
    if (dict) {
        NSArray*itemArray=[dict objectForKey:@"items"];
        for (NSDictionary *subdict in itemArray) {
            PressButtonViewItem *item=[[PressButtonViewItem alloc]init];
            item.pressButtonImage=[NSString stringWithFormat:@"http://app.caeac.cn/929d8f5835561f252553617ab8ac26d4//%@",[subdict objectForKey:@"thumbnail"]];
            item.pressButtonTitle=[subdict objectForKey:@"title"];
            item.pressButtonDate=[subdict objectForKey:@"addTime"];
            [pressButtonDataArray addObject:item];
            [item release];
        }
    }
    [self.view addSubview:myTableView];

}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */

-(void)backToTop{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIButton *leftButton=[UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame=CGRectMake(0, 0, 50, 30);
    [leftButton addTarget:self action:@selector(backToTop) forControlEvents:UIControlEventTouchUpInside];
    [leftButton setImage:[UIImage imageNamed:@"head_03.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *lefBarButton=[[UIBarButtonItem alloc]initWithCustomView:leftButton];
    self.navigationItem.leftBarButtonItem=lefBarButton;
    [lefBarButton release];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    
    pressButtonDataArray=[[NSMutableArray alloc]init];
    NSString *pressButtonurlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexgalleryc.php?w=90&d=%@",downloadId];
    NSURL *pressButtonurl=[NSURL URLWithString:pressButtonurlStr];
    HttpDownload *pressButtonDownload=[[HttpDownload alloc]init];
    pressButtonDownload.delegate=self;
    [pressButtonDownload downloadFormUrlWithAsi:pressButtonurl];
    
    myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-44) style:UITableViewStylePlain];
    myTableView.dataSource=self;
    myTableView.delegate=self;
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 2;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        return 70;
    }else{
        return 416-44-70;
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        PressButtonRow1Cell *cell=[tableView dequeueReusableCellWithIdentifier:@"PressButtonRow1Cell"];
        if (cell==nil) {
            cell=[[[NSBundle mainBundle]loadNibNamed:@"PressButtonRow1Cell" owner:nil options:nil]lastObject];
        }
        PressButtonViewItem *item=[pressButtonDataArray objectAtIndex:0];
        cell.Row1Date.textAlignment=UITextAlignmentCenter;
        cell.Row1Date.text=item.pressButtonDate;
        cell.Row1Title.textAlignment=UITextAlignmentCenter;
        cell.Row1Title.text=item.pressButtonTitle;
        cell.selectionStyle=UITableViewCellSelectionStyleNone;

        return cell;
    }else{
        PressButtonRow2Cell *cell=[tableView dequeueReusableCellWithIdentifier:@"PressButtonRow2Cell"];
        if (cell==nil) {
            cell=[[[NSBundle mainBundle]loadNibNamed:@"PressButtonRow2Cell" owner:nil options:nil]lastObject];
        }
        PressButtonViewItem *item=[pressButtonDataArray objectAtIndex:0];
        [cell.Row2image setImageWithURL:[NSURL URLWithString:item.pressButtonImage]];
        cell.selectionStyle=UITableViewCellSelectionStyleNone;
        return cell;
    }
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)dealloc{
    self.downloadId=nil;
    [super dealloc];
}

@end
