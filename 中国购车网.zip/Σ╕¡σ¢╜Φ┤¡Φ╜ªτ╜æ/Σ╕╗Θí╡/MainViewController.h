//
//  MainViewController.h
//  中国购车网
//
//  Created by qianfeng on 13-3-8.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"
#import "EGORefreshTableHeaderView.h"

@interface MainViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,HttpDownloadDelegate,EGORefreshTableHeaderDelegate>
{
    NSMutableArray *mainDataArray;
    UITableView *myTableView;
    NSMutableArray *mainTopImageArray;
    EGORefreshTableHeaderView *refreshView;
    BOOL isLoading;
    NSInteger page;
    NSInteger number;
    HttpDownload *httpdownload2;
}

@end
