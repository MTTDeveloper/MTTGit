//
//  MainTableViewImageItem.m
//  中国购车网
//
//  Created by qianfeng on 13-3-11.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "MainTableViewImageItem.h"

@implementation MainTableViewImageItem
@synthesize tableViewimage,tableViewimagemessage;

-(void)dealloc{
    self.tableViewimage=nil;
    self.tableViewimagemessage=nil;
    [super dealloc];
}
@end
