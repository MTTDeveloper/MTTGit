//
//  FirstCell.h
//  网易新闻
//
//  Created by qianfeng on 13-3-3.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstCell : UITableViewCell<UIScrollViewDelegate>

{
    UIScrollView *sv;
}
@property (nonatomic,retain)NSArray *imageArray;

-(UIView *)CellView;
-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier withArray:(NSArray *)array;

@end
