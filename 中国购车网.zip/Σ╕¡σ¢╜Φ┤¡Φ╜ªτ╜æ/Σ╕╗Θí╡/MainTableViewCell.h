//
//  MainTableViewCell.h
//  中国购车网
//
//  Created by qianfeng on 13-3-9.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainTableViewCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UIImageView *TableViewCellImage;
@property (retain, nonatomic) IBOutlet UILabel *TableViewCellTitleLable;
@property (retain, nonatomic) IBOutlet UILabel *TableViewCellMessageLable;

@end
