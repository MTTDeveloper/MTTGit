//
//  MainSelectViewController.h
//  中国购车网
//
//  Created by qianfeng on 13-3-15.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"
#import "PingLunDelegate.h"

@interface MainSelectViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,HttpDownloadDelegate,UIWebViewDelegate,PingLunDelegate>
{
    UITableView *myTableView;
    UIWebView *view;
}
@property (nonatomic,retain)NSString *mainsecondViewId;
@property (nonatomic,retain)NSString *mainselectTitle;
@property (nonatomic,retain)NSString *mainselectDate;
@property (nonatomic,retain)NSString *mainselectMessage;
@end
