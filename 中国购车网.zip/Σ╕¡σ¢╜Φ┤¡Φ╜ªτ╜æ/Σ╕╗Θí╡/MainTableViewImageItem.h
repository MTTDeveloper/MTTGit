//
//  MainTableViewImageItem.h
//  中国购车网
//
//  Created by qianfeng on 13-3-11.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MainTableViewImageItem : NSObject
@property (nonatomic,retain)NSString *tableViewimage;
@property (nonatomic,retain)NSString *tableViewimagemessage;
@end
