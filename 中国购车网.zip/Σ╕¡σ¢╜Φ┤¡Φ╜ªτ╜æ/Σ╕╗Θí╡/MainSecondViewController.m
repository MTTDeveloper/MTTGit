//
//  MainSecondViewController.m
//  中国购车网
//
//  Created by qianfeng on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "MainSecondViewController.h"
#import "HttpDownload.h"
#import "SBJson.h"

@implementation MainSecondViewController
@synthesize mainsecondViewId;
@synthesize mainsecondViewTitleLable;
@synthesize mainsecondViewTimeLable;
@synthesize mainsecondViewMessageLable;
@synthesize scrollView;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)downloadComplete:(HttpDownload *)hd{
    NSString *str=[[NSString alloc]initWithData:hd.mData encoding:NSUTF8StringEncoding];
    str=[str substringFromIndex:1];
    str=[str substringToIndex:str.length-1];
    NSDictionary *dict=[str JSONValue];
    if (dict) {
        NSArray *itemArray=[dict objectForKey:@"items"];
        NSLog(@"%d",itemArray.count);
        for (NSDictionary *subdict in itemArray) {
            NSLog(@"%@",subdict);
            self.mainsecondViewTitleLable.text=[subdict objectForKey:@"title"];
            self.mainsecondViewTimeLable.text=[subdict objectForKey:@"addTime"];
            NSLog(@"abc");
            self.mainsecondViewMessageLable.text=[subdict objectForKey:@"content"];
            CGSize newsize=[mainsecondViewMessageLable.text sizeWithFont:[UIFont boldSystemFontOfSize:18] constrainedToSize:CGSizeMake(320, 150000) lineBreakMode:UILineBreakModeCharacterWrap];
            CGRect newrect=CGRectMake(mainsecondViewMessageLable.frame.origin.x, mainsecondViewMessageLable.frame.origin.y, mainsecondViewMessageLable.frame.size.width, newsize.height);
            mainsecondViewMessageLable.frame=newrect;
            scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, 320, 416-44)];
            scrollView.delegate=self;
            scrollView.contentSize=CGSizeMake(320, mainsecondViewMessageLable.frame.origin.y+mainsecondViewMessageLable.frame.size.height+200);
            [scrollView addSubview:mainsecondViewTitleLable];
            [scrollView addSubview:mainsecondViewTimeLable];
            [scrollView addSubview:mainsecondViewMessageLable];
            [self.view addSubview:scrollView];
            [scrollView release];
        }
    }
}

-(void)backToTop{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIButton *leftButton=[UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame=CGRectMake(0, 0, 50, 30);
    [leftButton addTarget:self action:@selector(backToTop) forControlEvents:UIControlEventTouchUpInside];
    [leftButton setImage:[UIImage imageNamed:@"head_03.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *lefBarButton=[[UIBarButtonItem alloc]initWithCustomView:leftButton];
    //self.navigationItem.leftBarButtonItem=lefBarButton;
    [lefBarButton release];
    
    // Do any additional setup after loading the view from its nib.
    NSString *mainsecondurlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexarticlec.php?w=90&d=55&n=5&p=0&t=1"];
    NSURL *mainsecondUrl=[NSURL URLWithString:mainsecondurlStr];
    HttpDownload *mainsecondDownload=[[HttpDownload alloc]init];
    mainsecondDownload.delegate=self;
    [mainsecondDownload downloadFormUrlWithAsi:mainsecondUrl];
    
    
    mainsecondViewTitleLable.textAlignment=UITextAlignmentCenter;
    mainsecondViewTitleLable.numberOfLines=0;
    [self.view addSubview:mainsecondViewTitleLable];
    mainsecondViewTimeLable.textAlignment=UITextAlignmentCenter;
    [self.view addSubview:mainsecondViewTimeLable];
    mainsecondViewMessageLable.numberOfLines=0;
    [self.view addSubview:mainsecondViewMessageLable];
    
}


- (void)viewDidUnload
{
    [self setMainsecondViewTitleLable:nil];
    [self setMainsecondViewTimeLable:nil];
    [self setMainsecondViewMessageLable:nil];
    [self setScrollView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)dealloc{
    self.mainsecondViewId=nil;
    [mainsecondViewTitleLable release];
    [mainsecondViewTimeLable release];
    [mainsecondViewMessageLable release];
    [scrollView release];
    [super dealloc];
}

@end
