//
//  MainTableViewCell.m
//  中国购车网
//
//  Created by qianfeng on 13-3-9.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "MainTableViewCell.h"

@implementation MainTableViewCell
@synthesize TableViewCellImage;
@synthesize TableViewCellTitleLable;
@synthesize TableViewCellMessageLable;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [TableViewCellImage release];
    [TableViewCellTitleLable release];
    [TableViewCellMessageLable release];
    [super dealloc];
}
@end
