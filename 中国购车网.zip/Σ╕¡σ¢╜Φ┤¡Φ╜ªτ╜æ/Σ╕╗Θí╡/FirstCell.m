//
//  FirstCell.m
//  网易新闻
//
//  Created by qianfeng on 13-3-3.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "FirstCell.h"
#import "MainTableViewImageItem.h"
#import "UIImageView+WebCache.h"

@implementation FirstCell
@synthesize imageArray;

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier withArray:(NSArray *)array{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.imageArray=array;
        UIView *view=[self CellView];
        [self.contentView addSubview:view];
    }
    return self;
    
}

-(void)changeImage:(id *)sender{
    static int i=0;
    i++;
    if(i==imageArray.count)
        i=0;
    UIImageView *theOne=[sv.subviews objectAtIndex:i];
    [sv scrollRectToVisible:theOne.frame animated:YES];
    
}

-(UIView *)CellView{
    CGRect rect=CGRectMake(0, 0, 320, 180);
    UIView *showView=[[UIView alloc]initWithFrame:rect];
    showView.backgroundColor=[UIColor clearColor];
    
    sv=[[UIScrollView alloc]initWithFrame:rect];
    sv.contentSize=CGSizeMake(rect.size.width*imageArray.count, rect.size.height);
    sv.delegate=self;
    sv.pagingEnabled=YES;
    sv.showsVerticalScrollIndicator=NO;
    sv.showsHorizontalScrollIndicator=NO;
    sv.alwaysBounceHorizontal=YES;
    sv.alwaysBounceVertical=YES;
    sv.bounces=YES;
    [showView addSubview:sv];
    
    for (int i=0; i<imageArray.count; i++) {
        rect.origin.x=i*rect.size.width;
        UIView *View=[[UIView alloc]initWithFrame:rect];
        UIImageView *imView=[[UIImageView alloc]initWithFrame:View.bounds];
        MainTableViewImageItem *item=[imageArray objectAtIndex:i];
        [imView setImageWithURL:[NSURL URLWithString:item.tableViewimage]];
        [View addSubview:imView];
        [imView release];
        
        UIView *tipView=[[UIView alloc]initWithFrame:CGRectMake(0, 145, 320, 35)];
        [tipView setBackgroundColor:[UIColor blackColor]];
        [tipView setAlpha:0.8];
        tipView.backgroundColor=[UIColor darkGrayColor];
        
        
        UILabel *title=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 320, 35)];
        title.textAlignment=UITextAlignmentCenter;
        title.backgroundColor=[UIColor clearColor];
        [title setFont:[UIFont boldSystemFontOfSize:15.0]];
        [title setTextColor:[UIColor whiteColor]];
        title.text=item.tableViewimagemessage;
        [tipView addSubview:title];
        [imView addSubview:tipView];
        [tipView release];
        [sv addSubview:View];
        if (i==imageArray.count-1) {
            [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(changeImage:) userInfo:nil repeats:YES];
        }
    }
    
    return showView;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
       // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
   
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
