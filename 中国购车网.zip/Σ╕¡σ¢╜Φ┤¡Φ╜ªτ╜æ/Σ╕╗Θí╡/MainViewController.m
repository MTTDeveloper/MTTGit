//
//  MainViewController.m
//  中国购车网
//
//  Created by qianfeng on 13-3-8.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "MainViewController.h"
#import "UIImage+UIImageExtras.h"
#import "MainTableViewCell.h"
#import "MainTableViewItem.h"
#import "HttpDownload.h"
#import "UIImageView+WebCache.h"
#import "MainTableViewImageItem.h"
#import "FirstCell.h"
#import "SBJson.h"
#import "DGViewController.h"
#import "ZXViewController.h"
#import "PCViewController.h"
#import "HQViewController.h"
#import "MainSecondViewController.h"
#import "MainSelectViewController.h"
#import "SearchViewController.h"

@implementation MainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        UIImage *tabimage=[UIImage imageNamed:@"h1.png"];
        UIImage *tabUnimage=[UIImage imageNamed:@"k1.png"];
        CGSize size=CGSizeMake(30, 30);
        self.tabBarItem =[[UITabBarItem alloc]initWithTitle:@"主页" image:[tabimage imageByScalingToSize:size] tag:1];
        [self.tabBarItem setFinishedSelectedImage:[tabUnimage imageByScalingToSize:size] withFinishedUnselectedImage:[tabimage imageByScalingToSize:size]];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)downloadComplete:(HttpDownload *)hd{
    if (hd.tag==1) {
        //NSLog(@"图片下载");
        [mainTopImageArray removeAllObjects];
        NSString *str=[[NSString alloc]initWithData:hd.mData encoding:NSUTF8StringEncoding];
        str=[str substringFromIndex:1];
        str=[str substringToIndex:str.length-1];
        NSDictionary *imagedict=[str JSONValue];
        if (imagedict) {
            NSArray *itemArray=[imagedict objectForKey:@"items"];
            for (NSDictionary *subdict in itemArray) {
                MainTableViewImageItem *imageItem=[[MainTableViewImageItem alloc]init];
                imageItem.tableViewimage=[subdict objectForKey:@"thumbnail"];
                imageItem.tableViewimagemessage=[subdict objectForKey:@"title"];
                [mainTopImageArray addObject:imageItem];
                [imageItem release];
            }
        }
    }else if(hd.tag==2){
        [mainDataArray removeAllObjects];
        NSString *str = [[NSString alloc] initWithData:hd.mData encoding:NSUTF8StringEncoding];
        str = [str substringFromIndex:1];
        str = [str substringToIndex:str.length - 1];
        //NSLog(@"%@", str);
        NSDictionary *dict = [str JSONValue];
        //NSLog(@"%@", dict);
        if (dict) 
        {
            //NSLog(@"Parse Data");
            NSArray *itemArray = [dict objectForKey:@"items"];
            for (NSDictionary *subdict in itemArray) 
            {
                MainTableViewItem *item =[[MainTableViewItem alloc]init];
                item.tableviewcelltitleLable=[subdict objectForKey:@"title"];
                item.tableviewcellmessageLable=[subdict objectForKey:@"digest"];
                item.tableviewcellImage=[subdict objectForKey:@"thumbnail"];
                item.MaintableViewCellId=[subdict objectForKey:@"id"];
                [mainDataArray addObject:item];
                //NSLog(@"%d",mainDataArray.count);
                [item release];
            }
            isLoading=NO;
            [refreshView egoRefreshScrollViewDataSourceDidFinishedLoading:myTableView];
            [myTableView reloadData];
        }
    }
}

-(void)createButton{
    UIView *buttonView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 320, 30)];
    buttonView.backgroundColor=[UIColor grayColor];
    [self.view addSubview:buttonView];
    NSArray *nameArray=[NSArray arrayWithObjects:@"导购",@"咨询",@"评测",@"行情", nil];
    for (int i=0; i<nameArray.count; i++) {
        UIButton *button =[UIButton buttonWithType:UIButtonTypeRoundedRect];
        button.frame=CGRectMake(80*i, 0, 80, 30);
        button.backgroundColor=[UIColor whiteColor];
        [button setTitle:[nameArray objectAtIndex:i] forState:UIControlStateNormal];
        button.tag=i;
        [button addTarget:self action:@selector(pressButton:) forControlEvents:UIControlEventTouchUpInside];
        [buttonView addSubview:button];
        //NSLog(@"%@",[nameArray objectAtIndex:i]);
    }
}

-(void)pressButton:(UIButton *)button{
    if (button.tag==0) {
        DGViewController *dgvc=[[DGViewController alloc]init];
        [self.navigationController pushViewController:dgvc animated:YES];
    }else if(button.tag==1){
        ZXViewController *zxvc=[[ZXViewController alloc]init];
        [self.navigationController pushViewController:zxvc animated:YES];
    }else if(button.tag==2){
        PCViewController *pcvc=[[PCViewController alloc]init];
        [self.navigationController pushViewController:pcvc animated:YES];
    }else{
        HQViewController *hqvc=[[HQViewController alloc]init];
        [self.navigationController pushViewController:hqvc animated:YES];
    }
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 */

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row==0) {
        NSLog(@"点击第一个cell");
    }else if(indexPath.row==mainDataArray.count+1){
        NSLog(@"点击文字");
    }else{
//        MainSecondViewController *mainSecondVc=[[MainSecondViewController alloc]initWithNibName:@"MainSecondViewController" bundle:nil];
//        MainTableViewItem *item=[mainDataArray objectAtIndex:indexPath.row-1];
//        mainSecondVc.mainsecondViewId=item.MaintableViewCellId;
//        [self.navigationController pushViewController:mainSecondVc animated:YES];
//        [mainSecondVc release];
        MainSelectViewController *msvc=[[MainSelectViewController alloc]init];
        MainTableViewItem *item=[mainDataArray objectAtIndex:indexPath.row-1];
        msvc.mainsecondViewId=item.MaintableViewCellId;
        [self.navigationController pushViewController:msvc animated:YES];
        [msvc release];
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return mainDataArray.count+1+1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        return 180;
    }else if(indexPath.row==mainDataArray.count+1){
        return 44;
    }else{
        return 90;
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        FirstCell *cell=[[FirstCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell" withArray:mainTopImageArray];
        return cell;
    }else if(indexPath.row!=mainDataArray.count+1){
    MainTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"MainTableViewCell"];
    if (cell==nil) {
        cell=[[[NSBundle mainBundle]loadNibNamed:@"MainTableViewCell" owner:nil options:nil]lastObject];
    }
    
    MainTableViewItem *item=[mainDataArray objectAtIndex:indexPath.row-1];
    cell.TableViewCellMessageLable.text=item.tableviewcellmessageLable;
        cell.TableViewCellMessageLable.numberOfLines=0;
    cell.TableViewCellTitleLable.text=item.tableviewcelltitleLable;
    [cell.TableViewCellImage setImageWithURL:[NSURL URLWithString:item.tableviewcellImage]];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    return cell;
    }else{
        UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"ID"];
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"];
        }
        if (page==2) {
            cell.textLabel.text=@"全部加载完毕";
        }else{
            cell.textLabel.text=@"正在加载中......";
        }
        cell.textLabel.font=[UIFont boldSystemFontOfSize:18];
        cell.textLabel.textAlignment=UITextAlignmentCenter;
        //cell.selectionStyle=UITableViewCellSelectionStyleNone;
        return cell;
    }
}

-(void)ToSearch{
    SearchViewController *sVc=[[SearchViewController alloc]init];
    [self.navigationController pushViewController:sVc animated:YES];
    [sVc release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    mainDataArray =[[NSMutableArray alloc]init];
    mainTopImageArray =[[NSMutableArray alloc]init];
    //[[NSBundle mainBundle] pathForResource:@"" ofType:@""];
    UIImage *navimage=[UIImage imageNamed:@"bg_top.jpg"];
    CGSize imagesize=CGSizeMake(320, 44);
    [self.navigationController.navigationBar setBackgroundImage:[navimage imageByScalingToSize:imagesize] forBarMetrics:UIBarMetricsDefault];
    UIImageView *image=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"logo.png"]];
    image.frame=CGRectMake(0, 0, 140, 44);
    self.navigationItem.titleView=image;
    [image release];
    UIButton *rightButton=[UIButton buttonWithType:UIButtonTypeCustom];
    rightButton.frame=CGRectMake(0, 0, 50, 30);
    [rightButton addTarget:self action:@selector(ToSearch) forControlEvents:UIControlEventTouchUpInside];
    [rightButton setImage:[UIImage imageNamed:@"head_09.jpg"] forState:UIControlStateNormal];
    UIBarButtonItem *rightBarButton=[[UIBarButtonItem alloc]initWithCustomView:rightButton];
    //self.navigationItem.rightBarButtonItem=rightBarButton;
    [rightBarButton release];
    
    [self createButton];

    
    NSString *urlTopImageStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexbanner.php?w=90"];
    NSURL *urlTopImage=[NSURL URLWithString:urlTopImageStr];
    HttpDownload *httpdownload1=[[HttpDownload alloc]init];
    httpdownload1.delegate=self;
    httpdownload1.tag=1;
    [httpdownload1 downloadFormUrlWithAsi:urlTopImage];
    
    page=0;
    number=15;
    NSString *urlTableViewStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexarticlec.php?w=90&p=%d&n=%d",page,number];
    NSURL *urlTableView=[NSURL URLWithString:urlTableViewStr];
    httpdownload2=[[HttpDownload alloc]init];
    httpdownload2.delegate=self;
    httpdownload2.tag=2;
    [httpdownload2 downloadFormUrlWithAsi:urlTableView];
    
    
    myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 30, 320, 460-44-44-30) style:UITableViewStylePlain];
    myTableView.dataSource=self;
    myTableView.delegate=self;
    [self.view addSubview:myTableView];
    
    refreshView=[[EGORefreshTableHeaderView alloc]initWithFrame:CGRectMake(0, -myTableView.frame.size.height, myTableView.frame.size.width, myTableView.frame.size.height)];
    [myTableView addSubview:refreshView];
    refreshView.delegate=self;
    [refreshView refreshLastUpdatedDate];
    
}

-(BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView *)view{
    return isLoading;
}

-(void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView *)view{
    isLoading=YES;
    if (page<2) {
        page++;
    }
    NSString *urlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexarticlec.php?w=90&p=%d&n=%d",page,number];
    NSURL *url=[NSURL URLWithString:urlStr];
    [httpdownload2 downloadFormUrlWithAsi:url];
}

-(NSDate *)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView *)view{
    return [NSDate date];
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    [refreshView egoRefreshScrollViewDidScroll:scrollView];
    CGPoint contentOffsetPoint=scrollView.contentOffset;
    CGRect frame=myTableView.frame;
    if (contentOffsetPoint.y==myTableView.contentSize.height-frame.size.height||myTableView.contentSize.height<frame.size.height) {
        if (page<2) {
            page++;
        }
        NSString *urlStr=[NSString stringWithFormat:@"http://app.caeac.cn/500e3e36751ddbd14b000000/api/indexarticlec.php?w=90&p=%d&n=%d",page,number];
        NSURL *url=[NSURL URLWithString:urlStr];
        [httpdownload2 downloadFormUrlWithAsi:url];
        
    }

}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    [refreshView egoRefreshScrollViewDidEndDragging:scrollView];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
