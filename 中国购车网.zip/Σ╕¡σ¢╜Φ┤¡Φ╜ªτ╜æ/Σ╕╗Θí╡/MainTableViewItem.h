//
//  MainTableViewItem.h
//  中国购车网
//
//  Created by qianfeng on 13-3-9.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MainTableViewItem : NSObject
@property (nonatomic,retain)NSString *tableviewcellImage;
@property (nonatomic,retain)NSString *tableviewcelltitleLable;
@property (nonatomic,retain)NSString *tableviewcellmessageLable;
@property (nonatomic,retain)NSString *MaintableViewCellId;
@end
