//
//  HQSelectVC.h
//  中国购车网
//
//  Created by qianfeng on 13-3-18.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpDownloadDelegate.h"

@interface HQSelectVC : UIViewController<UITableViewDataSource,UITableViewDelegate,HttpDownloadDelegate,UIWebViewDelegate>
{
    UITableView *myTableView;
    UIWebView *view;
}
@property (nonatomic,retain)NSString *HQSelectId;
@property (nonatomic,retain)NSString *HQSelectTitle;
@property (nonatomic,retain)NSString *HQSelectDate;
@property (nonatomic,retain)NSString *HQSelectMessage;
@end
