//
//  HQViewCell.h
//  中国购车网
//
//  Created by qianfeng on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HQViewCell : UITableViewCell
@property (retain, nonatomic) IBOutlet UIImageView *hqimage;
@property (retain, nonatomic) IBOutlet UILabel *hqViewtitleLable;
@property (retain, nonatomic) IBOutlet UILabel *hqViewmessageLable;

@end
