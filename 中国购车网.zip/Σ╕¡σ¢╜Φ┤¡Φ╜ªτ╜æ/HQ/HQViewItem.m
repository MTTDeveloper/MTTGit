//
//  HQViewItem.m
//  中国购车网
//
//  Created by qianfeng on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "HQViewItem.h"

@implementation HQViewItem
@synthesize HQImage,HQTitleText,HQMessageText,HQId;
-(void)dealloc{
    self.HQImage=nil;
    self.HQMessageText=nil;
    self.HQTitleText=nil;
    self.HQId=nil;
    [super dealloc];
}
@end
