//
//  HQViewItem.h
//  中国购车网
//
//  Created by qianfeng on 13-3-12.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HQViewItem : NSObject
@property (nonatomic,retain)NSString *HQImage;
@property (nonatomic,retain)NSString *HQTitleText;
@property (nonatomic,retain)NSString *HQMessageText;
@property (nonatomic,retain)NSString *HQId;
@end
