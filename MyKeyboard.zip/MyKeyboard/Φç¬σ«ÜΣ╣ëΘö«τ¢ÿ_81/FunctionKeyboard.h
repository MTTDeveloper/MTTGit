//
//  FunctionKeyboard.h
//  自定义键盘_81
//
//  Created by Roberts on 15/10/9.
//  Copyright (c) 2015年 iBokan Wisdom. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^FKB)(NSInteger index);

@interface FunctionKeyboard : UIView

@property (strong, nonatomic) FKB funcKBlockHandle;

@end
