//
//  MyTextView.h
//  自定义键盘_81
//
//  Created by Roberts on 15/10/9.
//  Copyright (c) 2015年 iBokan Wisdom. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum : NSUInteger
{
    KeyboardTypeSystem,
    KeyboardTypeFunction,
    KeyboardTypeFace,
}KeyboardType;

@protocol MyTextViewDelegate;

@interface MyTextView : UITextView

@property (weak, nonatomic) id<MyTextViewDelegate>myDelegate;

// 改变键盘的方法
- (void)changeKeyboardType:(KeyboardType)type;

@end

@protocol MyTextViewDelegate <NSObject>

// 点击了功能键盘的某个button回调
- (void)myTextView:(MyTextView *)textView didTapFunctionButtonIndex:(NSInteger)index;

@end



