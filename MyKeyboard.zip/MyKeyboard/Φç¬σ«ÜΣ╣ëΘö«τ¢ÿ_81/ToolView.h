//
//  ToolView.h
//  自定义键盘_81
//
//  Created by Roberts on 15/10/18.
//  Copyright © 2015年 iBokan Wisdom. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum : NSUInteger
{   //语言
    ToolViewTypeSpeaking,
    //字段
    ToolViewTypeTexting,
    //表情
    ToolViewTypeFace,
    //功能
    ToolViewTypeFunction,
}ToolViewType;
//功能键盘枚举
typedef enum : NSUInteger{
    FunctionPic,
    FunctionLocation,
    FunctionHongbao,
}Function;

typedef void(^TVSB)(NSString *text);
typedef void(^TVRB)(NSString *path);
typedef void(^TVFB)(Function f);

@interface ToolView : UIView
//发送文字
@property (strong, nonatomic) TVSB sendBlockHandle;
//录音
@property (strong, nonatomic) TVRB recordBlockHandle;
//点击功能
@property (strong, nonatomic) TVFB functionBlockHandle;
//改变toolView样式
- (void)changeToolViewType:(ToolViewType)type;
//恢复默认
- (void)changeNormal;

@end
