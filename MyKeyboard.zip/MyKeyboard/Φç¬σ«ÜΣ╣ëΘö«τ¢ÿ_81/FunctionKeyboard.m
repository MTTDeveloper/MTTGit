//
//  FunctionKeyboard.m
//  自定义键盘_81
//
//  Created by Roberts on 15/10/9.
//  Copyright (c) 2015年 iBokan Wisdom. All rights reserved.
//

#import "FunctionKeyboard.h"

//@interface FunctionKeyboard ()
//
//@property (strong, nonatomic) TextViewController *textVc;
//
//@end

@implementation FunctionKeyboard

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        // 在此处初始化功能键盘View的界面
        // 首先创建添加图片button
        UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
        button1.frame = CGRectMake(20, 20, 44, 44);
        button1.backgroundColor = [UIColor redColor];
        [button1 setTitle:@"图片" forState:UIControlStateNormal];
        button1.tag = 1;
        [self addSubview:button1];
        [button1 addTarget:self action:@selector(tapButtonIndex:) forControlEvents:UIControlEventTouchUpInside];
        
        UIButton *button2 = [UIButton buttonWithType:UIButtonTypeCustom];
        button2.frame = CGRectMake(74, 20, 44, 44);
        button2.backgroundColor = [UIColor redColor];
        [button2 setTitle:@"位置" forState:UIControlStateNormal];
        button2.tag = 2;
        [self addSubview:button2];
        [button2 addTarget:self action:@selector(tapButtonIndex:) forControlEvents:UIControlEventTouchUpInside];
        
//        button2.currentImage
        
        UIButton *button3 = [UIButton buttonWithType:UIButtonTypeCustom];
        button3.frame = CGRectMake(128, 20, 44, 44);
        button3.backgroundColor = [UIColor redColor];
        [button3 setTitle:@"红包" forState:UIControlStateNormal];
        [button3 addTarget:self action:@selector(tapButtonIndex:) forControlEvents:UIControlEventTouchUpInside];
        button3.tag = 3;
        [self addSubview:button3];
        
    }
    return self;
}

- (void)tapButtonIndex:(UIButton *)btn
{
    NSLog(@"当前点击了%ld",btn.tag);
    if (self.funcKBlockHandle)
    {
        self.funcKBlockHandle(btn.tag);
    }
    
//    if (!self.textVc)
//    {
//        self.textVc = [[TextViewController alloc] init];
//    }
}

@end
