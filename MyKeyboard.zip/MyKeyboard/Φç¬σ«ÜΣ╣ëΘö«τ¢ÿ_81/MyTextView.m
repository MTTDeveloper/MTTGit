//
//  MyTextView.m
//  自定义键盘_81
//
//  Created by Roberts on 15/10/9.
//  Copyright (c) 2015年 iBokan Wisdom. All rights reserved.
//

#import "MyTextView.h"
#import "FunctionKeyboard.h"
#import "FaceKeyboard.h"
#import "RecentFace.h"

#define MWIDTH [UIScreen mainScreen].bounds.size.width
#define MHEIGH [UIScreen mainScreen].bounds.size.height

@interface MyTextView ()<FaceKeyboardDelegate,FaceKeyboardDataSource>

@property (strong, nonatomic) FunctionKeyboard *functionKB;
@property (strong, nonatomic) FaceKeyboard *faceKB;
@property (strong, nonatomic) NSArray *faces;
@property (strong, nonatomic) NSManagedObjectContext *context;

@end

@implementation MyTextView

// 重写init方法
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        
        // 获取当前应用程序对象
        UIApplication *app = [UIApplication sharedApplication];
        // 获取当前应用程序的委托
        id delegate = app.delegate;
        // 获取上下文
        self.context = [delegate managedObjectContext];
        
        
        // 获取plist文件
        // 首先从bundle目录下获取plist文件路径
        NSString *path = [[NSBundle mainBundle] pathForResource:@"emoticons" ofType:@"plist"];
        // 将plist文件写入数组中
        self.faces = [NSArray arrayWithContentsOfFile:path];
        
        // 初始化功能键盘view
        self.functionKB = [[FunctionKeyboard alloc] initWithFrame:CGRectMake(0, 0, MWIDTH, MHEIGH/3)];
        self.functionKB.backgroundColor = [UIColor groupTableViewBackgroundColor];
        
//        __weak typeof(self) copy_self = self;
        __weak __block MyTextView *copy_self = self;
        self.functionKB.funcKBlockHandle = ^(NSInteger index)
        {
            // 判断是否实现了回调方法
            if ([copy_self.myDelegate respondsToSelector:@selector(myTextView:didTapFunctionButtonIndex:)])
            {
                [copy_self.myDelegate myTextView:copy_self didTapFunctionButtonIndex:index];
            }
        };
        
//        // 判断当前类的对象是否遵循了某个协议
//        self conformsToProtocol:<#(Protocol *)#>
//        // 判断当前类的对象是否是实现了某个方法
//        self respondsToSelector:<#(SEL)#>
        
        // 初始化表情键盘view
        self.faceKB = [[FaceKeyboard alloc] initWithFrame:CGRectMake(0, 0, MWIDTH, MHEIGH/3)];
        self.faceKB.backgroundColor = [UIColor blueColor];
        // 指定委托
        self.faceKB.delegate = self;
        self.faceKB.dataSource = self;
        
    }
    return self;
}

// 回调当前某个表情被点击
- (void)faceKeyboard:(FaceKeyboard *)faceKB didTapFacesButtonIndex:(NSInteger)buttonIndex
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:NSStringFromClass([RecentFace class])];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"faceIndex = %ld",buttonIndex];
    [request setPredicate:predicate];
    
    // 执行查询
    NSArray *result = [self.context executeFetchRequest:request error:nil];
    if (result.count == 0)
    {
        // 如果没有，则创建
        // 将选中的表情保存到coreData上下文中
        RecentFace *face = [NSEntityDescription insertNewObjectForEntityForName:NSStringFromClass([RecentFace class]) inManagedObjectContext:self.context];
        face.faceIndex = [NSString stringWithFormat:@"%ld",buttonIndex];
        face.date = [NSDate date];
        
        [self.context save:nil];
    }
    else
    {
        RecentFace *face = [result lastObject];
        face.date = [NSDate date];
        [self.context save:nil];
    }
  
    
//    NSDictionary *dic = self.faces[buttonIndex];
//    NSString *imageName = dic[@"png"];
//    UIImage *image = [UIImage imageNamed:imageName];
    
    UIImage *image = [self faceKeyboard:self.faceKB imageOfButtonIndex:buttonIndex];
    
    // 创建NSMuatableAttributedString类型的对象
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithAttributedString:self.attributedText];
    
    // 创建一个附件
    NSTextAttachment *attach = [[NSTextAttachment alloc] init];
    attach.image = image;
    // 将attach转换成NSAttributedString类型
    NSAttributedString *attributed = [NSAttributedString attributedStringWithAttachment:attach];
    [attributedString appendAttributedString:attributed];
    
    // 显示
    self.attributedText = attributedString;
}
// data Source Mothes 实现数据源委托
- (NSInteger)numberOfFacesInFaceKeyboard:(FaceKeyboard *)faceKB
{
    return self.faces.count;
}

// 返回每个当前button上的image
- (UIImage *)faceKeyboard:(FaceKeyboard *)faceKB imageOfButtonIndex:(NSInteger)index
{
    NSDictionary *dict = self.faces[index];
    NSString *imageName = dict[@"png"];
    UIImage *image = [UIImage imageNamed:imageName];
    return image;
}


// 实现改变键盘的方法
- (void)changeKeyboardType:(KeyboardType)type
{
    switch (type) {
        case KeyboardTypeSystem:
            // 让inputView为nil，因为默认就是系统的键盘
            self.inputView = nil;
            break;
        case KeyboardTypeFunction:
            // 让inputView为Function键盘
            self.inputView = self.functionKB;
            break;
        case KeyboardTypeFace:
            // 让inputView为face键盘
            self.inputView = self.faceKB;
            break;
            
        default:
            break;
    }
    if ([self isFirstResponder])
    {   //刷新
        [self reloadInputViews];
    }
    else
    {   //将当前样式的键盘注册成为第一响应者
        [self becomeFirstResponder];
    }
}

@end
