//
//  FaceKeyboard.h
//  自定义键盘_81
//
//  Created by Roberts on 15/10/9.
//  Copyright (c) 2015年 iBokan Wisdom. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol FaceKeyboardDelegate;
@protocol FaceKeyboardDataSource;

@interface FaceKeyboard : UIView

@property (weak, nonatomic) id<FaceKeyboardDelegate>delegate;
@property (weak, nonatomic) id<FaceKeyboardDataSource>dataSource;

@end


@protocol FaceKeyboardDelegate <NSObject>

@optional
// 当点击某个表情时回调此方法
- (void)faceKeyboard:(FaceKeyboard *)faceKB didTapFacesButtonIndex:(NSInteger)buttonIndex;

@end

@protocol FaceKeyboardDataSource <NSObject>
// 指定当前有多少表情需要展示
// 返回一个数据
- (NSInteger)numberOfFacesInFaceKeyboard:(FaceKeyboard *)faceKB;

// 用于返回当前表情按钮上的image
// 返回一个image对象
- (UIImage *)faceKeyboard:(FaceKeyboard *)faceKB imageOfButtonIndex:(NSInteger)index;

@end
