//
//  main.m
//  自定义键盘_81
//
//  Created by Roberts on 15/10/9.
//  Copyright (c) 2015年 iBokan Wisdom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
