//
//  ToolView.m
//  自定义键盘_81
//
//  Created by Roberts on 15/10/18.
//  Copyright © 2015年 iBokan Wisdom. All rights reserved.
//

#import "ToolView.h"
#import "MyTextView.h"

@interface ToolView ()

@property (strong, nonatomic) MyTextView *textView;
@property (strong, nonatomic) UIButton *speakBtn;// 语音按钮
@property (strong, nonatomic) UIButton *recordBtn;// 录音按钮
@property (strong, nonatomic) UIButton *faceBtn;// 表情按钮
@property (strong, nonatomic) UIButton *functionBtn;// 功能按钮
@property (strong, nonatomic) UILongPressGestureRecognizer *longpress;// 长按手势
@property (strong, nonatomic) UITapGestureRecognizer *tapGesture;// textView的点击手势

@end

@implementation ToolView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        [self creatUI];
    }
    return self;
}

- (void)creatUI
{
    // 初始化界面
    // 语音按钮
    self.speakBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.speakBtn setImage:[UIImage imageNamed:@"voice"] forState:UIControlStateNormal];
    self.speakBtn.tag = 1;
    [self.speakBtn setTitleColor:[UIColor magentaColor] forState:UIControlStateNormal];
    [self.speakBtn addTarget:self action:@selector(tapSpeakBtn:) forControlEvents:UIControlEventTouchUpInside];
    self.speakBtn.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:self.speakBtn];
    
    // 功能按钮
    self.functionBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.functionBtn setImage:[UIImage imageNamed:@"func.png"] forState:UIControlStateNormal];
    self.functionBtn.tag = 2;
    [self.functionBtn setTitleColor:[UIColor magentaColor] forState:UIControlStateNormal];
    [self.functionBtn addTarget:self action:@selector(tapFunctionBtn:) forControlEvents:UIControlEventTouchUpInside];
    self.functionBtn.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:self.functionBtn];
    
    // 表情按钮
    self.faceBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.faceBtn setImage:[UIImage imageNamed:@"face.png"] forState:UIControlStateNormal];
    self.faceBtn.tag = 3;
    [self.faceBtn setTitleColor:[UIColor magentaColor] forState:UIControlStateNormal];
    [self.faceBtn addTarget:self action:@selector(tapFaceBtn:) forControlEvents:UIControlEventTouchUpInside];
    self.faceBtn.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:self.faceBtn];
    
    // textView
    self.textView = [[MyTextView alloc] init];
    self.textView.translatesAutoresizingMaskIntoConstraints = NO;
    self.textView.backgroundColor = [UIColor whiteColor];
    self.textView.layer.cornerRadius = 6;
    self.textView.font = [UIFont systemFontOfSize:16];
    [self addSubview:self.textView];
    // 为textView添加点击手势
    self.tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapTextViewGesture:)];
    [self.textView addGestureRecognizer:self.tapGesture];
    
    // 录音按钮
    self.recordBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.recordBtn.translatesAutoresizingMaskIntoConstraints = NO;
    self.recordBtn.backgroundColor = [UIColor whiteColor];
    [self.recordBtn setTitle:@"按 住 录 音" forState:UIControlStateNormal];
    self.recordBtn.layer.cornerRadius = 6;
    [self.recordBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [self addSubview:self.recordBtn];
    // 为record按钮添加长按手势
    self.longpress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(tapLongpressGesture:)];
    [self.recordBtn addGestureRecognizer:self.longpress];
    
    
    // 添加约束
    NSDictionary * dic = NSDictionaryOfVariableBindings(_speakBtn,_recordBtn,_functionBtn,_faceBtn,_textView);
    //添加有录音按钮的水平方向约束
    NSString * HH = @"H:|-8-[_speakBtn(35)]-10-[_recordBtn]-10-[_faceBtn(35)]-8-[_functionBtn(35)]-10-|";
    NSArray * c = [NSLayoutConstraint constraintsWithVisualFormat:HH options:0 metrics:nil views:dic];
    [self addConstraints:c];
    self.recordBtn.hidden = YES;
    //添加有textView的水平方向约束
    NSString * HHH = @"H:|-10-[_speakBtn(35)]-10-[_textView]-10-[_faceBtn(35)]-8-[_functionBtn(35)]-10-|";
    NSArray * c1 = [NSLayoutConstraint constraintsWithVisualFormat:HHH options:0 metrics:nil views:dic];
    [self addConstraints:c1];
    //添加语音按钮竖直方向的约束
    NSString * spBV = @"V:|-4-[_speakBtn(35)]";
    NSArray * c2 = [NSLayoutConstraint constraintsWithVisualFormat:spBV options:0 metrics:nil views:dic];
    [self addConstraints:c2];
    //添加功能按钮竖直方向的约束
    NSString * funcBV = @"V:|-4-[_functionBtn(35)]";
    NSArray * c4 = [NSLayoutConstraint constraintsWithVisualFormat:funcBV options:0 metrics:nil views:dic];
    [self addConstraints:c4];
    //添加表情按钮竖直方向的约束
    NSString * faceBV = @"V:|-4-[_faceBtn(35)]";
    NSArray * c6 = [NSLayoutConstraint constraintsWithVisualFormat:faceBV options:0 metrics:nil views:dic];
    [self addConstraints:c6];
    //添加textView竖直方向的约束
    NSString * tvV = @"V:|-5-[_textView]-5-|";
    NSArray * c8 = [NSLayoutConstraint constraintsWithVisualFormat:tvV options:0 metrics:nil views:dic];
    [self addConstraints:c8];
    //添加录音按钮竖直方向的约束
    NSString * rcBV = @"V:|-5-[_recordBtn]-5-|";
    NSArray * c10 = [NSLayoutConstraint constraintsWithVisualFormat:rcBV options:0 metrics:nil views:dic];
    [self addConstraints:c10];

}


#pragma mark 录音按钮点击触发事件
- (void)tapSpeakBtn:(UIButton *)btn
{
    // 通过tag值判断当前按钮的状态
    if (btn.tag == 1)
    {
        [self changeToolViewType:ToolViewTypeSpeaking];
    }
    else
    {
        [self changeToolViewType:ToolViewTypeTexting];
    }
}

#pragma mark 功能按钮点击触发事件
- (void)tapFunctionBtn:(UIButton *)btn
{
    if (btn.tag == 2)
    {
        [self changeToolViewType:ToolViewTypeFunction];
    }
    else
    {
        [self changeToolViewType:ToolViewTypeTexting];
    }
}

#pragma mark 表情按钮触发事件
- (void)tapFaceBtn:(UIButton *)btn
{
    if (btn.tag == 3)
    {
        [self changeToolViewType:ToolViewTypeFace];
    }
    else
    {
        [self changeToolViewType:ToolViewTypeTexting];
    }
}

// ToolView改变键盘样式
- (void)changeToolViewType:(ToolViewType)type
{
    switch (type) {
        case ToolViewTypeFace:
        {
            // 让所有按钮恢复正常
            [self changeNormal];
            // 改变facebutton上的图片
            [self.faceBtn setImage:[UIImage imageNamed:@"keyboard.png"] forState:UIControlStateNormal];
            // 调用MyTextView改变键盘样式
            [self.textView changeKeyboardType:KeyboardTypeFace];
            // 为btn设置新的tag值
            self.faceBtn.tag = 4;
            break;
        }
        case ToolViewTypeFunction:
        {
            [self changeNormal];
            [self.functionBtn setImage:[UIImage imageNamed:@"keyboard.png"] forState:UIControlStateNormal];
            [self.textView changeKeyboardType:KeyboardTypeFunction];
            self.functionBtn.tag = 4;
            break;
        }
        case ToolViewTypeSpeaking:
        {
            [self changeNormal];
            [self.speakBtn setImage:[UIImage imageNamed:@"keyboard.png"] forState:UIControlStateNormal];
            [self.textView endEditing:YES];
            // 隐藏textView
            self.textView.hidden = YES;
            // 让record按钮显示
            self.recordBtn.hidden = NO;
            self.speakBtn.tag = 4;
            break;
        }
        case ToolViewTypeTexting:
        {
            [self changeNormal];
            [self.textView changeKeyboardType:KeyboardTypeSystem];
            break;
        }
            
        default:
            break;
    }
}

#pragma mark 将toolView上的按钮恢复默认状态
- (void)changeNormal
{
    [self.faceBtn setImage:[UIImage imageNamed:@"face.png"] forState:UIControlStateNormal];
    [self.functionBtn setImage:[UIImage imageNamed:@"func.png"] forState:UIControlStateNormal];
    [self.speakBtn setImage:[UIImage imageNamed:@"voice.png"] forState:UIControlStateNormal];
    self.faceBtn.tag = 3;
    self.speakBtn.tag = 1;
    self.functionBtn.tag = 2;
    self.textView.hidden = NO;
    self.recordBtn.hidden = YES;
}

#pragma mark 录音方法
- (void)startRecord
{
    NSLog(@"开始录音");
}
- (void)endRecord
{
    NSLog(@"录音结束");
}

// 点击return发送文字
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"])
    {
        NSString *str = self.textView.text;// 需要发送的文字
        if (self.sendBlockHandle)
        {
            self.sendBlockHandle(str);
        }
    }
    return YES;
}


#pragma mark textView回调的手势方法
- (void)tapTextViewGesture:(UITapGestureRecognizer *)sender
{
    [self changeToolViewType:ToolViewTypeTexting];
}
//长按录音
- (void)tapLongpressGesture:(UILongPressGestureRecognizer *)sender
{
    if (sender.state == UIGestureRecognizerStateBegan)
    {
        [self startRecord];
    }
    else if (sender.state == UIGestureRecognizerStateEnded)
    {
        [self endRecord];
    }
}

@end
