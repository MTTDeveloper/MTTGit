//
//  FaceKeyboard.m
//  自定义键盘_81
//
//  Created by Roberts on 15/10/9.
//  Copyright (c) 2015年 iBokan Wisdom. All rights reserved.
//

#import "FaceKeyboard.h"
#import "RecentFace.h"

#define MWIDTH self.bounds.size.width
#define MHEIGH self.bounds.size.height

@interface FaceKeyboard ()

@property (strong, nonatomic) UIScrollView *scrollViewDefault;// 显示默认表情view
@property (strong, nonatomic) UIScrollView *scrollViewHistory;// 显示历史表情view
@property (strong, nonatomic) UIScrollView *scrollerViewButton;// 显示选择按钮view

@property (strong, nonatomic) NSManagedObjectContext *context;

@end

@implementation FaceKeyboard

// 重写init方法
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        // 获取当前应用程序的对象
        UIApplication *app = [UIApplication sharedApplication];
        id delegate = app.delegate;
        self.context = [delegate managedObjectContext];
        
        
        // 初始化表情键盘上的组件
        self.scrollViewDefault = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, MWIDTH, MHEIGH - 44)];
        self.scrollViewDefault.backgroundColor = [UIColor lightGrayColor];
        [self addSubview:self.scrollViewDefault];
        self.scrollViewDefault.pagingEnabled = YES;
        self.scrollViewDefault.showsHorizontalScrollIndicator = YES;
        self.scrollViewDefault.showsVerticalScrollIndicator = NO;
        
        self.scrollViewHistory = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, MWIDTH, MHEIGH - 44)];
        self.scrollViewHistory.backgroundColor = [UIColor yellowColor];
        [self addSubview:self.scrollViewHistory];
        // 隐藏历史表情view
        self.scrollViewHistory.hidden = YES;
        self.scrollViewHistory.pagingEnabled = YES;
        self.scrollViewHistory.showsHorizontalScrollIndicator = NO;
        self.scrollViewHistory.showsVerticalScrollIndicator = NO;
        
        self.scrollerViewButton = [[UIScrollView alloc] initWithFrame:CGRectMake(0, MHEIGH - 44, MWIDTH, 44)];
        self.scrollerViewButton.backgroundColor = [UIColor blackColor];
        [self addSubview:self.scrollerViewButton];
        
        // 创建历史表情按钮
        UIButton *button1 = [UIButton buttonWithType:UIButtonTypeCustom];
        button1.frame = CGRectMake(0, 0, MWIDTH/2, 44);
        button1.backgroundColor = [UIColor greenColor];
        [button1 setTitle:@"历史表情" forState:UIControlStateNormal];
        button1.tag = 1;
        [button1 addTarget:self action:@selector(tapButtonIndex:) forControlEvents:UIControlEventTouchUpInside];
        [self.scrollerViewButton addSubview:button1];
        
        // 创建默认按钮
        UIButton *button2 = [UIButton buttonWithType:UIButtonTypeCustom];
        button2.frame = CGRectMake(MWIDTH/2, 0, MWIDTH/2, 44);
        button2.backgroundColor = [UIColor orangeColor];
        [button2 setTitle:@"默认" forState:UIControlStateNormal];
        button2.tag = 2;
        [button2 addTarget:self action:@selector(tapButtonIndex:) forControlEvents:UIControlEventTouchUpInside];
        [self.scrollerViewButton addSubview:button2];
        
        // 用KVO监听数据源变化
        [self addObserver:self forKeyPath:@"dataSource" options:NSKeyValueObservingOptionNew context:nil];
        
        [self tapFaceButtonIndex:nil];
    }
    return self;
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    // 首先获取需要添加的表情总数
    int count = (int)[self.dataSource numberOfFacesInFaceKeyboard:self];
    NSLog(@"表情总数 ：%d",count);
    // 获取当前需要多少页来展示所有的表情
    int page = count/32;
    NSLog(@"需要页数：%d",page);
    // 指定scrollView的contentSize
    self.scrollViewDefault.contentSize = CGSizeMake(MWIDTH * 3, MHEIGH - 44);
    
    for (int i = 0; i < count; i++)
    {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.tag = i;
        
        // 计算当前button在第几页
        int section = (int)button.tag/32;
        // 计算在当前页的第几个位置
        int index = button.tag%32;
        // 计算在第几列
        int lie = index % 8;
        // 计算在第几行
        int row = index / 8;
        
//        // 每页的宽度
//        int w = self.frame.size.width;
        
        // 每个button的宽度
        int bW = self.frame.size.width / 8;
        // 计算当前button的X坐标
        CGFloat x = self.frame.size.width * section + bW * lie;
        // 计算当前button的Y坐标
        CGFloat y = row * bW;
        
        // 设置button的frame
        button.frame = CGRectMake(x, y, bW, bW);
        
        // 在button上添加表情
        // 首先获取到相对应的表情
        UIImage *image = [self.dataSource faceKeyboard:self imageOfButtonIndex:button.tag];
        [button setImage:image forState:UIControlStateNormal];
        
        // 将button添加到scrollView上
        [self.scrollViewDefault addSubview:button];
        
        [button addTarget:self action:@selector(tapFaceButtonIndex:) forControlEvents:UIControlEventTouchUpInside];
    }
}

#pragma mark 点击某个表情触发方法
- (void)tapFaceButtonIndex:(UIButton *)btn
{
    NSLog(@"点击了第%ld个表情",btn.tag);
    if ([self.delegate respondsToSelector:@selector(faceKeyboard:didTapFacesButtonIndex:)])
    {
        [self.delegate faceKeyboard:self didTapFacesButtonIndex:btn.tag];
    }
}
#pragma mark 点击button触发事件
- (void)tapButtonIndex:(UIButton *)btn
{
    if (btn.tag == 1)// 当前选择了历史表情按钮
    {
        // 隐藏默认view，显示历史表情view
        self.scrollViewHistory.hidden = NO;
        self.scrollViewDefault.hidden = YES;
        
        // 从上下文中获取表情
        NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:NSStringFromClass([RecentFace class])];
        // 添加一个排序规则
        NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"date" ascending:NO];// 设置为降序，则可以拿到最后的date
        [request setSortDescriptors:@[sort]];
        
        // 执行查询
        NSArray *result = [self.context executeFetchRequest:request error:nil];
        
        // 移除之前添加在view上的表情
        NSArray *arr = self.scrollViewHistory.subviews;
        for (UIView *view in arr)
        {
            [view removeFromSuperview];
        }
//        NSArray * subviews = self.scrollViewHistory.subviews;
//        [subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
        
        // 如果历史表情超过一页时，需要做下面的操作
        // 当前需要在历史表情view中展示的表情个数
        NSLog(@"从coreData 中获取的count ＝ %ld",result.count);
        // 计算需要多少页去展示
        NSInteger page = result.count/32 + 1;
        NSLog(@"需要%ld页显示",page);
        // 设置scrollView的contentSize
        self.scrollViewHistory.contentSize = CGSizeMake(MWIDTH * page, MHEIGH-44);
        
        for (int i = 0; i < result.count; i++)
        {
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            RecentFace *face = result[i];
            // 获取当前表情在表情键盘中的faceIndex
            button.tag = [face.faceIndex intValue];
            
            // 计算button在哪一页
            int section = i/32;
            // 计算button在当前页的什么位置
            int index = i%32;
            
            // 计算在当前页的第几列
            int lie = index%8;
            // 计算在当前页的第几行
            int row = index/8;
            
            // 每个button的宽度
            int BW = self.scrollViewHistory.frame.size.width/8;
            // 计算当前button的X和Y坐标
            CGFloat x = self.scrollViewHistory.frame.size.width * section + BW * lie;
            CGFloat y = row * BW;
            // 设置当前button的frame
            button.frame = CGRectMake(x, y, BW, BW);
            
            // 将表情添加到button上
            UIImage *image = [self.dataSource faceKeyboard:self imageOfButtonIndex:button.tag];// 此处的Index参数必须传递当前button上的表情在表情键盘上的faceIndex，否则获取不到准确的表情.
            [button setImage:image forState:UIControlStateNormal];
            
            [button addTarget:self action:@selector(tapFaceButtonIndex:) forControlEvents:UIControlEventTouchUpInside];
            
            // 将button添加到scrollerView上
            [self.scrollViewHistory addSubview:button];
            
        }
    }
    else if (btn.tag == 2)
    {
        self.scrollViewHistory.hidden = YES;
        self.scrollViewDefault.hidden = NO;
    }
}



@end
