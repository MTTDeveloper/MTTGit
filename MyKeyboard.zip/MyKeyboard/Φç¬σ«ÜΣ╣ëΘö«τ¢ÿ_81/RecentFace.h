//
//  RecentFace.h
//  自定义键盘_81
//
//  Created by Roberts on 15/10/9.
//  Copyright (c) 2015年 iBokan Wisdom. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface RecentFace : NSManagedObject

@property (nonatomic, retain) NSString * faceIndex;
@property (nonatomic, retain) NSDate * date;

@end
