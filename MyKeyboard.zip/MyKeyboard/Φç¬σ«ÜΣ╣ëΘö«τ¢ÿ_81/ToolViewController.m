//
//  ToolViewController.m
//  自定义键盘_81
//
//  Created by Roberts on 15/10/18.
//  Copyright © 2015年 iBokan Wisdom. All rights reserved.
//

#import "ToolViewController.h"
#import "ToolView.h"
#import "FunctionKeyboard.h"

@interface ToolViewController ()

@property (strong, nonatomic) ToolView *toolView;

@end

@implementation ToolViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
#pragma mark 初始化toolView
    self.toolView = [[ToolView alloc] initWithFrame:CGRectZero];
    self.toolView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    self.toolView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.toolView];
    
    // 给toolView添加约束
    NSString *tvH = @"H:|[_toolView]|";
    NSString *tvV = @"V:[_toolView(40)]|";
    NSArray *c1 = [NSLayoutConstraint constraintsWithVisualFormat:tvH options:0 metrics:nil views:NSDictionaryOfVariableBindings(_toolView)];
    NSArray *c2 = [NSLayoutConstraint constraintsWithVisualFormat:tvV options:0 metrics:nil views:NSDictionaryOfVariableBindings(_toolView)];
    [self.view addConstraints:c1];
    [self.view addConstraints:c2];
    
    
    // 接收键盘弹起的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveNoti:) name:UIKeyboardWillChangeFrameNotification object:nil];
}


- (void)receiveNoti:(NSNotification *)notification
{
    NSLog(@"noti:%@",notification.userInfo);
    
    NSDictionary *dic = notification.userInfo;
    // 键盘弹起后新的frame
    NSValue *value = dic[UIKeyboardFrameEndUserInfoKey];
    CGRect endFrame = [value CGRectValue];
    // 拿到当前屏幕的frame
    CGRect frame = self.view.frame;
    frame.size.height = endFrame.origin.y;
    self.view.frame = frame;
    // 重新加载自动布局
    [self.view layoutIfNeeded];
}



- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
