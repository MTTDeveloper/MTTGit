//
//  UITableViewCell+setinfo.m
//  显示微博（4种cell）
//
//  Created by 穆天泰 on 15/9/14.
//  Copyright (c) 2015年 穆天泰. All rights reserved.
//

#import "UITableViewCell+setinfo.h"

@implementation UITableViewCell (setinfo)

@end
