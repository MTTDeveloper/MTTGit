//
//  twitterManager.h
//  显示微博（4种cell）
//
//  Created by 穆天泰 on 15/9/14.
//  Copyright (c) 2015年 穆天泰. All rights reserved.
//

#import <Foundation/Foundation.h>
//此处用来传请求微博 请求下来的数组
typedef void(^weiboblock) (NSArray *arr);
//此处代码块用于传值（传是否发生成功的BOOL值）
typedef void(^SendWeiboBlock)(BOOL bl);
@interface twitterManager : NSObject
//单例（仅初始化一次）
+(instancetype)share;
//获取指定条数微博
-(void)gettwitterwithcount:(NSString *)count success:(weiboblock)block;
//获取微博评论
-(void)gettwitterwithcomments:(NSString *)weiboID success:(weiboblock)block;
//发送一条文字微博
-(void)sendWeiboWithStatus:(NSString *)status success:(SendWeiboBlock)block;
//发送微博(带图)
-(void)sendWeiboWithStatus:(NSString *)status Image:(NSData *)imageData success:(SendWeiboBlock)block;
//转发微博
-(void)zhuanFaWeiboWithWeiboID:(NSString *)WeiboID Status:(NSString *)status success:(SendWeiboBlock)block;
//评论微博
-(void)pinglunwithweiboID:(NSString *)WeiboID Status:
(NSString *)status success:(SendWeiboBlock)block;
@end
