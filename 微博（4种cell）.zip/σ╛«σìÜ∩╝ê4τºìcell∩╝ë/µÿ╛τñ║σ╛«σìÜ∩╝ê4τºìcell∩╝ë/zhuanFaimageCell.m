//
//  zhuanFaimageCell.m
//  显示微博（4种cell）
//
//  Created by 穆天泰 on 15/9/14.
//  Copyright (c) 2015年 穆天泰. All rights reserved.
//

#import "zhuanFaimageCell.h"
#import "UITableViewCell+setinfo.h"
#import "UIKit+AFNetworking.h"
@interface zhuanFaimageCell ()
@property (weak, nonatomic) IBOutlet UIImageView *headPortrait;
@property (weak, nonatomic) IBOutlet UILabel *myTextLabel;
@property (weak, nonatomic) IBOutlet UILabel *zhuanFaImage;
@property (weak, nonatomic) IBOutlet UIImageView *myImage;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

@property(strong,nonatomic) DidTapBlock tapBlockHandle;
@end
@implementation zhuanFaimageCell
- (void)awakeFromNib {
    // Initialization code
}
-(void)setCellInfo:(NSDictionary *)dic
{
    NSDateFormatter *formatter = [NSDateFormatter new];
    //注意要说明日期时间字符串格式
    [formatter setDateFormat:@"EEE MMM dd HH:mm:ss zzz yyyy"];
    NSDate *adate = [formatter dateFromString:dic[@"created_at"]];
    NSDate *nowDate = [NSDate date];
    NSTimeInterval timeInterval = [nowDate timeIntervalSinceDate:adate];
    NSLog(@"%2lf",timeInterval);
    if (timeInterval < 60) {
        self.timeLabel.text = @"刚刚";
    }else if(timeInterval < 3600){
        self.timeLabel.text = [NSString stringWithFormat:@"%d分钟前",(int)timeInterval/60];
    }else {
        self.timeLabel.text = [NSString stringWithFormat:@"%d小时前",(int)timeInterval/3600];
    }
    self.myTextLabel.text = dic[@"text"];
    [self.headPortrait setImageWithURL:[NSURL URLWithString:dic[@"user"][@"profile_image_url"]]];
    [self.myImage setImageWithURL:[NSURL URLWithString:dic[@"retweeted_status"][@"thumbnail_pic"]]];
    self.zhuanFaImage.text=dic[@"retweeted_status"][@"text"];
    [self.contentView layoutIfNeeded];
}
//传tag值的方法
- (IBAction)tapButton:(UIButton *)sender
{
    //此处点那个按钮那个按钮就是sender 获得点击按钮的tag值
    //判断如果点击了
    if (self.tapBlockHandle) {
        //就返回点击按钮的tag值此处相当blockle tag的value
        self.tapBlockHandle(sender.tag);
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
@end
