//
//  twitterManager.m
//  显示微博（4种cell）
//
//  Created by 穆天泰 on 15/9/14.
//  Copyright (c) 2015年 穆天泰. All rights reserved.
//

#import "twitterManager.h"
#import "AFNetworking.h"
//TOKEN做成宏
#define TOKEN @"2.00EqARzFCojrCE33c483b847_48oHC"
@interface twitterManager()
//manager做成属性方便调用
@property(strong,nonatomic)AFHTTPRequestOperationManager * manager;
@end
@implementation twitterManager
//做成单例 仅初始化一次
+(instancetype)share
{
    static twitterManager *manager =nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[twitterManager alloc]init];
    });
    return manager;
}
//获取指定条数微博  参数分别为指定条数 和成功请求下的数组
-(void)gettwitterwithcount:(NSString *)count success:(weiboblock)block
{
    //初始化
    self.manager= [AFHTTPRequestOperationManager manager];
    //关闭自动解析
    self.manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [self.manager GET:@"https://api.weibo.com/2/statuses/home_timeline.json" parameters:@{@"access_token":TOKEN,@"count":count}success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //解析responseObject转成二进制数据放入字典中
        NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
        //字典中的statuses强转成数组
        NSArray * arr = dic[@"statuses"];
        //返回一个数组
        block(arr);

    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",[error description]);
    }];
    
}
//获取评论列表
-(void)gettwitterwithcomments:(NSString *)weiboID success:(weiboblock)block
{
    self.manager = [AFHTTPRequestOperationManager manager];
    self.manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [self.manager GET:@"https://api.weibo.com/2/comments/show.json" parameters:@{@"access_token":TOKEN,@"id":weiboID} success:^(AFHTTPRequestOperation *operation, NSData *responseObject) {
        NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
        NSArray * arr = dic[@"comments"];
        block(arr);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",[error description]);
    }];
    
}
//发送一条微博（纯文本）
-(void)sendWeiboWithStatus:(NSString *)status success:(SendWeiboBlock)block{
    self.manager = [AFHTTPRequestOperationManager manager];
    self.manager.responseSerializer = [AFHTTPResponseSerializer serializer];
     NSDictionary * dic = @{@"access_token":TOKEN,@"status":status};
   [self.manager POST:@"https://upload.api.weibo.com/2/statuses/upload.json" parameters:dic success:^(AFHTTPRequestOperation *operation, id responseObject) {
       block(YES);
   } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
       NSLog(@"%@",[error description]);
   }];
}
//发送微博（带图片）
-(void)sendWeiboWithStatus:(NSString *)status Image:(NSData *)imageData success:(SendWeiboBlock)block
{
    AFHTTPRequestOperationManager * manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    //将要上传的图片转为二进制并上传
    [manager POST:@"https://upload.api.weibo.com/2/statuses/upload.json" parameters:@{@"access_token":TOKEN,@"status":status} constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        //四个参数分别为要上传的二进制数据，后台要求的键的名字，文件的名字，文件的类型及格式
        [formData appendPartWithFileData:imageData name:@"pic" fileName:@"imagefile" mimeType:@"image/png"];
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        block(YES);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",[error description]);
    }];
}
//转发微博
-(void)zhuanFaWeiboWithWeiboID:(NSString *)WeiboID Status:(NSString *)status success:(SendWeiboBlock)block
{
    //
   self.manager = [AFHTTPRequestOperationManager manager];
    //关闭自动解析
    self.manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [self.manager POST:@"https://api.weibo.com/2/statuses/repost.json" parameters:@{@"access_token":TOKEN,@"id":WeiboID,@"status":status} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        block(YES);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",[error description]);
    }];
}
//评论微博
-(void)pinglunwithweiboID:(NSString *)WeiboID Status:
(NSString *)status success:(SendWeiboBlock)block
{
    self.manager = [AFHTTPRequestOperationManager manager];
    //关闭自动解析
    self.manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    [self.manager POST:@"https://api.weibo.com/2/comments/create.json" parameters:@{@"access_token":TOKEN,@"id":WeiboID,@"comment":status} success:^(AFHTTPRequestOperation *operation, id responseObject) {
        block(YES);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",[error description]);
    }];
}
@end
