//
//  sendViewController.m
//  显示微博（4种cell）
//
//  Created by 穆天泰 on 15/9/15.
//  Copyright (c) 2015年 穆天泰. All rights reserved.
//

#import "sendViewController.h"
#import "twitterManager.h"
@interface sendViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (weak, nonatomic) IBOutlet UIImageView *imageV;
@property(nonatomic,strong)twitterManager * manager;
@property(nonatomic,strong)UIImagePickerController * imagePicker;
@property(nonatomic,strong)NSData * data;
@end

@implementation sendViewController

- (void)viewDidLoad {
    [super viewDidLoad];
  
}
- (IBAction)tapsend:(id)sender
{
    if (self.data) {
        [self.manager sendWeiboWithStatus:self.textView.text Image:self.data success:^(BOOL bl) {
            if (bl == YES) {
                NSLog(@"发送成功");
            }
        }];
    }else{
        [self.manager sendWeiboWithStatus:self.textView.text success:^(BOOL bl){
            if (bl == YES) {
                NSLog(@"发送成功");
            }
        }];
    }}
- (IBAction)chooseImage:(id)sender
{
    self.imagePicker = [[UIImagePickerController alloc]init];
    self.imagePicker.allowsEditing = YES;
    self.imagePicker.delegate = self;
    self.imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:self.imagePicker animated:YES completion:nil];
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage * image = info[UIImagePickerControllerEditedImage];
    self.data = UIImagePNGRepresentation(image);
    self.imageV.image = image;
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
