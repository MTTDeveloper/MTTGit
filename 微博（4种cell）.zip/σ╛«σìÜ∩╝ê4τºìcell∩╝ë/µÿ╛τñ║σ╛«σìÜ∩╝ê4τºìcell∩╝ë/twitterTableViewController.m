//
//  twitterTableViewController.m
//  显示微博（4种cell）
//
//  Created by 穆天泰 on 15/9/14.
//  Copyright (c) 2015年 穆天泰. All rights reserved.
//

#import "twitterTableViewController.h"
#import "twitterManager.h" 
#import "UITableViewCell+setinfo.h"
#import "MBProgressHUD.h"
#import "UIViewController+HUD.h"
@interface twitterTableViewController ()
@property(strong,nonatomic)twitterManager *manager;
@property(strong,nonatomic)NSArray *twitterList;
@property(nonatomic,strong)MBProgressHUD * HUD;
@end
@implementation twitterTableViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    //初始化并贴上旋转提示
    self.HUD = [[MBProgressHUD alloc]initWithView:self.tableView];
    [self.tableView addSubview:self.HUD];
    [self.HUD show:YES];
    
    __block __weak twitterTableViewController * copy_self = self;
    self.manager = [twitterManager share];
    //请求20条  成功返回数组
    [self.manager gettwitterwithcount:@"20" success:^(NSArray *arr) {
        //将数组赋值给微博数组
        copy_self.twitterList = arr;
        //刷新 重新加载数据
        [copy_self.tableView reloadData];
        //请求成功后旋转提示消失
        [copy_self.HUD hide:YES];
        //显示请求成功弹窗
        [self showHint:@"请求成功"];
    }];
    //两段神奇的语句 可以在布局好cell上的约束之后自动扩充或者收缩cell中行的高度
    self.tableView.estimatedRowHeight = 44;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    // Return the number of rows in the section.
    return self.twitterList.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary * dic = self.twitterList[indexPath.row];
    UITableViewCell *cell ;
    //初始化cell之后来用数组中字典的关键字判断使用那种cell来显示
    //非转发
    if (dic[@"retweeted_status"]==nil)
    {//不带图
        if (dic[@"thumbnail_pic"]==nil) {
           cell = [tableView dequeueReusableCellWithIdentifier:@"cell1" forIndexPath:indexPath];
        }else
        {//带图
            cell =[tableView dequeueReusableCellWithIdentifier:@"cell3" forIndexPath:indexPath];
        }
    }else
    {//转发
        //不带图
        if (dic[@"retweeted_status"][@"thumbnail_pic"]==nil) {
           cell = [tableView dequeueReusableCellWithIdentifier:@"cell2" forIndexPath:indexPath];
        }
        else
        {
            cell = [tableView dequeueReusableCellWithIdentifier:@"cell4" forIndexPath:indexPath];
        }
    }
    //评论和转发按钮  判断点击了那个按钮
    cell.tapBlockHandle = ^(NSInteger index){
        if (index == 0) {
            //如果按了评论按钮 传过来的tag值=0 那么推送到下一界面并传值
            //传（weiboID ）来判断要对那个ID的微博进行评论
            UIStoryboard *s =[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
            UIViewController *vc = [s instantiateViewControllerWithIdentifier:@"pinglun"];
            [vc setValue:dic[@"id"] forKey:@"weiboID"];
            [self.navigationController pushViewController:vc animated:YES];
        }
    else
        {//转发  转发那个ID  并转发文本内容
            [self.manager zhuanFaWeiboWithWeiboID:dic[@"id"] Status:dic[@"text"]success:^(BOOL bl){
                if (bl == YES) {
                    [self showHint:@"转发成功"];
                }
                else{
                    [self showHint:@"转发失败"];
                }
            }];
        }
    };
    [cell setCellInfo:dic];    
    return cell;
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //点击操作行推送到评论列表界面
    UIStoryboard * s = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController * vc = [s instantiateViewControllerWithIdentifier:@"comments"];
    NSDictionary * dic = self.twitterList[indexPath.row];
   //传值微博ID 来判断看那个ID的评论列表
    NSString * weiboid = dic[@"id"];
    [vc setValue:weiboid forKey:@"weiboID"];
    [self.navigationController pushViewController:vc animated:YES];
    NSLog(@"111");
}


// Override to support conditional editing of the table view.


/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
