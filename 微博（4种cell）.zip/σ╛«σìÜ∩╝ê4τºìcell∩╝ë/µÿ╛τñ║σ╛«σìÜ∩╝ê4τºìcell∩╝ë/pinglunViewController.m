//
//  pinglunViewController.m
//  显示微博（4种cell）
//
//  Created by 穆天泰 on 15/9/15.
//  Copyright (c) 2015年 穆天泰. All rights reserved.
//

#import "pinglunViewController.h"
#import "UITableViewCell+setinfo.h"
#import "twitterManager.h"
@interface pinglunViewController ()
@property (weak, nonatomic) IBOutlet UITextField *pingluntext;
@property(strong,nonatomic)twitterManager *manager;
@end

@implementation pinglunViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.manager =[twitterManager share];
}
- (IBAction)tapfasong:(id)sender
{
[self.manager pinglunwithweiboID:self.weiboID Status:self.pingluntext.text success:^(BOOL bl){
    if (bl==YES) {
        
        UIAlertView *alert =[[UIAlertView alloc]initWithTitle:@"提示" message:@"评论成功" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
    else{
        UIAlertView *alert =[[UIAlertView alloc]initWithTitle:@"提示" message:@"评论失败" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }
    }];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
