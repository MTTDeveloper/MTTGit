//
//  UITableViewCell+setinfo.h
//  显示微博（4种cell）
//
//  Created by 穆天泰 on 15/9/14.
//  Copyright (c) 2015年 穆天泰. All rights reserved.
//

#import <UIKit/UIKit.h>
//定义个返回Tag值的代码块方便每个cell调用
typedef void(^DidTapBlock)(NSInteger Index);
@interface UITableViewCell (setinfo)
//做成属性
@property(nonatomic,strong)DidTapBlock tapBlockHandle;
-(void)setCellInfo:(NSDictionary *)dic;
@end
