//
//  commentsTableViewController.m
//  显示微博（4种cell）
//
//  Created by 穆天泰 on 15/9/15.
//  Copyright (c) 2015年 穆天泰. All rights reserved.
//

#import "commentsTableViewController.h"
#import "UIKit+AFNetworking.h"
#import "twitterManager.h"
@interface commentsTableViewController ()
@property(nonatomic,strong)twitterManager * manager;
@property(nonatomic,strong)NSArray * commentsList;
@end

@implementation commentsTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.manager = [twitterManager share];
    __block __weak commentsTableViewController * copy_self = self;
    [self.manager gettwitterwithcomments:self.weiboID success:^(NSArray *arr) {
        copy_self.commentsList = arr;
        [copy_self.tableView reloadData];
    }];
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return self.commentsList.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell5" forIndexPath:indexPath];
    
    NSDictionary *dic = self.commentsList[indexPath.row];
    cell.textLabel.text = dic[@"uesr"][@"name"];
    cell.detailTextLabel.text=dic[@"text"];
    [cell.imageView setImageWithURL:[NSURL URLWithString:dic[@"user"][@"profile_image_url"]] placeholderImage:[UIImage imageNamed:@"1.png"]];
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
