//
//  TextTableViewCell.h
//  显示微博（4种cell）
//
//  Created by 穆天泰 on 15/9/14.
//  Copyright (c) 2015年 穆天泰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TextTableViewCell : UITableViewCell

@end
