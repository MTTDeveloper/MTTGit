//
//  Line.m
//  TuYaBan-1
//
//  Created by 刘伟华 on 15/5/29.
//  Copyright (c) 2015年 刘伟华. All rights reserved.
//

#import "Line.h"

@implementation Line

- (instancetype)initWithPoint:(CGPoint)point Color:(UIColor *)color Width:(CGFloat)width
{
    self = [super init];
    if (self) {
        //初始化一个点数组
        self.points = [NSMutableArray arrayWithCapacity:1];
        //用Value对象来接收数组拿出的对象
        NSValue * value = [NSValue valueWithCGPoint:point];
        [self.points addObject:value];
        //给线的颜色赋值
        self.lineColor = color;
        //给线的宽度赋值
        self.lineWidth = width;
    }
    return self;
}
//设置贝塞尔曲线渲染
- (UIBezierPath *)bezierPath
{
    //实例化贝塞尔曲线
    UIBezierPath * path = [UIBezierPath bezierPath];
    //为贝塞尔曲线设置线宽
    [path setLineWidth:self.lineWidth];
    //用Value接收
    NSValue * value = self.points.firstObject;
    //强转
    CGPoint point = [value CGPointValue];
    //渲染路径指向第一个点
    [path moveToPoint:point];
    //拿出除了第一个点外所有的点
    for (int i = 1; i < self.points.count; i++)
    {
        //拿出所有点
        NSValue * v1 = self.points[i];
        //强转为CG结构体
        CGPoint p1 = [v1 CGPointValue];
        //把渲染路径指向这些点
        [path addLineToPoint:p1];
    }
    //返还一个渲染的路径
    return path;
}

@end
