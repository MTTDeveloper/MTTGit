//
//  SettingManager.h
//  TuYaBan-1
//
//  Created by 刘伟华 on 15/5/29.
//  Copyright (c) 2015年 刘伟华. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface SettingManager : NSObject

@property (strong, nonatomic) UIColor * color;
@property (assign, nonatomic) CGFloat red;
@property (assign, nonatomic) CGFloat green;
@property (assign, nonatomic) CGFloat blue;
@property (assign, nonatomic) CGFloat width;
@property (strong, nonatomic) NSUserDefaults * userDefaults;
+ (instancetype)shareSettingManager;
@end
