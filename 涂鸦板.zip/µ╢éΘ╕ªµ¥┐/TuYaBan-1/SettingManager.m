//
//  SettingManager.m
//  TuYaBan-1
//
//  Created by 刘伟华 on 15/5/29.
//  Copyright (c) 2015年 刘伟华. All rights reserved.
//

#import "SettingManager.h"

@implementation SettingManager

+ (instancetype)shareSettingManager
{
    static SettingManager * manager = nil;
    static dispatch_once_t OnceToken;
    dispatch_once(&OnceToken, ^{
        manager = [[SettingManager alloc]init];
        
        manager.userDefaults = [NSUserDefaults standardUserDefaults];
        manager.red = [manager.userDefaults floatForKey:@"red"];
        manager.green = [manager.userDefaults floatForKey:@"green"];
        manager.blue = [manager.userDefaults floatForKey:@"blue"];
        manager.width = [manager.userDefaults floatForKey:@"width"];
    });
    return manager;
}
//重写UIColor的父类
- (UIColor *)color
{
    return [UIColor colorWithRed:self.red green:self.green blue:self.blue alpha:1];
}

@end
