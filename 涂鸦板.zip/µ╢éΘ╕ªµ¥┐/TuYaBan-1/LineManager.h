//
//  LineManager.h
//  TuYaBan-1
//
//  Created by 刘伟华 on 15/5/29.
//  Copyright (c) 2015年 刘伟华. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Line.h"
typedef void(^LineManagerBlock)(NSArray * lines);
@interface LineManager : NSObject

@property (strong, nonatomic) NSMutableArray * lines;
@property (strong, nonatomic) NSMutableArray * historyLines;
@property (strong, nonatomic) LineManagerBlock tapLineBlock;

+ (instancetype)shareLineManager;
//添加一条新线
- (void)addNewLine:(Line *)line;

- (void)addPointAtNewLine:(CGPoint)point;

- (void)undo;
- (void)redo;
- (void)clean;

@end
