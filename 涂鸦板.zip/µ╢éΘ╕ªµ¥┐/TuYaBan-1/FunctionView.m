//
//  FunctionView.m
//  TuYaBan-1
//
//  Created by 刘伟华 on 15/6/1.
//  Copyright (c) 2015年 刘伟华. All rights reserved.
//

#import "FunctionView.h"
@interface FunctionView ()
@property (weak,  nonatomic)id target;
@property (assign, nonatomic) SEL action;
@end
@implementation FunctionView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        CGFloat width = (self.bounds.size.width-100)/4;
        
        UIButton * undo = [UIButton buttonWithType:UIButtonTypeCustom];
        undo.tag = FunctionTypeUndo;
        [undo setTitle:@"undo" forState:UIControlStateNormal];
        undo.backgroundColor = [UIColor yellowColor];
        undo.frame = CGRectMake(20, 10, width, 40);
        [undo addTarget:self action:@selector(tapFuncButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:undo];
        
        UIButton * redo = [UIButton buttonWithType:UIButtonTypeCustom];
        redo.tag = FunctionTypeRedo;
        [redo setTitle:@"redo" forState:UIControlStateNormal];
        redo.backgroundColor = [UIColor orangeColor];
        redo.frame = CGRectMake(width + 40, 10, width, 40);
        [redo addTarget:self action:@selector(tapFuncButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:redo];
        
        UIButton * clean = [UIButton buttonWithType:UIButtonTypeCustom];
        clean.tag = FunctionTypeClean;
        [clean setTitle:@"clean" forState:UIControlStateNormal];
        clean.backgroundColor = [UIColor blueColor];
        clean.frame = CGRectMake(width*2+60, 10, width, 40);
        [clean addTarget:self action:@selector(tapFuncButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:clean];
        
        UIButton * save = [UIButton buttonWithType:UIButtonTypeCustom];
        save.tag = FunctionTypeSave;
        [save setTitle:@"save" forState:UIControlStateNormal];
        save.backgroundColor = [UIColor magentaColor];
        save.frame = CGRectMake(width*3+80, 10, width, 40);
        [save addTarget:self action:@selector(tapFuncButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:save];
        
    }
    
    return self;
}

- (void)tapFuncButton:(UIButton *)btn
{
    self.type = btn.tag;
    
    if ([self.target respondsToSelector:self.action]) {
        [self.target performSelector:self.action withObject:self];
    }}

- (void)addTarget:(id)target Action:(SEL)action
{
    self.target = target;
    self.action = action;
}

@end
