//
//  TouchEventView.m
//  TuYaBan-1
//
//  Created by 刘伟华 on 15/5/29.
//  Copyright (c) 2015年 刘伟华. All rights reserved.
//

#import "TouchEventView.h"

@implementation TouchEventView

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch * touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    
    if ([self.delegate respondsToSelector:@selector(touchEventView:touchBeganAtPoint:)]) {
        [self.delegate touchEventView:self touchBeganAtPoint:point];
    }
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch * touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    if ([self.delegate respondsToSelector:@selector(touchEventView:touchMovedAtPoint:)]) {
        [self.delegate touchEventView:self touchMovedAtPoint:point];
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch * touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    if ([self.delegate respondsToSelector:@selector(touchEventView:touchEndedAtPoint:)]) {
        [self.delegate touchEventView:self touchEndedAtPoint:point];
    }
}

@end
