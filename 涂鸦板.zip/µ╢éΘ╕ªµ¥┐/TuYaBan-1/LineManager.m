//
//  LineManager.m
//  TuYaBan-1
//
//  Created by 刘伟华 on 15/5/29.
//  Copyright (c) 2015年 刘伟华. All rights reserved.
//

#import "LineManager.h"

@implementation LineManager

+ (instancetype)shareLineManager
{
    static LineManager * manager = nil;
    static dispatch_once_t OnceToken;
    dispatch_once(&OnceToken, ^{
        manager = [[LineManager alloc]init];
        manager.lines = [NSMutableArray arrayWithCapacity:1];
        manager.historyLines = [NSMutableArray arrayWithCapacity:1];
        
    });
    return manager;
}

- (void)addNewLine:(Line *)line
{
    [self.lines addObject:line];
    if (self.tapLineBlock) {
        self.tapLineBlock(self.lines);
    }
}

- (void)addPointAtNewLine:(CGPoint)point
{
    Line * currentLine = self.lines.lastObject;
    [currentLine.points addObject:[NSValue valueWithCGPoint:point]];
    if (self.tapLineBlock) {
        self.tapLineBlock(self.lines);
    }
}

- (void)undo
{
    if ([self.lines lastObject])
    {
        [self.historyLines addObject:[self.lines lastObject]];
        [self.lines removeObject:[self.lines lastObject]];
    }
}

- (void)redo
{
    if ([self.historyLines lastObject])
    {
        [self.lines addObject:[self.historyLines lastObject]];
        [self.historyLines removeObject:[self.historyLines lastObject]];
    }
}

- (void)clean
{
    [self.lines removeAllObjects];
    [self.historyLines removeAllObjects];
}
@end
