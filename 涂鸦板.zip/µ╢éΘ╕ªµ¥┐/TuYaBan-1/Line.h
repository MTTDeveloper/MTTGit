//
//  Line.h
//  TuYaBan-1
//
//  Created by 刘伟华 on 15/5/29.
//  Copyright (c) 2015年 刘伟华. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface Line : NSObject
//存放点的数组
@property (strong, nonatomic) NSMutableArray * points;
//线颜色
@property (strong, nonatomic) UIColor * lineColor;
//线宽
@property (assign, nonatomic) CGFloat lineWidth;
//便利初始化点  颜色  线宽
- (instancetype)initWithPoint:(CGPoint)point Color:(UIColor *)color Width:(CGFloat)width;
//设置贝塞尔曲线
- (UIBezierPath *)bezierPath;

@end
