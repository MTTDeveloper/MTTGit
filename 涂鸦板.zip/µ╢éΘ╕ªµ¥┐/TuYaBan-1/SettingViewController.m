//
//  SettingViewController.m
//  TuYaBan-1
//
//  Created by 刘伟华 on 15/5/29.
//  Copyright (c) 2015年 刘伟华. All rights reserved.
//

#import "SettingViewController.h"
#import "SettingManager.h"
@interface SettingViewController ()
@property (weak, nonatomic) IBOutlet UISlider *slR;
@property (weak, nonatomic) IBOutlet UISlider *slG;
@property (weak, nonatomic) IBOutlet UISlider *slB;
@property (weak, nonatomic) IBOutlet UISlider *slWidth;
@property (weak, nonatomic) IBOutlet UIView *pColor;
@property (strong, nonatomic) UIView * testView;
@property (strong, nonatomic) SettingManager * manager;
@property (strong, nonatomic) NSUserDefaults * userDefaults;
@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.manager = [SettingManager shareSettingManager];
    
    self.slR.value = self.manager.red;
    self.slG.value = self.manager.green;
    self.slB.value = self.manager.blue;
    self.slWidth.value = self.manager.width;
    self.slWidth.minimumValue =5;
    self.slWidth.maximumValue =20;
    self.pColor.backgroundColor = self.manager.color;
    
    self.testView = [[UIView alloc]initWithFrame:CGRectMake(160, 360, 130, self.manager.width)];
    self.testView.backgroundColor = [UIColor greenColor];
    [self.view addSubview:self.testView];
    
    self.userDefaults = [NSUserDefaults standardUserDefaults];
    
    
}
- (IBAction)tapR:(UISlider *)sender
{
    self.manager.red = sender.value;
    self.pColor.backgroundColor = self.manager.color;
    [self.userDefaults setFloat:sender.value forKey:@"red"];
    [self.userDefaults synchronize];
}
- (IBAction)tapG:(UISlider *)sender
{
    self.manager.green = sender.value;
    self.pColor.backgroundColor = self.manager.color;
    [self.userDefaults setFloat:sender.value forKey:@"green"];
    [self.userDefaults synchronize];
}
- (IBAction)tapB:(UISlider *)sender
{
    self.manager.blue = sender.value;
    self.pColor.backgroundColor = self.manager.color;
    [self.userDefaults setFloat:sender.value forKey:@"blue"];
    [self.userDefaults synchronize];
}
- (IBAction)tapWidth:(UISlider *)sender
{
    self.manager.width = sender.value;
    CGRect frame = self.testView.frame;
    frame.size.height = self.manager.width;
    self.testView.frame = frame;
    [self.userDefaults setFloat:sender.value forKey:@"width"];
    [self.userDefaults synchronize];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
