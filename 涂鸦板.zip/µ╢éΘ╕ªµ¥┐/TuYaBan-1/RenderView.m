//
//  RenderView.m
//  TuYaBan-1
//
//  Created by 刘伟华 on 15/5/29.
//  Copyright (c) 2015年 刘伟华. All rights reserved.
//

#import "RenderView.h"
#import "Line.h"
@implementation RenderView

- (void)setLines:(NSArray *)lines
{
    self.tempLines = lines;
    [self setNeedsDisplay];//绘图
}



// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    for (Line * line in self.tempLines)
    {
        UIColor * color = line.lineColor;
        [color setStroke];
        
        UIBezierPath * path = line.bezierPath;
        
        [path stroke];//用贝塞尔描绘曲线
    }
}


@end
