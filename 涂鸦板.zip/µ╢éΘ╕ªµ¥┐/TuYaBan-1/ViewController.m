//
//  ViewController.m
//  TuYaBan-1
//
//  Created by 刘伟华 on 15/5/29.
//  Copyright (c) 2015年 刘伟华. All rights reserved.
//

#import "ViewController.h"
#import "Line.h"
#import "LineManager.h"
#import "TouchEventView.h"
#import "RenderView.h"
#import "SettingManager.h"
#import "FunctionView.h"
@interface ViewController ()<TouchEventDelegate>

@property (strong, nonatomic) LineManager * manager;
@property (strong, nonatomic) TouchEventView * touchView;
@property (strong, nonatomic) RenderView * renderView;
@property (strong, nonatomic) SettingManager * settingManger;
@property(strong, nonatomic) FunctionView * functionView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    self.manager = [LineManager shareLineManager];
    
    __weak __block ViewController * copy_self = self;
    self.manager.tapLineBlock = ^(NSArray * lines){
        [copy_self.renderView setLines:lines];
    };
    self.touchView = [[TouchEventView alloc]initWithFrame:self.view.bounds];
    self.touchView.backgroundColor = [UIColor clearColor];
    self.touchView.delegate = self;
    
    self.renderView = [[RenderView alloc]initWithFrame:self.view.bounds];
    self.renderView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [self.view addSubview:self.renderView];

    [self.renderView addSubview:self.touchView];
    self.settingManger = [SettingManager shareSettingManager];
    if (self.settingManger.width == 0) {
        self.settingManger.width = 3;
    }
    
    
    self.functionView = [[FunctionView alloc]initWithFrame:CGRectMake(0, self.view.bounds.size.height-60, self.view.bounds.size.width, 60)];
    self.functionView.backgroundColor = [UIColor grayColor];
    [self.functionView addTarget:self Action:@selector(tapFuncView:)];
    [self.view addSubview:self.functionView];
    
}

- (void)touchEventView:(TouchEventView *)tv touchBeganAtPoint:(CGPoint)point
{
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    __weak __block ViewController * copy_self = self;
    [UIView animateWithDuration:0.3 animations:^{
        copy_self.functionView.frame = CGRectMake(0, copy_self.view.bounds.size.height, copy_self.view.bounds.size.width, 60);
    }];

    Line * line = [[Line alloc]initWithPoint:point Color:self.settingManger.color Width:self.settingManger.width];
    [self.manager addNewLine:line];
}

- (void)touchEventView:(TouchEventView *)tv touchMovedAtPoint:(CGPoint)point
{
    [self.manager addPointAtNewLine:point];
}

- (void)touchEventView:(TouchEventView *)tv touchEndedAtPoint:(CGPoint)point
{
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    __weak __block ViewController * copy_self = self;
    [UIView animateWithDuration:0.3 animations:^{
        copy_self.functionView.frame = CGRectMake(0, copy_self.view.bounds.size.height-60, copy_self.view.bounds.size.width, 60);
    }];
    [self.manager addPointAtNewLine:point];
}

- (void)tapFuncView:(FunctionView *)fv
{
    switch (fv.type) {
        case FunctionTypeUndo:
        {
            [self.manager undo];
            [self.renderView setLines:self.manager.lines];
            break;
        }
        case FunctionTypeRedo:
        {
            [self.manager redo];
            [self.renderView setLines:self.manager.lines];
            break;
        }
        case FunctionTypeClean:
        {
            [self.manager clean];
            [self.renderView setLines:self
             .manager.lines];
            break;
        }
        case FunctionTypeSave:
        {
            self.functionView.hidden = YES;
            CGSize size;
            size = self.view.bounds.size;
            //给图形上下文设置大小
            UIGraphicsBeginImageContext(size);
            //获取layer上的图层
            [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
            //从当前上下文获取图片
            UIImage * image = UIGraphicsGetImageFromCurrentImageContext();
            //保存图片到相册
            UIImageWriteToSavedPhotosAlbum(image, self, nil, nil);
            //结束绘图
            UIGraphicsEndImageContext();
            
            UIAlertView * alter = [[UIAlertView alloc]initWithTitle:@"提示" message:@"截图成功" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alter show];
            self.functionView.hidden = NO;
            break;
        }
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
