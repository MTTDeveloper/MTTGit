//
//  TouchEventView.h
//  TuYaBan-1
//
//  Created by 刘伟华 on 15/5/29.
//  Copyright (c) 2015年 刘伟华. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol TouchEventDelegate;
@interface TouchEventView : UIView

@property (weak, nonatomic) id<TouchEventDelegate>delegate;
@end

@protocol TouchEventDelegate <NSObject>

@optional

- (void)touchEventView:(TouchEventView *)tv touchBeganAtPoint:(CGPoint)point;

- (void)touchEventView:(TouchEventView *)tv touchMovedAtPoint:(CGPoint)point;

- (void)touchEventView:(TouchEventView *)tv touchEndedAtPoint:(CGPoint)point;

@end
