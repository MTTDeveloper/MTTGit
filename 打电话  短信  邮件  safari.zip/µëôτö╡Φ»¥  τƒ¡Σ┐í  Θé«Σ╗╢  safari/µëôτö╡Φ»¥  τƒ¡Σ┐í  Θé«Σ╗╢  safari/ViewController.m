//
//  ViewController.m
//  打电话  短信  邮件  safari
//
//  Created by 穆天泰 on 15/10/13.
//  Copyright (c) 2015年 穆天泰. All rights reserved.
//
#import "ViewController.h"
#import <MessageUI/MessageUI.h>
@interface ViewController ()<MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UITextField *TextURL;
@property (weak, nonatomic) IBOutlet UITextField *SendID;
@property (weak, nonatomic) IBOutlet UITextField *TextSubJect;
@property (weak, nonatomic) IBOutlet UITextField *TextBody;
@end
@implementation ViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
#pragma mark  打开iOS系统的 Safari浏览器
- (IBAction)tapSafari:(id)sender
{
    NSString *strURL = self.TextURL.text;
    //可以直接输入三W
    strURL = [NSString stringWithFormat:@"http://%@",strURL];
    NSURL *url =[NSURL URLWithString:strURL];
    //获取当前的应用程序对象
    UIApplication *app = [UIApplication sharedApplication];
    //当前应该程序打开地址
    [app openURL:url];
}
#pragma mark  打开系统的拨号
- (IBAction)openCall:(id)sender
{
    NSString *strURL = [NSString stringWithFormat:@"tel://%@",self.TextURL.text];
    NSURL *url = [NSURL URLWithString:strURL];
    UIApplication *app = [UIApplication sharedApplication];
    [app openURL:url];
}
#pragma mark  打开系统短信
- (IBAction)openMessage:(id)sender
{
    NSString *strURL =[NSString stringWithFormat:@"sms://%@",self.TextURL.text];
    NSURL *url = [NSURL URLWithString:strURL];
    [[UIApplication sharedApplication]openURL:url];
    
}
#pragma mark  打开系统的邮箱
- (IBAction)openMail:(id)sender
{
    NSString *to  =self.SendID.text;
    NSString *subject = self.TextSubJect.text;
    NSString *body = self.TextBody.text;
    NSString *strURL = [NSString stringWithFormat:@"mailto:?to=%@&subject=%@&body=%@",to,subject,body];
    NSURL *url = [NSURL URLWithString:strURL];
 [[UIApplication sharedApplication]openURL:url];
}
#pragma mark  打开程序内短信功能
- (IBAction)openSms:(id)sender
{ //需导入库MessageUI.framework 遵循协议<MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate>
    if (![MFMessageComposeViewController canSendText]) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:@"设备不支持" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        [self presentViewController:alertController animated:YES completion:nil];
    }
    NSString *to  =self.SendID.text;
    NSString *body = self.TextBody.text;
    
    //创建一个系统短信ViewController ,并且指定相关的属性
    MFMessageComposeViewController *messageVC= [MFMessageComposeViewController new];
    messageVC.recipients = @[to];//设置接收人
    messageVC.body = body;
    //指定委托
    messageVC.messageComposeDelegate = self;
    //弹出MessageVC
    [self presentViewController:messageVC animated:YES completion:nil];
    
}
#pragma mark  打开程序内邮件功能
- (IBAction)openMailInObJect:(id)sender
{
    if (![MFMailComposeViewController canSendMail]) {
        [self myALert:@"设备不支持"];
    }
    //新建系统邮箱ViewController ,并且指定相关属性
    MFMailComposeViewController *mailVC = [MFMailComposeViewController new];
    NSString *to  =self.SendID.text;
    NSString *subject = self.TextSubJect.text;
    NSString *body = self.TextBody.text;
    
    [mailVC setToRecipients:@[to]];
    [mailVC setSubject:subject];
    [mailVC setMessageBody:body isHTML:YES];
    //指定委托
    mailVC.mailComposeDelegate =self;
    
}
//邮件委托回调，监控邮件编辑状态
-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    [self dismissViewControllerAnimated:YES completion:nil];
    switch (result) {
        case MFMailComposeResultCancelled:
            [self myALert:@"您取消了发送"];
            break;
        case MFMailComposeResultSent:
            [self myALert:@"发送成功"];
            break;
        case MFMailComposeResultFailed:
            [self myALert:@"发送失败"];
            break;
        case MFMailComposeResultSaved:
            [self myALert:@"保存了草稿"];
            break;
        default:
            break;
    }
}
//短信回调委托方法，监控发送状态
-(void)messageComposeViewController:(MFMessageComposeViewController *)controller   didFinishWithResult:(MessageComposeResult)result
{
    [self dismissViewControllerAnimated:YES completion:nil];
    switch (result) {
        case MessageComposeResultCancelled:
            [self myALert:@"您取消了发送"];
            break;
        case MessageComposeResultSent:
            [self myALert:@"发送成功"];
            break;
        case MessageComposeResultFailed:
            [self myALert:@"发送失败"];
        default:
            break;
    }
}
//自定义一个Alert
-(void)myALert:(NSString *)mag
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:mag preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleDefault handler:nil];
    [alertController addAction:ok];
    [self presentViewController:alertController animated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
