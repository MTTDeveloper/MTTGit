//
//  Constant.h
//  meituan
//
//  Created by jinzelu on 15/7/13.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#ifndef meituan_Constant_h
#define meituan_Constant_h

//友盟Appkey
#define UMAPPKEY @"55a37e7f67e58e1aac00211f"


#endif
