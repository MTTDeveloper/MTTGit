//
//  JZMerAroundGroupModel.m
//  meituan
//
//  Created by jinzelu on 15/7/22.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import "JZMerAroundGroupModel.h"

@implementation JZMerAroundGroupModel

+(NSDictionary *) replacedKeyFromPropertyName{
    return @{@"rate_count":@"rate-count"};
}

@end
