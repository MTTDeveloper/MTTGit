//
//  JZMerDetailModel.m
//  meituan
//
//  Created by jinzelu on 15/7/17.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import "JZMerDetailModel.h"

@implementation JZMerDetailModel

@end
