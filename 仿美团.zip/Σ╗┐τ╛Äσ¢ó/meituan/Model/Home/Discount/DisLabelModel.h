//
//  DisLabelModel.h
//  meituan
//
//  Created by jinzelu on 15/7/3.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DisLabelModel : NSObject

@property(nonatomic, strong) NSString *viewmore;
@property(nonatomic, strong) NSString *lname;
@property(nonatomic, strong) NSNumber *count;
@property(nonatomic, strong) NSString *subtitle;

@end
