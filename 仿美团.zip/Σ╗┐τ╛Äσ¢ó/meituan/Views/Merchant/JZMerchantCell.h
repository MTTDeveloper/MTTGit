//
//  JZMerchantCell.h
//  meituan
//
//  Created by jinzelu on 15/7/9.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZMerchantModel.h"

@interface JZMerchantCell : UITableViewCell


@property(nonatomic, strong) JZMerchantModel *jzMerM;

@end
