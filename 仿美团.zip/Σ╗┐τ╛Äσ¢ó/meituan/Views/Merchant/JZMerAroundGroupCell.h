//
//  JZMerAroundGroupCell.h
//  meituan
//
//  Created by jinzelu on 15/7/22.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZMerAroundGroupModel.h"

@interface JZMerAroundGroupCell : UITableViewCell

@property(nonatomic, strong) JZMerAroundGroupModel *jzMerAroundM;/**   数据*/

@end
