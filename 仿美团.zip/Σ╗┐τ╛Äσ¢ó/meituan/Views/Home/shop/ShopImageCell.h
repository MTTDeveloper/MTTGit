//
//  ShopImageCell.h
//  meituan
//
//  Created by jinzelu on 15/7/8.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShopImageCell : UITableViewCell

@property(nonatomic, strong) UIImageView *shopImageView;
@property(nonatomic, strong) UILabel *shopNameLabel;
@property(nonatomic, strong) UILabel *shopTitleLabel;

@end
