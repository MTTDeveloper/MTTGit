//
//  ShopPriceCell.h
//  meituan
//
//  Created by jinzelu on 15/7/8.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShopPriceCell : UITableViewCell

@property(nonatomic, strong) UILabel *priceLabel;
@property(nonatomic, strong) UILabel *oldPriceLabel;

@end
