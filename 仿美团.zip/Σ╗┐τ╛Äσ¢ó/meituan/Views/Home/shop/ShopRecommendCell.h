//
//  ShopRecommendCell.h
//  meituan
//
//  Created by jinzelu on 15/7/8.
//  Copyright (c) 2015年 jinzelu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShopRecommendModel.h"

@interface ShopRecommendCell : UITableViewCell

@property(nonatomic, strong) ShopRecommendModel *shopRecM;

@end
