//
//  AboutUSTableViewController.h
//  HiddenLove
//
//  Created by mac on 15/4/30.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutUSTableViewController : UITableViewController

@end
