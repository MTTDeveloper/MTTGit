//
//  LoginViewController.m
//  HiddenLove
//
//  Created by mac on 15/3/15.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "LoginViewController.h"

#import "UserManager.h"
#import "SlideNavigationController.h"
#import "PersonInfoTableViewController.h"
#import "HomeViewController.h"
@interface LoginViewController ()
{
    NSTimer * timer;
    int count;
    NSString * code;
}

@property(nonatomic,strong)UserManager * uManager;

@end

@implementation LoginViewController


#pragma - mark  重新父类方法

-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBar.hidden=YES;
}

-(void)viewWillDisappear:(BOOL)animated
{
    self.navigationController.navigationBar.hidden=NO;
}
- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.view.backgroundColor=[MUser hexStringToColor:@"ff6063"];
    
   [self.loginBtn setBackgroundColor:[MUser hexStringToColor:@"007b43"]];
    self.loginBtn.layer.cornerRadius  = 8;
    self.loginBtn.layer.masksToBounds = YES;
    self.uManager = [UserManager shareManager];
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [UIView animateWithDuration:0.35 animations:^{
        CGRect frame=self.view.frame;
        frame.origin.y=0;
        self.view.frame=frame;
    }];
    [self.view endEditing:YES];
}


#pragma - mark  回调方法


-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    CGFloat height= SCREEN_Height-(self.loginBtn.frame.origin.y+30);
    if (height<216){
        [UIView animateWithDuration:0.35 animations:^{
            CGRect frame=self.view.frame;
            frame.origin.y=height-216-20;
            self.view.frame=frame;
        }];
    }
    return YES;
}

- (IBAction)login:(id)sender {
    [self.uManager autheCode:self.codeText.text TEl:self.telText.text BlockHandel:^(NSDictionary * dic) {

        
        if ([dic[@"success"] integerValue]==0) {
        UIStoryboard * s=[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
            if ([dic[@"user"][@"name"]isEqualToString:@""]) {
                UIViewController * vc=[s instantiateViewControllerWithIdentifier:@"personInfo"];
                
                [self.navigationController pushViewController:vc animated:YES];
            }
            else
            {
                HomeViewController * vc=[s instantiateViewControllerWithIdentifier:@"home"];
                vc.type=@"主页";
                [self.navigationController pushViewController:vc animated:YES];
            }
       
           
        }
        else
        {

            [MUser alertViewShowTitle:@"提示" andMessage:@"登录失败，请重新登录" andDelegate:self controltag:1000];
        }
    }];

  
    
    [UIView animateWithDuration:0.35 animations:^{
        CGRect frame=self.view.frame;
        frame.origin.y=0;
        self.view.frame=frame;
    }];
    
}


- (IBAction)getCode:(id)sender {
    
    
    if ([self isRightTEL:self.telText.text])
    {
        //发送信息
        timer=[NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(jishi) userInfo:nil repeats:YES];
        count=30;
        
        [self.uManager getCodeWithTel:self.telText.text BlockHandle:^(BOOL isSuccess)
         {
             if (isSuccess) {
                 
                [MUser alertViewShowTitle:@"提示" andMessage:@"验证码将会发送到您的手机上，\n请注意查收" andDelegate:self controltag:1000];
             }
             else
             {
                [MUser alertViewShowTitle:@"提示" andMessage:@"验证码获取失败，请重试" andDelegate:self controltag:1000];
             }
             
         }];
    }
    else
    {
        [MUser alertViewShowTitle:@"提示" andMessage:@"请输入正确手机号" andDelegate:self controltag:2];
    }
    

}

-(void)jishi
{
    if (count==0)
    {
        [timer invalidate];
        self.codeBtn.userInteractionEnabled=YES;
        self.codeBtn.backgroundColor=[UIColor colorWithRed:0.92f green:0.54f blue:0.20f alpha:1.00f];
        [self.codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
    }
    else{
        count--;
        self.codeBtn.userInteractionEnabled=NO;
        self.codeBtn.backgroundColor=[UIColor lightGrayColor];
        [self.codeBtn setTitle:[NSString stringWithFormat:@"重新获取(%d)",count] forState:UIControlStateNormal];
    }
}




#pragma - mark vc功能封装

-(BOOL)isRightTEL:(NSString *)tel
{
    if (tel.length==11) {
        return YES;
    }
    return NO;
}






/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
