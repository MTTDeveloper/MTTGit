//
//  WebViewController.h
//  HiddenLove
//
//  Created by mac on 15/5/26.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebViewController : UIViewController
@property (nonatomic,copy)NSString * urlString;
@end
