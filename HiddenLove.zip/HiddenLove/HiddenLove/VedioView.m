//
//  VedioView.m
//  HiddenLove
//
//  Created by mac on 15/3/27.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "VedioView.h"
#import "MVPlayerControllerViewController.h"
#import "MUser.h"
@interface VedioView ()
@property (nonatomic,strong)UIImageView * playImage;
@property (nonatomic,strong)UIImageView * delectImage;
@property (strong, nonatomic) IBOutlet UIButton *playBtn;
@property (strong, nonatomic) IBOutlet UIButton *delectBtn;


@end

@implementation VedioView
-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if(self)
    {
//        CGFloat w=(CGFloat)(SCREEN_Width-40)/2;
//        CGFloat width=w/2-20;
//        self.playImage=[[UIImageView alloc]initWithFrame:CGRectMake(74, 10, 60, 60)];
//        self.playImage.image=[UIImage imageNamed:@"bofang1.png"];
//        [self addSubview:self.playImage];
//        self.delectImage=[[UIImageView alloc]initWithFrame:CGRectMake(width+w, 10, 60, 60)];
//        self.delectImage.image=[UIImage imageNamed:@"shanchu.png"];
//        [self addSubview:self.delectImage];

    }
    return self;
}
-(void)addImages
{
    CGFloat w=(SCREEN_Width-40)/2;
    
    CGFloat width=w/2-50;
    self.playImage=[[UIImageView alloc]initWithFrame:CGRectMake(width, 0, 60, 60)];
    self.playImage.image=[UIImage imageNamed:@"bofang1.png"];
    [self.playBtn addSubview:self.playImage];
    self.delectImage=[[UIImageView alloc]initWithFrame:CGRectMake(width, 0, 60, 60)];
    self.delectImage.image=[UIImage imageNamed:@"shanchu.png"];
    [self.delectBtn addSubview:self.delectImage];


}
- (IBAction)player:(id)sender {
   
    self.playVideoBlock();
    
}
- (IBAction)delectVideo:(id)sender {
    self.delectVideoBlock();
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
