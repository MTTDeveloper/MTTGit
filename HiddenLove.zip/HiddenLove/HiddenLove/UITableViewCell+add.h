//
//  UITableViewCell+add.h
//  HiddenLove
//
//  Created by mac on 15/3/17.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UserManager.h"
typedef void(^TapBLOCK)(NSDictionary * dic);
@protocol UITableViewCellDelegate
-(void)setPerson:(NSDictionary *)dic;
@end
@interface UITableViewCell (add)<UITableViewCellDelegate>
@property (nonatomic,strong)TapBLOCK tapBlock;
-(void)setCellInfo:(NSDictionary * )dic;
- (NSString *)getSendDate:(NSString *)sendDate;
-(NSAttributedString *)changeTextWithBiaoqing:(NSString *)text;
-(NSString *)getSex;
@end
