//
//  AVVoicePlayer.m
//  HiddenLove
//
//  Created by mac on 15/3/23.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "AVVoicePlayer.h"

@interface AVAudioPlayer ()


@property(nonatomic,strong)AVAudioPlayer * player;

@end

@implementation AVVoicePlayer
+(instancetype)share
{
    static AVVoicePlayer * player=nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        player=[[AVVoicePlayer alloc]init];
    });
   
    return player;
}

-(void)playWithData:(NSData *)data
{
    self.player = [[AVAudioPlayer alloc]initWithData:data error:nil];
}


@end
