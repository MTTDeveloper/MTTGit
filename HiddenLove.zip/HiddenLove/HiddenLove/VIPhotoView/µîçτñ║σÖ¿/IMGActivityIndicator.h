//
//  IMGActivityIndicator.h
//  IMGActivityIndicator
//
//  Created by Maijid Moujaled on 11/12/14.
//  Copyright (c) 2014 Maijid Moujaled. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IMGActivityIndicator : UIView

@property (nonatomic, strong) UIColor *strokeColor;

@end
