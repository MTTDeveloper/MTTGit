//
//  vedioCell.m
//  HiddenLove
//
//  Created by mac on 15/3/19.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "vedioCell.h"
#import "UITableViewCell+add.h"
#import "UIButton+WebCache.h"
#import "MUser.h"
#import <MediaPlayer/MediaPlayer.h>
#import "MVPlayerControllerViewController.h"
@interface vedioCell()
@property (nonatomic,strong)TapBLOCK tapBlock;
@property (strong, nonatomic) IBOutlet UIView *bgView;
@property (strong, nonatomic) IBOutlet UIButton *headBtn;
@property (strong, nonatomic) IBOutlet UIButton *nameBtn;
@property (strong, nonatomic) IBOutlet UILabel *text;
@property (strong, nonatomic) IBOutlet UILabel *dateText;
@property (strong, nonatomic) IBOutlet UIButton *vedioBtn;

@property (strong, nonatomic) MPMoviePlayerController * p;

@property (strong, nonatomic) UIImageView * playView;
@property (nonatomic,assign)BOOL my;
@end

@implementation vedioCell

-(void)awakeFromNib
{
   
  //  [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(movieThumbnailLoadComplete:) name:MPMoviePlayerThumbnailImageRequestDidFinishNotification object:nil];
    NSString * sex=[self getSex];
    self.bgView.backgroundColor=[MUser hexStringToColor:@"eaf4fc"];
    [self.headBtn setBackgroundImage:[UIImage imageNamed:@"tyzongjian.png"] forState:UIControlStateNormal];
    
    if ([sex isEqualToString:@"nv"]) {
        self.bgView.backgroundColor=[MUser hexStringToColor:@"f8f4e6"];
        [self.headBtn setBackgroundImage:[UIImage imageNamed:@"tyyuangong.png"] forState:UIControlStateNormal];
    }
    
    self.bgView.layer.cornerRadius=5;
    self.bgView.layer.masksToBounds=YES;
     self.vedioBtn.userInteractionEnabled=NO;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setCellInfo:(NSDictionary * )dic
{
    UserManager * uManager=[UserManager shareManager];
    NSString * str=dic[@"fromUid"];
    if([str isEqualToString:uManager.uid])
    {
        [self.headBtn sd_setBackgroundImageWithURL:uManager.personInfo[@"headImage"] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"tyzongjian.png"]];
         [self.nameBtn setTitle:uManager.personInfo[@"name"] forState:UIControlStateNormal];
        self.my=YES;
    }
    else
    {
         if (str.length>1) {
        [self.headBtn sd_setBackgroundImageWithURL:uManager.otherInfo[@"headImage"] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"tyzongjian.png"]];
        [self.nameBtn setTitle:uManager.otherInfo[@"name"] forState:UIControlStateNormal];
         }
    }
     self.dateText.text=[self getSendDate:dic[@"date"]];
     self.text.attributedText=[self changeTextWithBiaoqing:dic[@"text"]];
     _url=dic[@"content"];
    
    self.vedioBtn.backgroundColor=[UIColor blackColor];
  
    self.playView=[[UIImageView alloc]initWithFrame:CGRectMake(self.vedioBtn.bounds.size.width/2-30, self.vedioBtn.bounds.size.height/2-30,60, 60)];
    self.playView.image=[UIImage imageNamed:@"shipin.png"];
    [self.vedioBtn addSubview:self.playView];

    
 
 
}
-(void)prepareForReuse
{
    self.my=NO;
    self.playView=nil;
}
- (IBAction)setPersonInfo:(UIButton *)sender {
    UserManager * uManager=[UserManager shareManager];
    if (self.my) {
        self.tapBlock(uManager.personInfo);
    }
    else
    {
        self.tapBlock(uManager.otherInfo);
    }
}
/*
-(void)movieThumbnailLoadComplete:(NSNotification*)notification{
    
    NSLog(@"userInfo:%@",notification.userInfo);
    
    NSDictionary *userInfo = [notification userInfo];
    
    
    
    NSNumber *timecode =[userInfo objectForKey: @"MPMoviePlayerThumbnailTimeKey"];
  
    UIImage *thumbnail =[userInfo objectForKey: @"MPMoviePlayerThumbnailImageKey"];
    UIImage * image= [MUser thumbnailWithImageWithoutScale:thumbnail size:self.vedioBtn.frame.size];
    [self.vedioBtn setBackgroundImage:image forState:UIControlStateNormal];
        
    [_p stop];
    _p = nil;
    
  
    
    
    
}
-(void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}
*/
@end
