//
//  MainView.h
//  HiddenLove
//
//  Created by mac on 15/3/27.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef enum : NSUInteger
{
    PhotoBtn,
    VoivceBtn,
    VedioBtn,
}WhichBtn;
typedef void(^buttonBlock)(NSUInteger);
@interface MainView : UIView
@property (strong, nonatomic) buttonBlock  btnBlock;
-(void)setBtnBlock:(buttonBlock)btnBlock;
-(void)addImage;
@end
