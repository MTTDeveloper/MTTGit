//
//  AboutUSTableViewController.m
//  HiddenLove
//
//  Created by mac on 15/4/30.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "AboutUSTableViewController.h"
#import "SlideNavigationController.h"
@interface AboutUSTableViewController()

@end
@implementation AboutUSTableViewController
- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}
- (IBAction)openTel:(UIButton *)sender {
    
    NSMutableString * str=[[NSMutableString alloc] initWithFormat:@"telprompt://%@",sender.titleLabel.text];
                NSLog(@"str======%@",str);
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
    
}
- (IBAction)openUrl:(UIButton *)sender {
    
    UIStoryboard * s=[UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UIViewController * vc=[s instantiateViewControllerWithIdentifier:@"web"];
    [vc setValue:sender.titleLabel.text forKey:@"urlString"];
    [self.navigationController pushViewController:vc animated:YES];
    

}
@end
