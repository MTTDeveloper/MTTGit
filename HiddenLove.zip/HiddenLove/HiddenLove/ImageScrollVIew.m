//
//  ImageScrollVIew.m
//  HiddenLove
//
//  Created by mac on 15/3/29.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "ImageScrollVIew.h"
#import "MUser.h"
#import "ScrollImageView.h"
@interface ImageScrollVIew()<UIScrollViewDelegate>

//@property (strong, nonatomic) IBOutlet NSLayoutConstraint *leading;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *leading;

@property (strong, nonatomic) NSMutableArray * images;
@property (strong, nonatomic)ScrollImageView * scrollImageView;
@property (nonatomic,strong)UIPageControl * pageControl;
@end
@implementation ImageScrollVIew

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(void)addWithImages:(NSMutableArray *)array
{
    [self delectBtn];
    self.images=array;
    for (int i=0;i<self.images.count;i++)
    {
        
        UIButton * imageBtn=[UIButton buttonWithType:UIButtonTypeCustom];
       // imageBtn.backgroundColor=[UIColor blueColor];
        imageBtn.tag=100+i;
        [self addSubview:imageBtn];
        [imageBtn setImage:array[i] forState:UIControlStateNormal];
        [imageBtn addTarget:self action:@selector(tap:) forControlEvents:UIControlEventTouchUpInside];
        imageBtn.translatesAutoresizingMaskIntoConstraints=NO;
        UILongPressGestureRecognizer * longPressGr = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressToDo:)];
        longPressGr.minimumPressDuration = 1.5;
        [imageBtn addGestureRecognizer:longPressGr];
        NSString * str=[NSString stringWithFormat:@"|-%f-[imageBtn(60)]",i*60.0+8.0*(i+1)];
        NSArray * wArr=[NSLayoutConstraint constraintsWithVisualFormat:str options:0 metrics:nil views:NSDictionaryOfVariableBindings(imageBtn)];
        NSArray * hArr=[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[imageBtn(60)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(imageBtn)];
        [self addConstraints:wArr];
        [self addConstraints:hArr];
        
        
    }
 
    self.addImageBtn.translatesAutoresizingMaskIntoConstraints=NO;
//NSString * w=[NSString stringWithFormat:@"H:|-%f-[_addImageBtn]",array.count*68.0+8.0];
//    NSArray * addArr=[NSLayoutConstraint constraintsWithVisualFormat:w options:0 metrics:nil views:NSDictionaryOfVariableBindings(_addImageBtn)];
//    [self addConstraints:addArr];
    self.leading.constant=array.count*60.0+8.0*(self.images.count+1);
    [self.addImageBtn layoutIfNeeded];
    NSLog(@"%f", self.addImageBtn.frame.origin.x);
    if(self.addImageBtn.frame.origin.x+68>SCREEN_Width)
    {
        self.contentOffset=CGPointMake(self.addImageBtn.frame.origin.x+68-SCREEN_Width, 0);
    }
}
-(void)longPressToDo:(UILongPressGestureRecognizer *)sender
{
    UIButton * button=(UIButton*)sender.view;
    UIButton * delectBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    [delectBtn setBackgroundImage:[UIImage imageNamed:@"shanchu1.png"] forState:UIControlStateNormal];
    delectBtn.frame=button.bounds;
    [button addSubview:delectBtn];
    [delectBtn addTarget:self action:@selector(delectImage:) forControlEvents:UIControlEventTouchUpInside];
    
    
    }
-(void)delectImage:(UIButton *)sender
{
    UIButton * button=(UIButton *)sender.superview;
    int count=(int)button.tag;
    [self delectBtn];
    self.delectBlock(count-100);
    
}
- (IBAction)addImage:(id)sender {
    self.imageBlock();
}
-(void)tap:(UIButton *)sender
{
    if (self.images.count>0) {
        int count=(int)sender.tag-100;
        self.scrollImageView=[[ScrollImageView alloc]initWithArray:self.images andInt:count];
        self.scrollImageView.delegate=self;
        UIWindow * window= [UIApplication sharedApplication].keyWindow;
        [window addSubview:self.scrollImageView];
        if (self.images.count>1) {
            
        
        self.pageControl=[[UIPageControl alloc]initWithFrame:CGRectMake(30, SCREEN_Height-40, SCREEN_Width-60,30)];
        self.pageControl.numberOfPages=self.images.count;
        self.pageControl.currentPage=count;
//            self.pageControl.backgroundColor=[UIColor redColor];
        [window addSubview:self.pageControl];
        }
    }
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView==self.scrollImageView) {
        self.pageControl.currentPage=scrollView.contentOffset.x/SCREEN_Width;
    }
   
}
-(void)delectBtn
{
    for (int i=0;i<self.images.count;i++) {
        UIButton * button=(UIButton *)[self viewWithTag:(100+i)];
        [button removeFromSuperview];
        
    }
}
@end
