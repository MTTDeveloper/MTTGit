//
//  MainView.m
//  HiddenLove
//
//  Created by mac on 15/3/27.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "MainView.h"
#import "MUser.h"
@interface MainView ()
@property (strong, nonatomic) IBOutlet UIButton *one;
@property (strong, nonatomic) IBOutlet UIButton *two;
@property (strong, nonatomic) IBOutlet UIButton *three;

@end

@implementation MainView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if(self)
    {
      
        
    }
    return self;
}
-(void)addImage
{
//    CGFloat w=(SCREEN_Width-20)/3;
//    
//    CGFloat width=w/2-40;
//    UIImageView * imageV1=[[UIImageView alloc]initWithFrame:CGRectMake(width, 0, 60, 60)];
//    imageV1.image=[UIImage imageNamed:@"xiangji.png"];
//    [self.one addSubview:imageV1];
//    UIImageView * imageV2=[[UIImageView alloc]initWithFrame:CGRectMake(width, 0, 60, 60)];
//    imageV2.image=[UIImage imageNamed:@"luyinji.png"];
//    [self.two addSubview:imageV2];
//    UIImageView * imageV3=[[UIImageView alloc]initWithFrame:CGRectMake(width, 0, 60, 60)];
//    imageV3.image=[UIImage imageNamed:@"shexiangji.png"];
//    [self.three addSubview:imageV3];
}
- (IBAction)tapBtn:(UIButton *)sender
{
    switch (sender.tag) {
        case 101:
            self.btnBlock(PhotoBtn);
            break;
        case 102:
            self.btnBlock(VoivceBtn);
            break;
        case 103:
            self.btnBlock(VedioBtn);
            break;
        default:
            break;
    }
    
}

@end
