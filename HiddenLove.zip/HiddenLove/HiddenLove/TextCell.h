//
//  TextCell.h
//  HiddenLove
//
//  Created by mac on 15/3/19.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UITableViewCell+add.h"
@interface TextCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIView *backgroundView;
@property (strong, nonatomic) IBOutlet UIButton *headBtn;
@property (strong, nonatomic) IBOutlet UIButton *nameBtn;
@property (strong, nonatomic) IBOutlet UILabel *text;
@property (strong, nonatomic) IBOutlet UILabel *dateText;

@end
