//
//  MoreImageCell.m
//  HiddenLove
//
//  Created by mac on 15/3/19.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "MoreImageCell.h"
#import "UIImageView+WebCache.h"
#import "UIButton+WebCache.h"
#import "ScrollImageView.h"

@interface MoreImageCell()<UIScrollViewDelegate>
@property (nonatomic,strong)TapBLOCK tapBlock;

@property (strong, nonatomic) IBOutlet UIView *bgView;
@property (strong, nonatomic) IBOutlet UIView *detailVIew;
@property (strong, nonatomic) IBOutlet UIButton *headBtn;
@property (strong, nonatomic) IBOutlet UILabel *text;
@property (strong, nonatomic) IBOutlet UIButton *nameBtn;
@property (strong, nonatomic) IBOutlet UIImageView *firstImageView;
@property (strong, nonatomic) IBOutlet UIImageView *secondImageView;
@property (strong, nonatomic) IBOutlet UIImageView *thirdImageView;
@property (strong, nonatomic) IBOutlet UIImageView *fourthImageView;
@property (strong, nonatomic) IBOutlet UIImageView *fifthImageView;
@property (strong, nonatomic) IBOutlet UIImageView *sixthImageView;
@property (strong, nonatomic) IBOutlet UIImageView *seventhImageView;
@property (strong, nonatomic) IBOutlet UIImageView *eighthImageView;
@property (strong, nonatomic) IBOutlet UIImageView *ninthImageView;
@property (strong, nonatomic) NSArray * images;
@property (strong, nonatomic) NSMutableArray * arr;
@property (strong, nonatomic) IBOutlet UILabel *dateText;
@property (strong, nonatomic)  NSArray * imageArr;

@property (strong, nonatomic)ScrollImageView * scrollImageView;
@property (nonatomic,strong)UIPageControl * pageControl;
@property (nonatomic,assign)BOOL my;
@end
@implementation MoreImageCell

-(void)awakeFromNib
{
    NSString * sex=[self getSex];
    self.bgView.backgroundColor=[MUser hexStringToColor:@"eaf4fc"];
    [self.headBtn setBackgroundImage:[UIImage imageNamed:@"tyzongjian.png"] forState:UIControlStateNormal];
    
    if ([sex isEqualToString:@"nv"]) {
        self.bgView.backgroundColor=[MUser hexStringToColor:@"f8f4e6"];
        [self.headBtn setBackgroundImage:[UIImage imageNamed:@"tyyuangong.png"] forState:UIControlStateNormal];
    }
    
    self.bgView.layer.cornerRadius=5;
    self.bgView.layer.masksToBounds=YES;
    _arr=[NSMutableArray array];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)prepareForReuse
{
    NSLog(@"11");
     [self delectImages];
    self.my=NO;
    [_arr removeAllObjects];
   
}
-(void)setCellInfo:(NSDictionary * )dic
{
    UserManager * uManager=[UserManager shareManager];
    NSString * str=dic[@"fromUid"];
      if([str isEqualToString:uManager.uid])
    {
       
        [self.headBtn sd_setBackgroundImageWithURL:uManager.personInfo[@"headImage"] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"tyzongjian.png"]];
        
         [self.nameBtn setTitle:uManager.personInfo[@"name"] forState:UIControlStateNormal];
        self.my=YES;
    }
    else
    {
     if (str.length>1) {
     [self.headBtn sd_setBackgroundImageWithURL:uManager.otherInfo[@"headImage"] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"tyzongjian.png"]];
          [self.nameBtn setTitle:uManager.otherInfo[@"name"] forState:UIControlStateNormal];
         }
     else
     {
         [self.headBtn setBackgroundImage:[UIImage imageNamed:@"tyzongjian.png"] forState:UIControlStateNormal];
         
     }
    }
    self.text.attributedText=[self changeTextWithBiaoqing:dic[@"text"]];
    self.dateText.text=[self getSendDate:dic[@"date"]];
    _imageArr=[dic[@"content"] componentsSeparatedByString:@"|"];

    if (_imageArr.count==4) {
        _images=@[self.firstImageView,self.secondImageView,self.fourthImageView,self.fifthImageView];
        }
    else {
        _images=@[self.firstImageView,self.secondImageView,self.thirdImageView,self.fourthImageView,self.fifthImageView,self.sixthImageView,self.seventhImageView,self.eighthImageView,self.ninthImageView];
       }
    for (int i=0; i<_imageArr.count; i++) {
        
        UIImageView *imageView=_images[i];
        [imageView sd_setImageWithURL:[NSURL URLWithString:_imageArr[i]] placeholderImage:[UIImage imageNamed:@"tp1.png"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            if (image) {
                [_arr addObject:image]; 
            }
           
        }];
            
        imageView.userInteractionEnabled=YES;
        imageView.backgroundColor=[UIColor blackColor];
        imageView.tag=1000+i;
        UITapGestureRecognizer * tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
        tap.numberOfTapsRequired=1;
        [imageView addGestureRecognizer:tap];
      
    }
}
-(void)tap:(UITapGestureRecognizer *)sender
{
    if (_arr.count>0) {
    UIImageView * imageview=(UIImageView *)[sender view];
    int count=(int)imageview.tag-1000;
    self.scrollImageView=[[ScrollImageView alloc]initWithArray:_arr andInt:count];
    self.scrollImageView.delegate=self;
    UIWindow * window= [UIApplication sharedApplication].keyWindow;
    [window addSubview:self.scrollImageView];
    self.pageControl=[[UIPageControl alloc]initWithFrame:CGRectMake(30, SCREEN_Height-40, SCREEN_Width-60,30)];
    self.pageControl.numberOfPages=_arr.count;
    self.pageControl.currentPage=count;
    [window addSubview:self.pageControl];
    }
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    self.pageControl.currentPage=scrollView.contentOffset.x/SCREEN_Width;
}
-(void)delectImages
{
    for (int i=0; i<_imageArr.count; i++) {
        UIImageView * imageView=_images[i];
        imageView.image=nil;
    }
}
- (IBAction)setPersonInfo:(UIButton *)sender {
    
    UserManager * uManager=[UserManager shareManager];
    if (self.my) {
        self.tapBlock(uManager.personInfo);
    }
    else
    {
        self.tapBlock(uManager.otherInfo);
    }
    
}
@end
