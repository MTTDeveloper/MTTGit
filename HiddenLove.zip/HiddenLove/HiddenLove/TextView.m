//
//  TextView.m
//  HiddenLove
//
//  Created by mac on 15/3/31.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "TextView.h"
#import "MUser.h"
#import "ToolBar.h"
@interface TextView ()<FaceBoardDelegate,FaceBoardSource>
@property (strong, nonatomic) ToolBar * toolBar;
@property (nonatomic,strong)NSArray *faceData;
@property (nonatomic, strong)NSMutableArray *newfaceData;
@end
@implementation TextView


-(void)awakeFromNib
{
    NSString *path = [[NSBundle mainBundle]pathForResource:@"emotions" ofType:@"plist"];
    self.faceData = [NSArray arrayWithContentsOfFile:path];
    self.newfaceData = [NSMutableArray arrayWithCapacity:self.faceData.count];
    for (int i = 0; i < self.faceData.count; i++) {
        
        NSString *pngName = self.faceData[i][@"png"];
        NSString *name = self.faceData[i][@"chs"];
        UIImage *image = [UIImage imageNamed:pngName];
        NSData *imageData = UIImagePNGRepresentation(image);
        NSDictionary *dic = @{@"name":name,@"data":imageData};
        [self.newfaceData addObject:dic];
    }
    
  
    self.faceBoard = [[FaceBoard alloc]initWithFrame:CGRectMake(0, 0,SCREEN_Width , 250)];
    self.faceBoard.backgroundColor = [UIColor whiteColor];
    self.faceBoard.delegate = self;
    self.faceBoard.source = self;
    
    self.toolBar=(ToolBar *)[self initWithName:@"ToolBar"];
    [self.toolBar addImages];
    self.inputAccessoryView=self.toolBar;
    __block __weak TextView * copy_self=self;
    [self.toolBar setDownBlock:^{
        [copy_self resignFirstResponder];
    }];
    [self.toolBar setChangeBlock:^(BOOL faceBoard){
       
        [copy_self changeFaceBoard:faceBoard];
    }];
}
-(id)initWithName:(NSString *)name
{
    NSArray * array=[[NSBundle mainBundle]loadNibNamed:name owner:nil options:nil];
    return [array firstObject];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(void)changeFaceBoard:(BOOL)faceBoard
{
    
    if (faceBoard) {
    self.inputView=self.faceBoard;
    }
    else
    {
        self.inputView=nil;
    }
    [self reloadInputViews];
}


-(NSString*)contentToString
{
    
    NSMutableAttributedString *mutableAttString = [[NSMutableAttributedString alloc]initWithAttributedString:self.attributedText];
    NSMutableArray *fetchedFacesArray = [NSMutableArray array];
    [mutableAttString enumerateAttributesInRange:NSMakeRange(0, mutableAttString.length) options:NSAttributedStringEnumerationReverse usingBlock:^(NSDictionary *attrs, NSRange range, BOOL *stop) {
        NSTextAttachment *attachment = attrs[@"NSAttachment"];
        if (attachment) {
            UIImage *image = attachment.image;
            NSValue *position = [NSValue valueWithRange:range];
            NSDictionary *dic = @{@"image":image,@"range":position};
            [fetchedFacesArray addObject:dic];
        }
    }];
    
    for (int i = 0; i < fetchedFacesArray.count; i++) {
        NSDictionary *dic = fetchedFacesArray[i];
        UIImage *image = dic[@"image"];
        NSRange range = [dic[@"range"] rangeValue];
        NSString *imageName = [self getNameOfImage:image];
        [mutableAttString replaceCharactersInRange:range withString:imageName];
    }
    return mutableAttString.string;
}


-(NSString *)getNameOfImage:(UIImage*)image
{
    NSData *data = UIImagePNGRepresentation(image);
    for (int i = 0; i < self.newfaceData.count; i++) {
        NSData *data2 = self.newfaceData[i][@"data"];
        if ([data isEqualToData:data2]) {
            NSString *name = self.newfaceData[i][@"name"];
            return name;
        }
    }
    return nil;
}
#pragma mark - faceBoardDelegate
//贴图
-(void)faceBoard:(FaceBoard *)faceBoard didTapButtonIndex:(NSInteger)buttonIndex
{
    NSString *name = self.faceData[buttonIndex][@"png"];
    UIImage *image = [UIImage imageNamed:name];
    
    NSMutableAttributedString *mutableAttString = [[NSMutableAttributedString alloc]initWithAttributedString:self.attributedText];
    NSTextAttachment *attachment = [[NSTextAttachment alloc]init];
    attachment.image = image;
    NSAttributedString *imageString = [NSAttributedString attributedStringWithAttachment:attachment];
    [mutableAttString appendAttributedString:imageString];
    self.attributedText = mutableAttString;

    
}
#pragma mark - faceBoardSource
-(NSInteger)numberOfFacesInKeyBoard:(FaceBoard *)faceBoard
{
    return self.faceData.count;
}
-(UIImage *)faceBoard:(FaceBoard *)faceBoard imageAtButtonIndex:(NSInteger)buttonIndex
{
    NSString *name = self.faceData[buttonIndex][@"png"];
    UIImage *image = [UIImage imageNamed:name];
    return image;
}
@end
