//
//  StateManager.m
//  HiddenLove
//
//  Created by mac on 15/3/16.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "StateManager.h"
#import "AFHTTPRequestOperationManager.h"
#import "MUser.h"
@interface StateManager()
@property(nonatomic,strong)AFHTTPRequestOperationManager * afManager;

@property(nonatomic,strong)NSOperationQueue * queue;

@end


@implementation StateManager

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


+(instancetype)shareManager
{

    
    static StateManager * s=nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        s = [[StateManager alloc]init];
    });
    return s;
}


-(instancetype)init
{
    self = [super init];
    if (self) {
        self.afManager = [AFHTTPRequestOperationManager manager];
    }
    return self;
}
-(void)postStatesWithUID:(NSString *)uid Dic:(NSMutableDictionary *)dic BlockHandle:(SMBlock)block
{
    NSArray * array=dic[@"files"];
    [dic setObject:uid forKey:@"uid"];
    _queue=[[NSOperationQueue alloc]init];
    NSMutableArray * operations=[NSMutableArray array];
    NSMutableString * urls=[NSMutableString string];
    _queue.maxConcurrentOperationCount=1;
    if (array.count>0) {
        for (int i=0; i<array.count; i++)
        {
            NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer]multipartFormRequestWithMethod:@"POST" URLString:@"http://anlianlove.sinaapp.com/uploadfile.php" parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
                if ([dic[@"type"]isEqualToString:@"image"]) {
                    UIImage *image=array[i];
                    NSString * name=[NSString stringWithFormat:@"test.png"];
                    [formData appendPartWithFileData:UIImagePNGRepresentation(image) name:@"file" fileName:name mimeType:@"image/png"];
                }
                else if([dic[@"type"]isEqualToString:@"voice"])
                {
                    [formData appendPartWithFileData:array[i] name:@"file" fileName:@"test.wav" mimeType:@"audio/x-wav"];
                    
                }
                else if([dic[@"type"]isEqualToString:@"video"])
                {
                    [formData appendPartWithFileData:array[i] name:@"file" fileName:@"test.mov" mimeType:@"video/quicktime"];
                }
                
               
                
            } error:nil];
            
            AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc]initWithRequest:request];
            __block  __weak AFHTTPRequestOperation * copy=operation;
            operation.name=[NSString stringWithFormat:@"sad%d",i];
            [operation setUploadProgressBlock:^(NSUInteger bytesWritten, long long totalBytesWritten, long long totalBytesExpectedToWrite) {
                NSLog(@"cur %@",[NSThread currentThread]);
                NSLog(@"%@",copy.name);
            }];
            [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, NSData * responseObject) {
                NSError * error;
                NSDictionary * dic1 = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:&error];
                if (dic1 == nil)
                {
                    NSLog(@"%@",error.localizedDescription);
                    return ;
                }
                NSString * isS = dic1[@"success"];
                if ([isS isEqualToString:@"0"]) {
                   
                [urls appendString:[NSString stringWithFormat:@"%@|",dic1[@"url"]]];
                                  }
                
                NSLog(@"成功");
            } failure:^(AFHTTPRequestOperation *operation, NSError *error)
             {
                 NSLog(@"%@",error.localizedDescription);
                NSLog(@"失败");
            }];
            [operations addObject:operation];
            NSLog(@"cur %@",[NSThread currentThread]);
           // [_queue addOperation:operation];
          
        }
    
        NSArray *ops = [AFURLConnectionOperation batchOfRequestOperations:operations progressBlock:^(NSUInteger numberOfFinishedOperations, NSUInteger totalNumberOfOperations) {
            NSLog(@"%lu of %lu complete", (unsigned long)numberOfFinishedOperations, (unsigned long)totalNumberOfOperations);
           
        } completionBlock:^(NSArray *operations) {
            NSLog(@"All operations in batch complete %@",operations[0]);
             NSLog(@"1111成功");
            if (urls.length>0) {
                NSString * url=[urls substringToIndex:(urls.length-1)];
                NSLog(@"url%@",url);
                [dic setObject:url forKey:@"content"];
                [dic removeObjectForKey:@"files"];
                [self postParameter:dic URL:@"http://anlianlove.sinaapp.com/postState.php" blockHandle:block];
            }
            else
            {
                block(@{@"success":@"1"});
            }
         
            
        }];
 
          [_queue addOperations:ops waitUntilFinished:NO];
    }
    else
    {
           [dic setObject:@"" forKey:@"content"];
         [self postParameter:dic URL:@"http://anlianlove.sinaapp.com/postState.php" blockHandle:block];
    }
  
}
-(void)postParameter:(NSDictionary *)parameter URL:(NSString *)url blockHandle:(SMBlock)block
{
    
    
    AFHTTPRequestOperation * op =[self.afManager POST:url parameters:parameter success:^(AFHTTPRequestOperation *operation, NSData * responseObject) {
        NSError * error;
        NSString * str=[[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
        NSLog(@"...str%@",str);
        NSDictionary * dic= [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:&error];
        if (dic == nil)
        {
            NSLog(@"%@",error.localizedDescription);
            return ;
        }
        NSString * isS = dic[@"success"];
        
        if ([isS integerValue] == 0)
        {
            block(dic);
        }
        else
        {
            [MUser alertViewShowTitle:@"提示" andMessage:@"数据上传失败" andDelegate:self controltag:1000];
        }
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error.localizedDescription);
        [self tishi];

    }];
    op.responseSerializer = [AFHTTPResponseSerializer serializer];
    [op start];
    
}
-(void)getTextBlockHandle:(SMBlock)block
{
   
}
//获取日记信息
-(void)getStatesWithUID:(NSString *)uid BlockHandle:(SMBlock)block
{
    NSMutableDictionary * dic1=[NSMutableDictionary dictionary];
    [dic1 setObject:uid forKeyedSubscript:@"uid"];
    AFHTTPRequestOperation * op =[self.afManager POST:@"http://anlianlove.sinaapp.com/getState.php" parameters:dic1 success:^(AFHTTPRequestOperation *operation, NSData * responseObject) {
        NSError * error;
        NSDictionary * dic= [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:&error];
        if (dic == nil)
        {
            NSLog(@"%@",error.localizedDescription);
            return ;
        }
        NSString * isS = dic[@"success"];
        
        if ([isS integerValue] == 0)
        {
            block(dic);
        }
        else
        {
            block(dic);
            [MUser alertViewShowTitle:@"提示" andMessage:@"数据上传失败" andDelegate:self controltag:1000];
        }
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error.localizedDescription);
        block(nil);
        [self tishi];
    }];
    op.responseSerializer = [AFHTTPResponseSerializer serializer];
    [op start];
}

-(void)tishi
{
    [MUser alertViewShowTitle:@"提示" andMessage:@"网络连接超时" andDelegate:self controltag:1000];
}
@end
