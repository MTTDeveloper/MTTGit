//
//  VoiceView.m
//  HiddenLove
//
//  Created by mac on 15/3/27.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "VoiceView.h"
#import "LCVoiceHud.h"
#import "MUser.h"
#import <AVFoundation/AVFoundation.h>
@interface VoiceView()<AVAudioRecorderDelegate,AVAudioPlayerDelegate>
@property (strong, nonatomic) IBOutlet UIButton *playBtn;
@property (strong, nonatomic) IBOutlet UIButton *recordBtn;
@property (strong, nonatomic) IBOutlet UIButton *delectBtn;
@property (strong, nonatomic) IBOutlet UIImageView *voiceImageView;
@property (nonatomic, strong) AVAudioRecorder *recorder;
@property (nonatomic, strong) AVAudioPlayer *player;
@property (nonatomic, strong) NSTimer * timer;
@property (nonatomic, strong) LCVoiceHud *voiceHud;
@property (nonatomic, copy)   NSString *  documentString;
@property (nonatomic, strong) UIColor * yuanColor;
@end
@implementation VoiceView

-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if(self)
    {
        [self initRecorder];
      
    }
    return self;
}
-(void)yuanjiao
{
    self.recordBtn.layer.cornerRadius=5;
    self.recordBtn.layer.masksToBounds=YES;
    self.yuanColor=self.recordBtn.backgroundColor;
}
-(void)initImageAnimation{
    
    NSString *strImageA,*strImageB,*strImageC;
    strImageA = @"yuyin3";
    strImageB = @"yuyin2";
    strImageC = @"yuyin1";
    NSString *strName = @"yuyin1.png";
    
    UIImage *imageA = [UIImage imageNamed:strImageA];
    UIImage *imageB = [UIImage imageNamed:strImageB];
    UIImage *imageC = [UIImage imageNamed:strImageC];

    self.voiceImageView.animationImages = @[imageA,imageB,imageC];
    self.voiceImageView.image = [UIImage imageNamed:strName];
    self.voiceImageView.animationDuration = 1.0;
    self.voiceImageView.hidden=YES;

}


-(void)initRecorder
{
    
//    AVAudioSession * audioSession = [AVAudioSession sharedInstance];
//    
//    [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord error: nil]; //设置音频类别，这里表示当应用启动，停掉后台其他音频
//    
//    [audioSession setActive:YES error:nil];//设置当前应用音频活跃性
    NSMutableDictionary *settingDictionary = [[NSMutableDictionary alloc]init];
    [settingDictionary setObject:[NSNumber numberWithInt:kAudioFormatLinearPCM] forKey:AVFormatIDKey];
    [settingDictionary setObject:[NSNumber numberWithInt:2] forKey:AVNumberOfChannelsKey];
    [settingDictionary setObject:[NSNumber numberWithInt:8000] forKey:AVSampleRateKey];
    [settingDictionary setObject:[NSNumber numberWithInt:16] forKey:AVLinearPCMBitDepthKey];
    [settingDictionary setObject:[NSNumber numberWithInt:AVAudioQualityHigh] forKey:AVEncoderAudioQualityKey];
    _documentString   = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    
    NSURL *url = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/record.wav",_documentString] isDirectory:NO];
    NSError * error;
    _recorder = [[AVAudioRecorder alloc]initWithURL:url settings:settingDictionary error:&error];
    if(error){
        NSLog(@"%@,%@ ,%@ ,%@",self,error,[error userInfo],[error description ] );
        abort();
    }
    _recorder.delegate = self;
    // 可否测量峰值
    _recorder.meteringEnabled = YES;
    //设置音频管理者
    AVAudioSession * session = [AVAudioSession sharedInstance];
    NSError * sessionError;
    [session setCategory:AVAudioSessionCategoryPlayAndRecord error:&sessionError];
    if (sessionError)
    {
        NSLog(@"sessionError = %@",sessionError.localizedDescription);
    }else
    {
        [session setActive:YES error:nil];
    }
    
}
- (IBAction)play:(id)sender
{
    NSLog(@"播放声音");
    
    if(_player.isPlaying)
    {
        [self playStop];
    }else
    { [self initImageAnimation];
        if (!_audiowavPath||_audiowavPath.length==0) {
            [MUser alertViewShowTitle:@"提示" andMessage:@"您还没有录音" andDelegate:self controltag:1000];
            
        }else{
//        UInt32 doChangeDefaultRoute = 1;
//        AudioSessionSetProperty(kAudioSessionProperty_OverrideCategoryDefaultToSpeaker,sizeof(doChangeDefaultRoute), &doChangeDefaultRoute);
        NSData *wavdata = [NSData dataWithContentsOfFile:_audiowavPath];
        _player = [[AVAudioPlayer alloc]initWithData:wavdata error:nil];
        [_player  prepareToPlay];
        _player.volume = 1.0;
        _player.delegate=self;
        [_player play];
        self.voiceImageView.hidden=NO;
        [self.voiceImageView startAnimating];
       
    }
    }

}
- (void)playStop
{
    [_player stop];
    _player = nil;
     [self.voiceImageView stopAnimating];
}
- (IBAction)delect:(id)sender
{
    if (!_audiowavPath||_audiowavPath.length==0) {
        [MUser alertViewShowTitle:@"提示" andMessage:@"您还没有录音" andDelegate:self controltag:1000];
    }
    else
    {
        NSFileManager * fileManager=[NSFileManager defaultManager];
        if ( [fileManager removeItemAtPath:_audiowavPath error:nil]) {
            _audiowavPath=@"";
            self.recordBtn.backgroundColor=self.yuanColor;
            [self.recordBtn setTitle:@"录音" forState:UIControlStateNormal];
            //录音按钮变颜色
        }
    }
    
}

- (IBAction)recordUp:(id)sender
{
   
    NSLog(@"结束录制");
    [_voiceHud hide];
    [_timer invalidate];
    _voiceHud = nil;
    int _voiceTime = [_recorder currentTime];
    if(_voiceTime > 1.0)
    {
        NSLog(@"录音成功");
        //发送录音、缓存录音、更新界面
        NSLog(@"time = %dS",_voiceTime);
        NSString * time=[NSString stringWithFormat:@"%ds",_voiceTime];
        [self.recordBtn setTitle:time forState:UIControlStateNormal];
        [_recorder stop];
        self.recordBtn.backgroundColor=[MUser hexStringToColor:@"3eb370"];
    }
    else
    {
        [_recorder stop];
        [_recorder deleteRecording];
        return;
    }
    _audiotime =_voiceTime;
    //NSFileManager *fileManager = [[NSFileManager alloc]init];
    _audiowavPath = [NSString stringWithFormat:@"%@/record.wav",_documentString];


}
- (IBAction)recordDown:(UIButton *)sender {
    NSLog(@"语音按钮");
    
   
    BOOL record = [_recorder prepareToRecord];
    if(record == YES)
    {
        [_recorder record];
    }
    _timer = [NSTimer scheduledTimerWithTimeInterval:0.05 target:self selector:@selector(updateMeters) userInfo:nil repeats:YES];
    _voiceHud = [[LCVoiceHud alloc] init];
    [_voiceHud show];
    
}
- (void)updateMeters {
    
    
    if (_voiceHud)
    {
        /*  发送updateMeters消息来刷新平均和峰值功率。
         *  此计数是以对数刻度计量的，-160表示完全安静，
         *  0表示最大输入值
         */
        
        if (_recorder) {
            [_recorder updateMeters];
        }
        
        float peakPower = [_recorder averagePowerForChannel:0];
        double ALPHA = 0.05;
        double peakPowerForChannel = pow(10, (ALPHA * peakPower));
        
        [_voiceHud setProgress:peakPowerForChannel];
    }
}
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    NSLog(@"播放完毕 - %@,%f",flag?@"YES":@"NO",player.duration);
    
    [self.voiceImageView stopAnimating];
    self.voiceImageView.hidden=YES;
}
- (void)audioPlayerDecodeErrorDidOccur:(AVAudioPlayer *)player error:(NSError *)error
{
    NSLog(@"cuowu");
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
