//
//  SetPersonInfoController.m
//  HiddenLove
//
//  Created by mac on 15/4/22.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "SetPersonInfoController.h"
#import "MUser.h"
#import "UIImageView+AFNetworking.h"
#import "UIButton+AFNetworking.h"
@interface SetPersonInfoController()
@property (strong, nonatomic) IBOutlet UIButton *headImage;
@property (strong, nonatomic) IBOutlet UIImageView *backgroundImage;
@property (strong, nonatomic) IBOutlet UITextField *name;
@property (strong, nonatomic) IBOutlet UITextField *mytel;
@property (strong, nonatomic) IBOutlet UIImageView *sexImage;
@property (strong, nonatomic) IBOutlet UITextField *sign;
@property (strong, nonatomic) IBOutlet UITextField *otherName;
@property (strong, nonatomic) IBOutlet UITextField *otherTel;
@property (strong, nonatomic) NSString * sex;

@end


@implementation SetPersonInfoController

-(void)viewDidLoad
{
    self.tableView.rowHeight=UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 100;
    NSDictionary * info=self.dic;
    
     [self.headImage setBackgroundImageForState:UIControlStateNormal withURL:[NSURL URLWithString:info[@"headImage"]] placeholderImage:[UIImage imageNamed:@"weizhitouxiang.png"]];
 
    self.name.text=info[@"name"];
    self.sex=info[@"sex"];
    if ([self.sex isEqualToString:@"nv"]) {
        self.sexImage.image=[UIImage imageNamed:@"nv.png"];
        self.backgroundImage.backgroundColor=[MUser hexStringToColor:@"f8f4e6"];
        
    }
    else if([self.sex isEqualToString:@"nan"])
    {
        self.sexImage.image=[UIImage imageNamed:@"nan.png"];
        self.backgroundImage.backgroundColor=[MUser hexStringToColor:@"eaf4fc"];
    }
    self.mytel.text=info[@"tel"];
    self.sign.text=info[@"sign"];
    self.otherName.text=info[@"darling"];
    self.otherTel.text=info[@"otherTel"];
   
}
#pragma mark - Table view data source
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.01;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    [self.tableView endEditing:YES];
    
}
@end
