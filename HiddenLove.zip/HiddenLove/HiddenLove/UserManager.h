//
//  UserManager.h
//  HiddenLove
//
//  Created by mac on 15/3/16.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^UMBlock)(NSDictionary * dic);

typedef void(^UMBlockA)(BOOL isSuccess);

@interface UserManager : NSObject

+(instancetype)shareManager;


-(void)getCodeWithTel:(NSString *)tel BlockHandle:(UMBlockA)block;

-(void)autheCode:(NSString *)code TEl:(NSString *)tel BlockHandel:(UMBlock)block;
-(void)savePersonInfoWithDic:(NSDictionary *)dic BlockHandel:(UMBlockA)block;
-(void)getUserInfo:(NSDictionary *)dic BlockHandle:(UMBlock)block;
-(void)postdeviceToken;
-(void)saveWithDic:(id)dictionary Name:(NSString *)str;
@property(nonatomic,strong)NSString * uid;
@property(nonatomic,strong)NSString * tel;
@property(nonatomic,strong)NSString * otherUid;
@property(nonatomic,strong)NSDictionary * personInfo;
@property(nonatomic,strong)NSDictionary * otherInfo;




-(void)save;
-(void)delect;

//个人信息详情



@end
