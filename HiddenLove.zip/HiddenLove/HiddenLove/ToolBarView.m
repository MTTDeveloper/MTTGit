//
//  ToolBarView.m
//  HiddenLove
//
//  Created by mac on 15/3/31.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "ToolBarView.h"
@interface ToolBarView()
@property (strong, nonatomic) IBOutlet UIButton *faceBtn;
@property (strong, nonatomic) IBOutlet UIButton *down;

@end
@implementation ToolBarView
- (IBAction)tapFaceBtn:(UIButton *)sender {
    self.changeBlock(YES);
}
- (IBAction)tapDownBtn:(id)sender {
    self.downBlock();
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
