//
//  ImageCell.m
//  HiddenLove
//
//  Created by mac on 15/3/20.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "ImageCell.h"
#import "UITableViewCell+add.h"
#import "UIImageView+AFNetworking.h"
#import "UIButton+WebCache.h"
#import "VIPhotoView.h"
#import "MUser.h"
@interface ImageCell()
@property (nonatomic,strong)TapBLOCK tapBlock;

@property (strong, nonatomic) IBOutlet UIView *bgView;
@property (strong, nonatomic) IBOutlet UIButton *headImageB;
@property (strong, nonatomic) IBOutlet UIButton *userNameB;
@property (strong, nonatomic) IBOutlet UILabel *textL;
@property (strong, nonatomic) IBOutlet UIImageView *imageV;
@property (strong, nonatomic) IBOutlet UILabel *dateL;
@property (nonatomic,assign)BOOL my;
@end
@implementation ImageCell
-(void)awakeFromNib
{
    NSString * sex=[self getSex];
    self.bgView.backgroundColor=[MUser hexStringToColor:@"eaf4fc"];
    [self.headImageB setBackgroundImage:[UIImage imageNamed:@"tyzongjian.png"] forState:UIControlStateNormal];
    
    if ([sex isEqualToString:@"nv"]) {
        self.bgView.backgroundColor=[MUser hexStringToColor:@"f8f4e6"];
        [self.headImageB setBackgroundImage:[UIImage imageNamed:@"tyyuangong.png"] forState:UIControlStateNormal];
    }
    
    self.bgView.layer.cornerRadius=5;
    self.bgView.layer.masksToBounds=YES;

}
-(void)setCellInfo:(NSDictionary *)dic
{
    UserManager * uManager=[UserManager shareManager];
    NSString * str=dic[@"fromUid"];
    if([str isEqualToString:uManager.uid])
    {
        [self.headImageB sd_setBackgroundImageWithURL:uManager.personInfo[@"headImage"] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"tyzongjian.png"]] ;
         [self.userNameB setTitle:uManager.personInfo[@"name"] forState:UIControlStateNormal];
        self.my=YES;
    }
    else
    {
         if (str.length>1) {
        [self.headImageB sd_setBackgroundImageWithURL:uManager.otherInfo[@"headImage"] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"tyzongjian.png"]];
        [self.userNameB setTitle:uManager.otherInfo[@"name"] forState:UIControlStateNormal];
         }
         else
         {
              [self.headImageB setBackgroundImage:[UIImage imageNamed:@"tyzongjian.png"] forState:UIControlStateNormal];
             
         }
    }

    self.dateL.text=[self getSendDate:dic[@"date"]];
    self.textL.attributedText=[self changeTextWithBiaoqing:dic[@"text"]];
    NSString  * urlStr=dic[@"content"];

    [self.imageV setImageWithURL:[NSURL URLWithString:urlStr]  placeholderImage:[UIImage imageNamed:@"tp1.png"]];
    self.imageV.contentMode=UIViewContentModeScaleAspectFit;
    self.imageV.userInteractionEnabled=YES;
    UITapGestureRecognizer * tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
    tap.numberOfTapsRequired=1;
    [self.imageV addGestureRecognizer:tap];
    
  
    
  
}
-(void)tap:(UITapGestureRecognizer*)tap
{
    VIPhotoView * photoView=[[VIPhotoView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_Width, SCREEN_Height) andImage:self.imageV.image];
    UIView * view =[[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_Width, SCREEN_Height)];
    view.backgroundColor=[UIColor blackColor];
    [view addSubview:photoView];
    UIWindow * window= [UIApplication sharedApplication].keyWindow;
    [window addSubview:view];
}
-(void)prepareForReuse
{
    self.my=NO;
}
- (IBAction)setPersonInfo:(UIButton *)sender {
    UserManager * uManager=[UserManager shareManager];
    if (self.my) {
        self.tapBlock(uManager.personInfo);
    }
    else
    {
        self.tapBlock(uManager.otherInfo);
    }
    
}
@end
