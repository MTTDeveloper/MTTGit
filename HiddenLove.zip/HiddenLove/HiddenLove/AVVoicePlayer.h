//
//  AVVoicePlayer.h
//  HiddenLove
//
//  Created by mac on 15/3/23.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <AVFoundation/AVFoundation.h>

@interface AVVoicePlayer : AVAudioPlayer
+(instancetype)shareAVVoicePlayer:(NSData *)data;
@end
