//
//  SetPersonInfoController.h
//  HiddenLove
//
//  Created by mac on 15/4/22.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetPersonInfoController : UITableViewController
@property(nonatomic,strong)NSDictionary *dic;
@end
