//
//  SoundManager.m
//  HiddenLove
//
//  Created by mac on 15/3/24.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "SoundManager.h"

#import "AFNetworking.h"

#import <AVFoundation/AVFoundation.h>

#import "MUser.h"
@interface SoundManager ()<AVAudioPlayerDelegate>

@property(nonatomic,strong)NSMutableDictionary * blockDic;
@property(nonatomic,strong)NSMutableDictionary * loadingFlagDic;

@property(nonatomic,strong)AFHTTPRequestOperationManager * afManager;

@property (nonatomic,strong)AVAudioPlayer * player;


@end

@implementation SoundManager

+(instancetype)share
{
    static SoundManager * m = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        m = [[SoundManager alloc]init];
    });
    
    return m;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.blockDic = [NSMutableDictionary dictionary];
        self.loadingFlagDic = [NSMutableDictionary dictionary];
        self.afManager = [AFHTTPRequestOperationManager manager];
    }
    return self;
}

-(void)playORPauseWithURL:(NSString *)url
{
    SMBase block = (SMBase)self.blockDic[url];
    NSString * fileURL=[self pathWithURL:url];


    NSURL * u=[NSURL fileURLWithPath:fileURL];
    
    if ([self.player.url isEqual:u])
    {
        if (self.player.isPlaying)
        {
            [self.player pause];
            block(SoundDataStateWaitForPlay);
           
        }
        else
        {
            [self.player play];
            block(SoundDataStatePlaying);
            
        }
    }
    else{
        
        NSArray * arr=[self.blockDic allKeys];
        for (NSString * urlStr in arr) {
            SMBase base=self.blockDic[urlStr];
            base(SoundDataStateWaitForPlay);
        }
        [self playWithURL:fileURL];
    
         block(SoundDataStatePlaying);
    }

    
}



-(void)removeBlockHandleWithURL:(NSString *)url
{
    [self.blockDic removeObjectForKey:url];
}

-(void)playWithURL:(NSString *)url
{
    self.player=[[AVAudioPlayer alloc]initWithContentsOfURL:[NSURL fileURLWithPath:url] error:nil];
    NSLog(@"%lf",self.player.duration);
    self.player.delegate=self;
    // [self.player prepareToPlay];
    [self.player play];
    
}

-(void)soundURL:(NSString *)url changeStateBlockHandle:(SMBase)block
{
    [self.blockDic setObject:block forKey:url];
    
    NSString * path = [self pathWithURL:url];
    
    __weak __block SoundManager * copy_self = self;
    
    if (path)
    {
         block(SoundDataStateWaitForPlay);
    }
    else
    {
        block(SoundDataStateLoading);
        
        //通过loadingFlagDic检查是否下载
        
        BOOL isLoading = [self.loadingFlagDic[url] boolValue];
        
        if (isLoading == NO)
        {
            [self.loadingFlagDic setObject:[NSNumber numberWithBool:YES] forKey:url];
            //开始下载
            AFHTTPRequestOperation *op = [self.afManager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, NSData * responseObject) {
                //写入本地
                NSString * path=[self addStr:url];
                [responseObject writeToFile:path atomically:YES];
                block(SoundDataStateWaitForPlay);
                
                //回调block
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                NSLog(@"文件下载失败");
                [self tishi];
                [copy_self.loadingFlagDic setObject:[NSNumber numberWithBool:NO] forKey:url];
                block(SoundDataStateWaitForPlay);
                
            }];
            op.responseSerializer=[AFHTTPResponseSerializer serializer];
            [op start];
        }
        
        
    }
}
-(void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    NSArray * arr=[self.blockDic allKeys];
    for (NSString * urlStr in arr) {
        SMBase base=self.blockDic[urlStr];
        base(SoundDataStateWaitForPlay);
    }
}

-(NSString *)pathWithURL:(NSString *)url
{
    //将url后部分截取，对比本地是否有文件
    NSString * urlName=[self addStr:url];
    NSFileManager *fileManager=[NSFileManager defaultManager];
    
    //如果有回调return NO
    if ([fileManager fileExistsAtPath:urlName]) {
        return urlName;
    }
    return nil;
}
-(NSString *)addStr:(NSString *)url
{
    NSString * str=url.copy;
    NSRange range=[str rangeOfString:@"/"];
    while (range.length>0) {
        str=[str substringFromIndex:(range.location+1)];
        range=[str rangeOfString:@"/"];
    }
    NSArray *cacPath = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *cachePath = [cacPath objectAtIndex:0];
    NSString * urlName=[cachePath stringByAppendingPathComponent:str];
    return urlName;
}
-(void)tishi
{
    [MUser alertViewShowTitle:@"提示" andMessage:@"网络连接超时" andDelegate:self controltag:1000];
}

@end
