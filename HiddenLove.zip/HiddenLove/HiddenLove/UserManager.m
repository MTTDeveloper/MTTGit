//
//  UserManager.m
//  HiddenLove
//
//  Created by mac on 15/3/16.
//  Copyright (c) 2015年 aaa. All rights reserved.
//
#define GETCODE @"http://anlianlove.sinaapp.com/getCode.php"
#define CONFIRMCODE @"http://anlianlove.sinaapp.com/confirmCode.php"
#define UPLOADFILE @"http://anlianlove.sinaapp.com/uploadfile.php"
#define SETUSERINFO @"http://anlianlove.sinaapp.com/setUserInfo.php"
#define GETUSERINFO @"http://anlianlove.sinaapp.com/getUserInfo.php"
#import "UserManager.h"

#import "AFHTTPRequestOperationManager.h"
#import "MUser.h"
@interface UserManager ()

@property(nonatomic,strong)AFHTTPRequestOperationManager * afManager;




@end

@implementation UserManager

+(instancetype)shareManager
{
    static UserManager * m = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        m = [[UserManager alloc]init];
        [m loadInfo];
    });
    return m;
}

-(void)loadInfo
{
    //从userDefault中加载数据
    NSUserDefaults * user = [NSUserDefaults standardUserDefaults];
    
    self.uid = [user objectForKey:@"hlUID"];
    self.tel = [user objectForKey:@"hlTEL"];
    NSDictionary * dic=[user objectForKey:@"personInfo"];
    if (dic) {
        self.personInfo=dic;
    }
    NSDictionary * otherDic=[user objectForKey:@"otherpersonInfo"];
    if (otherDic) {
        self.otherInfo=otherDic;
    }
    NSString * otherUid=[user objectForKey:@"otherUid"];
    if (otherUid) {
     
        self.otherUid=otherUid;
    }

    
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.afManager = [AFHTTPRequestOperationManager manager];
    }
    return self;
}
-(void)savePersonInfoWithDic:(NSDictionary *)dic BlockHandel:(UMBlockA)block
{
    NSData * data=[dic objectForKey:@"headImage"];
    
    __block __weak UserManager  *copy_self = self;
    if (data)
    {
        AFHTTPRequestOperation * uploadImageop =[self.afManager POST:@"http://anlianlove.sinaapp.com/uploadfile.php" parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            NSData * data=[dic objectForKey:@"headImage"];

            [formData appendPartWithFileData:data name:@"file" fileName:@"test.png" mimeType:@"image/png"];
            
        } success:^(AFHTTPRequestOperation *operation, NSData * responseObject) {
            NSError * error;
            NSDictionary * dic1 = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:&error];
            if (dic1 == nil)
            {
                NSLog(@"%@",error.localizedDescription);
                return ;
            }
            NSString * isS = dic1[@"success"];
            
            if ([isS integerValue] == 0)
            {
                NSString * url = dic1[@"url"];
                
                NSMutableDictionary * pd = [NSMutableDictionary dictionaryWithDictionary:dic];
                [pd setObject:url forKey:@"headImage"];
                
                NSData * data=[NSJSONSerialization dataWithJSONObject:pd options:NSJSONWritingPrettyPrinted error:nil];
                NSString * info=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
                NSDictionary * parameter=@{@"uid":self.uid,@"userInfo":info};
                
                [copy_self postParameter:parameter URL:@"http://anlianlove.sinaapp.com/setUserInfo.php" blockHandle:block];
       
            }
                 

            
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSLog(@"%@",error.localizedDescription);
            block(NO);
            [self tishi];
        }];
        uploadImageop.responseSerializer = [AFHTTPResponseSerializer serializer];
        [uploadImageop start];
    }
    
    else
    {
        NSData * data=[NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
        NSString * info=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
        NSDictionary * parameter=@{@"uid":self.uid,@"userInfo":info};
        
        [self postParameter:parameter URL:@"http://anlianlove.sinaapp.com/setUserInfo.php" blockHandle:block];
 
    }

}
-(void)getUserInfo:(NSDictionary *)dic BlockHandle:(UMBlock)block
{
    NSMutableDictionary * dic1=[NSMutableDictionary dictionary];
    NSString * str=dic[@"uid"];
    if (str) {
        [dic1 setObject:str forKey:@"uid"];
        [dic1 setObject:dic[@"tel"] forKey:@"tel"];
    }
    else{
        [dic1 setObject:self.uid forKey:@"uid"];
        [dic1 setObject:self.tel forKey:@"tel"];
    }
    
   
    AFHTTPRequestOperation * op=[self.afManager GET:@"http://anlianlove.sinaapp.com/getUserInfo.php" parameters:dic1 success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSDictionary * dic0=[NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
        block(dic0);
        if (str) {
            
             NSDictionary * info=dic0[@"userInfo"];
            self.otherInfo=info;
            [self saveWithDic:info Name:@"otherpersonInfo"];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error.localizedDescription);
        [self tishi];
        block(@{@"success":@"1"});
    }];
    op.responseSerializer=[AFHTTPResponseSerializer serializer];
    [op start];
}
-(void)getCodeWithTel:(NSString *)tel BlockHandle:(UMBlockA)block
{
    self.tel = tel;
    [self postParameter:@{@"tel":tel} URL:@"http://anlianlove.sinaapp.com/getCode.php" blockHandle:block];
    

}

-(void)autheCode:(NSString *)code TEl:(NSString *)tel BlockHandel:(UMBlock)block
{
    
    AFHTTPRequestOperation * op = [self.afManager GET:@"http://2.anlianlove.sinaapp.com/confirmCode.php" parameters:@{@"tel":tel,@"code":code} success:^(AFHTTPRequestOperation *operation, NSData * responseObject) {
        NSError * error;
        NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:&error];
        if (dic == nil)
        {
            NSLog(@"%@",error.localizedDescription);
            return ;
        }
        NSString * isS = dic[@"success"];
        if ([isS integerValue] == 0)
        {
            block(dic);
            self.uid = dic[@"user"][@"uid"];
            self.tel=tel;
            [self save];
        }
        else
        {
            block(dic);
        }
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error.localizedDescription);
        [self tishi];
    }];
    op.responseSerializer = [AFHTTPResponseSerializer serializer];
    [op start];
}

-(void)save
{
    //将属性内容写入userDefault
    
    NSUserDefaults * user = [NSUserDefaults standardUserDefaults];
    
    @try {
        [user setObject:self.uid forKey:@"hlUID"];
        [user setObject:self.tel forKey:@"hlTEL"];
    }
    @catch (NSException *exception) {
        ;
    }
    @finally {
        ;
    }
    
    
    
    [user synchronize];
    
}
-(void)delect
{
    NSUserDefaults * user=[NSUserDefaults standardUserDefaults];
    [user removeObjectForKey:@"hlUID"];
    [user removeObjectForKey:@"hlTEL"];
    [user removeObjectForKey:@"personInfo"];
    NSDictionary * otherDic=[user objectForKey:@"otherpersonInfo"];
    if (otherDic) {
        [user removeObjectForKey:@"otherpersonInfo"];
    }
    NSString * otherUid=[user objectForKey:@"otherUid"];
    if (otherUid) {
        
        [user removeObjectForKey:@"otherUid"];
    }
    [user synchronize];
}
-(void)saveWithDic:(id)dictionary Name:(NSString *)str
{
    NSUserDefaults * user=[NSUserDefaults standardUserDefaults];
    [user setObject:dictionary forKey:str];
    [user synchronize];
    if([str isEqualToString:@"personInfo"])
    {
        self.personInfo=dictionary;
    }
    else if([str isEqualToString:@"otherpersonInfo"])
    {
        self.otherInfo=dictionary;
    }
    else if([str isEqualToString:@"otherUid"])
    {
        self.otherUid=dictionary;
    }
    
}

-(void)postParameter:(NSDictionary *)parameter URL:(NSString *)url blockHandle:(UMBlockA)block
{

    
    AFHTTPRequestOperation * op =[self.afManager POST:url parameters:parameter success:^(AFHTTPRequestOperation *operation, NSData * responseObject) {
        NSString * str=[[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
        NSLog(@"....%@",str);
        NSError * error;
        NSDictionary * dic= [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:&error];
        if (dic == nil)
        {
            NSLog(@"%@",error.localizedDescription);
         
            return ;
        }
        NSString * isS = dic[@"success"];
        
        if ([isS integerValue] == 0)
        {
            if ([url isEqualToString:@"http://anlianlove.sinaapp.com/setUserInfo.php"]) {
                NSString * str=parameter[@"userInfo"];
                NSData * data=[str dataUsingEncoding:NSUTF8StringEncoding];
                NSDictionary * d=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
                self.personInfo=d;
               
                [self saveWithDic:d Name:@"personInfo"];
                
            }
          
            block(YES);
        }
        else
        {
            block(NO);
        }
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error.localizedDescription);
        [self tishi];
        
    }];
    op.responseSerializer = [AFHTTPResponseSerializer serializer];
    [op start];
    
}
-(void)postdeviceToken
{
    NSUserDefaults * user=[NSUserDefaults standardUserDefaults];
    NSString * token=[user objectForKey:@"deviceToken"];
    NSDictionary * d=@{@"deviceToken":token};
   // NSDictionary * dic=@{@"uid":self.uid};
    NSData * data=[NSJSONSerialization dataWithJSONObject:d options:NSJSONWritingPrettyPrinted error:nil];
    NSString * info=[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    NSDictionary * parameter=@{@"uid":self.uid,@"userInfo":info};
    AFHTTPRequestOperationManager * m=[[AFHTTPRequestOperationManager alloc]init];
    AFHTTPRequestOperation * op =[m POST:@"http://anlianlove.sinaapp.com/setUserInfo.php" parameters:parameter success:^(AFHTTPRequestOperation *operation, NSData * responseObject) {
        NSString * s=[[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
        NSLog(@"ssssss%@",s);
        NSError * error;
        NSDictionary * dic= [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:&error];
        if (dic == nil)
        {
            NSLog(@"%@",error.localizedDescription);
            
            return ;
        }
        NSString * isS = dic[@"success"];
        
    
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error.localizedDescription);
       
        
    }];
    op.responseSerializer = [AFHTTPResponseSerializer serializer];
    [op start];

}

-(void)tishi
{
    [MUser alertViewShowTitle:@"提示" andMessage:@"网络连接超时" andDelegate:self controltag:1000];
}

@end
