//
//  ToolBar.h
//  HiddenLove
//
//  Created by mac on 15/3/31.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^DownBlock)(void);
typedef void(^ChangeBlock)(BOOL);
@interface ToolBar : UIToolbar
@property (nonatomic,strong)DownBlock downBlock;
@property (nonatomic,strong)ChangeBlock changeBlock;

-(void)addImages;
@end
