//
//  ScrollImageView.m
//  HiddenLove
//
//  Created by mac on 15/3/25.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "ScrollImageView.h"
#import "VIPhotoView.h"
#import "MUser.h"
@interface ScrollImageView()

@end
@implementation ScrollImageView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(instancetype)initWithArray:(NSArray *)array andInt:(int)count
{
    self=[super init];
    if (self) {
        
        self.frame=CGRectMake(0, 0, SCREEN_Width, SCREEN_Height);
        self.backgroundColor=[UIColor blackColor];
        self.contentSize=CGSizeMake(array.count * SCREEN_Width, SCREEN_Height);
        self.pagingEnabled=YES;
        self.contentOffset=CGPointMake(SCREEN_Width*count, 0);
        for (int i=0; i<array.count; i++) {
            VIPhotoView *photoView = [[VIPhotoView alloc] initWithFrame:CGRectMake(SCREEN_Width*i, 0, SCREEN_Width, SCREEN_Height) andImage:array[i]];
            photoView.autoresizingMask = (1 << 6) -1;
            [self addSubview:photoView];
        }
    
    
    
    
    }
    
    
    return self;
}

@end
