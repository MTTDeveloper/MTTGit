//
//  SoundCell.m
//  HiddenLove
//
//  Created by mac on 15/3/19.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "SoundCell.h"
#import <AVFoundation/AVFoundation.h>
#import "SoundManager.h"
#import "UIButton+WebCache.h"
@interface SoundCell()<AVAudioPlayerDelegate>
{
    double x;
}
@property (nonatomic,strong)TapBLOCK tapBlock;
@property (nonatomic,copy)NSString * url;
@property (strong, nonatomic) IBOutlet UIView *bgView;
@property (strong, nonatomic) IBOutlet UIButton *headImageV;
@property (strong, nonatomic) IBOutlet UIButton *userNameB;
@property (strong, nonatomic) IBOutlet UILabel *textL;
@property (strong, nonatomic) IBOutlet UILabel *dateL;
@property (strong, nonatomic) IBOutlet UIButton *soundBtn;
@property (strong, nonatomic) IBOutlet UILabel *timeL;
@property (strong, nonatomic) UIImageView * imageview;
@property (strong, nonatomic) NSTimer * timer;
@property(strong,nonatomic)SoundManager * sManager;
@property (nonatomic,assign)BOOL my;
@end
@implementation SoundCell

#pragma - mark 重写父类方法

-(void)awakeFromNib
{
    NSString * sex=[self getSex];
    self.bgView.backgroundColor=[MUser hexStringToColor:@"eaf4fc"];
    [self.headImageV setBackgroundImage:[UIImage imageNamed:@"tyzongjian.png"] forState:UIControlStateNormal];
    
    if ([sex isEqualToString:@"nv"]) {
        self.bgView.backgroundColor=[MUser hexStringToColor:@"f8f4e6"];
        [self.headImageV setBackgroundImage:[UIImage imageNamed:@"tyyuangong.png"] forState:UIControlStateNormal];
    }
    self.bgView.layer.cornerRadius=5;
    self.bgView.layer.masksToBounds=YES;
    
    self.soundBtn.layer.cornerRadius=5;
    self.soundBtn.layer.masksToBounds=YES;
    
    self.imageview=[[UIImageView alloc]initWithFrame:CGRectMake(6, 8, 12, 18)];
    NSString *strImageA,*strImageB,*strImageC;
    strImageA = @"yuyin3";
    strImageB = @"yuyin2";
    strImageC = @"yuyin1";
    NSString *strName = @"yuyin1.png";
    
    UIImage *imageA = [UIImage imageNamed:strImageA];
    UIImage *imageB = [UIImage imageNamed:strImageB];
    UIImage *imageC = [UIImage imageNamed:strImageC];
    self.imageview.animationImages = @[imageA,imageB,imageC];
    self.imageview.image = [UIImage imageNamed:strName];
    self.imageview.animationDuration = 1.0;
    self.imageview.hidden=YES;
    self.soundBtn.backgroundColor =[UIColor whiteColor];
    [self.soundBtn addSubview:self.imageview];
    
     x=0;
    self.sManager=[SoundManager share];
    
}





#pragma - mark SetCellInfo

//相当于VC中ViewDidLoad
-(void)setCellInfo:(NSDictionary * )dic
{
    UserManager * uManager=[UserManager shareManager];
    NSString * str=dic[@"fromUid"];
    if([str isEqualToString:uManager.uid])
    {
        [self.headImageV sd_setBackgroundImageWithURL:uManager.personInfo[@"headImage"] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"tyzongjian.png"]];
        
         [self.userNameB setTitle:uManager.personInfo[@"name"] forState:UIControlStateNormal];
    }
    else if(str)
    {
         if (str.length>1) {
        [self.headImageV sd_setBackgroundImageWithURL:uManager.otherInfo[@"headImage"] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"tyzongjian.png"]];
        [self.userNameB setTitle:uManager.otherInfo[@"name"] forState:UIControlStateNormal];
         }
         else
         {
             [self.headImageV setBackgroundImage:[UIImage imageNamed:@"tyzongjian.png"] forState:UIControlStateNormal];
             
         }
    }
  
    self.dateL.text=[self getSendDate:dic[@"date"]];
    self.textL.attributedText=[self changeTextWithBiaoqing:dic[@"text"]];
   self.url=dic[@"content"];
    self.timeL.text=dic[@"stime"];
    __weak __block SoundCell * copy_self=self;
 
    

    [self.sManager soundURL:self.url changeStateBlockHandle:^(SoundDataState state) {
        switch (state)
        {
            case SoundDataStateWaitForPlay:
                [copy_self waitingForPlay];
                break;
            case SoundDataStatePlaying:
                [copy_self didplay];
                break;
            case SoundDataStateLoading:
                [copy_self loading];
                break;
                
            default:
                break;
        }
    }];
    
}


-(void)prepareForReuse
{
    NSLog(@"11");
    [self.sManager removeBlockHandleWithURL:self.url];
    self.my=NO;
}

#pragma - mark 组件回调

- (IBAction)voicePlay:(id)sender
{
    
    [self.sManager playORPauseWithURL:self.url];
    
}

-(void)sansuo
{
    x+=0.01;
    self.soundBtn.alpha=MAX(fabs(sin(x)), 0.1);
}

#pragma - mark cell具体功能的封装

-(void)loading
{
    self.soundBtn.userInteractionEnabled=NO;
    if (self.timer.isValid)
    {
        [self.timer invalidate];
    }
    self.timer =[NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(sansuo) userInfo:nil repeats:YES];
}
-(void)waitingForPlay
{
   
    self.soundBtn.userInteractionEnabled=YES;
    self.soundBtn.backgroundColor=[MUser hexStringToColor:@"3eb370"];
    self.soundBtn.alpha=1;
    [self.timer invalidate];
    [self.imageview stopAnimating];
    self.imageview.hidden=YES;
}
-(void)didplay
{
    self.soundBtn.userInteractionEnabled=YES;
     self.soundBtn.backgroundColor=[MUser hexStringToColor:@"3eb370"];
    self.soundBtn.alpha=1;
    [self.timer invalidate];
    self.imageview.hidden=NO;
    [self.imageview startAnimating];
}
- (IBAction)setPersonInfo:(UIButton *)sender {
    UserManager * uManager=[UserManager shareManager];
    if (self.my) {
        self.tapBlock(uManager.personInfo);
    }
    else
    {
        self.tapBlock(uManager.otherInfo);
    }
}







@end
