//
//  StateManager.h
//  HiddenLove
//
//  Created by mac on 15/3/16.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^SMBlock)(NSDictionary * dic);

@interface StateManager : NSObject

+(instancetype)shareManager;


-(void)getStatesWithUID:(NSString *)uid BlockHandle:(SMBlock)block;

//-(void)getTextBlockHandle:(SMBlock)block;
//
//-(void)getImageBlockHandle:(SMBlock)block;
//
//-(void)getSoundBlockHandle:(SMBlock)block;
//
//-(void)getShipinBlockHandle:(SMBlock)block;



-(void)postStatesWithUID:(NSString *)uid Dic:(NSMutableDictionary *)dic BlockHandle:(SMBlock)block;


@end
