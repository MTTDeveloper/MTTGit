//
//  StateTableViewController.m
//  HiddenLove
//
//  Created by mac on 15/3/16.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "StateTableViewController.h"

#import "StateManager.h"
#import "UserManager.h"

@interface StateTableViewController ()

@property(nonatomic,strong)StateManager * sManager;
@property(nonatomic,strong)UserManager * uManager;


@property(nonatomic,strong)NSArray * states;

@end

@implementation StateTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.uManager = [UserManager shareManager];
//    
//    self.sManager = [StateManager shareManager];
//
//    __weak __block StateTableViewController * copy_self = self;
//    
//    [self.sManager getStatesWithUID:self.uManager.uid BlockHandle:^(NSDictionary *dic) {
//        NSArray * infos = dic[@"infos"];
//        
//        copy_self.states = infos;
//        
//        [copy_self.tableView reloadData];
//    }];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   // NSDictionary * dic = self.states[indexPath.row];
    
    NSString * celID = [self cellIDWithDic: nil];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:celID forIndexPath:indexPath];
    
   // [cell setCellInfo:dic];
    
    return cell;
}

#pragma - mark vc功能封装

-(NSString *)cellIDWithDic:(NSDictionary *)dic
{
    return @"moreCell";
}



@end
