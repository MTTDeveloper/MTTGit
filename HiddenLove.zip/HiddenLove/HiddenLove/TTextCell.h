//
//  TTextCell.h
//  HiddenLove
//
//  Created by mac on 15/3/20.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTextCell : UITableViewCell

@end
