//
//  MVPlayerControllerViewController.h
//  视频
//
//  Created by mac on 15/3/26.
//  Copyright (c) 2015年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MVPlayerControllerViewController : UIViewController
@property (nonatomic,copy)NSString * urlStr;
@property (nonatomic,assign)BOOL pathUrl;
@end
