//
//  HeadImageCell.m
//  HiddenLove
//
//  Created by mac on 15/3/16.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "HeadImageCell.h"
#import "UIImage+ImageEffects.h"
#import "MUser.h"
@implementation HeadImageCell

- (void)awakeFromNib {
    // Initialization code
   
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setCellInfo:(NSDictionary *)dic
{
    UIImage * image=[UIImage imageNamed:@"diqiu"];
    
    self.backgroundImageView.image=[image applyBlurWithRadius:2 tintColor:[UIColor colorWithWhite:0.5 alpha:0.5] saturationDeltaFactor:1.8 maskImage:nil];
    CGRect rect=self.backgroundImageView.frame;
    rect.size=CGSizeMake(SCREEN_Width, SCREEN_Width);
    self.backgroundImageView.frame=rect;
    self.headImageBtn.layer.borderColor=[UIColor whiteColor].CGColor;
    [self.headImageBtn.layer setMasksToBounds:YES];
    [self.headImageBtn.layer setCornerRadius:10.0]; //设置矩形四个圆角半径
    [self.headImageBtn.layer setBorderWidth:1]; //边框宽度
    [self.headImageBtn setBackgroundImage:image forState:UIControlStateNormal];
    self.myTel.text=@"13644507510";
    self.name.text=@"王新彬";
}

@end
