//
//  MenuTableViewController.m
//  HiddenLove
//
//  Created by mac on 15/3/18.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "MenuTableViewController.h"
#import "HomeViewController.h"
#import "PersonInfoTableViewController.h"
#import "AppDelegate.h"
#import "UIImageView+AFNetworking.h"
#import "UIImageView+WebCache.h"
#import "UserManager.h"
@interface MenuTableViewController ()

@property (strong, nonatomic) IBOutlet UIImageView *userImageView;
@property (strong, nonatomic) IBOutlet UILabel *userName;
@property (strong, nonatomic) IBOutlet UITableViewCell *zhuyeCell;


@end

@implementation MenuTableViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;

    self.tableView.rowHeight=UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 100;
    self.tableView.tableFooterView=[[UIView alloc]init];
    
    UserManager * uManager=[UserManager shareManager];
    if (uManager.otherUid) {
        [self changeTitle];
    }

   
    NSDictionary * dic=uManager.personInfo;
   // [self.userImageView setImageWithURL:[NSURL URLWithString:dic[@"headImage"]]];
    self.userImageView.layer.cornerRadius=10;
    [self.userImageView sd_setImageWithURL:[NSURL URLWithString:dic[@"headImage"]]];
    self.userImageView.layer.masksToBounds=YES;
    
   // =[UIImage imageWithData:dic[@"headImage"]];
    self.userName.text=dic[@"name"];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(receiveInfo:) name:@"changeInfo" object:nil];
   
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeTitle) name:@"Connect" object:nil];
    
    
    
    
}
-(void)receiveInfo:(NSNotification * )notification
{
    NSDictionary * dic= notification.userInfo;
    [self.userImageView sd_setImageWithURL:[NSURL URLWithString:dic[@"headImage"]]];
    self.userName.text=dic[@"name"];
    
}
-(void)changeTitle
{
    //改成，我们的主页
    self.zhuyeCell.textLabel.text=@"我们的主页";
}

-(void)toEditDiary
{
    UIStoryboard * s=[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController * vc=[s instantiateViewControllerWithIdentifier:@"editDiary"];
    [self.navigationController pushViewController:vc animated:YES];
}
-(void)viewDidAppear:(BOOL)animated
{
    [self.tableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
        
                                                             bundle: nil];
    if (indexPath.section==0) {
        PersonInfoTableViewController * vc=[mainStoryboard instantiateViewControllerWithIdentifier:@"personInfo"];
        vc.first=YES;
        [[SlideNavigationController sharedInstance] switchToViewController:vc withCompletion:nil];
    }
    
    if (indexPath.section==1|indexPath.section==2) {
        HomeViewController * vc=[mainStoryboard instantiateViewControllerWithIdentifier:@"home"];
    if (indexPath.section==1&&indexPath.row==0) {
        vc.type=@"主页";
    }
    else if(indexPath.section==2)
    {
        switch (indexPath.row) {
            case 0:
                vc.type=@"文字";
                break;
            case 1:
                vc.type=@"图片";
                break;
            case 2:
                vc.type=@"声音";
                break;
            case 3:
                vc.type=@"视频";
                break;

            default:
                break;
        }
    }
    
    
       [[SlideNavigationController sharedInstance] switchToViewController:vc withCompletion:nil];
    }
    if (indexPath.section==3) {
         UIStoryboard * s=[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
        if (indexPath.row==1) {
             UserManager * uManager=[UserManager shareManager];
            [uManager delect];
         
           
            UIWindow * window=[UIApplication sharedApplication].keyWindow;
            window.rootViewController=[s instantiateViewControllerWithIdentifier:@"vc"];
            UINavigationController * vc=[mainStoryboard
                                         instantiateViewControllerWithIdentifier: @"secendNav"];
        
            [SlideNavigationController sharedInstance].leftMenu = vc;
            
            
        }
        else
        {
           UIViewController * vc=[s instantiateViewControllerWithIdentifier:@"aboutus"];
            
        [[SlideNavigationController sharedInstance] switchToViewController:vc withCompletion:nil];
        }
    }
}
-(void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:@"connect" object:nil];
     [[NSNotificationCenter defaultCenter]removeObserver:self name:@"changeInfo" object:nil];
    
}


@end
