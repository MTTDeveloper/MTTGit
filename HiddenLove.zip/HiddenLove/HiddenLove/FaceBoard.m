//
//  FaceBoard.m
//  WeChat
//
//  Created by admin on 15/3/19.
//  Copyright (c) 2015年 刘兆镇. All rights reserved.
//

#import "FaceBoard.h"

@implementation FaceBoard
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.scrollView = [[UIScrollView alloc]initWithFrame:self.bounds];
        self.scrollView.pagingEnabled = YES;
        [self addSubview:self.scrollView];
        //kvo
        [self addObserver:self forKeyPath:@"source" options:NSKeyValueObservingOptionNew context:nil];
    }
    return self;
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    NSInteger counts = [self.source numberOfFacesInKeyBoard:self];
    NSInteger pages = counts/32;
    CGSize contentSize = CGSizeMake(self.scrollView.frame.size.width*pages,self.scrollView.frame.size.height);
    self.scrollView.contentSize = contentSize;
    //defence
    NSArray *subviews = self.scrollView.subviews;
    [subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    for (int i = 0; i < counts; i++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.tag = i;
        [button addTarget:self action:@selector(tapButton:) forControlEvents:UIControlEventTouchUpInside];
        //位置
        int section = i/32;
        int num = i%32;
        int column = num % 8;
        int row = num / 8;
        //坐标
        CGFloat buttonWidth = self.frame.size.width/8;
        CGFloat x = self.frame.size.width * section + column *buttonWidth;
        CGFloat y = row *buttonWidth;
        
        CGRect frame = CGRectMake(x, y, buttonWidth, buttonWidth);
        button.frame = frame;
        UIImage *image = [self.source faceBoard:self imageAtButtonIndex:i];
        [button setImage:image forState:UIControlStateNormal];
        [self.scrollView addSubview:button];
        
    }
}

-(void)tapButton:(UIButton *)button
{
    if ([self.delegate respondsToSelector:@selector(faceBoard:didTapButtonIndex:)]) {
        [self.delegate faceBoard:self didTapButtonIndex:button.tag];
    }
}

-(void)dealloc
{
    //增加kvo 需要释放
    [self removeObserver:self forKeyPath:@"source"];
    
}
@end
