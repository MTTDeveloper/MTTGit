//
//  ScrollImageView.h
//  HiddenLove
//
//  Created by mac on 15/3/25.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScrollImageView : UIScrollView
-(instancetype)initWithArray:(NSArray *)array andInt:(int)count;
@end
