//
//  HomeViewController.m
//  HiddenLove
//
//  Created by mac on 15/3/20.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "SlideNavigationController.h"
#import <AVFoundation/AVFoundation.h>

#import "HomeViewController.h"
#import "UITableViewCell+add.h"
#import "MoreImageCell.h"
#import "TextCell.h"
#import "vedioCell.h"
#import "StateManager.h"
#import "UserManager.h"
#import "MJRefresh.h"
#import "MVPlayerControllerViewController.h"
#import "SetPersonInfoController.h"
typedef enum Refresh_TYPE{
    
    Refresh_HEADER = 1,
    Refresh_FOORTER,
    
}Refresh_TYPE;
@interface HomeViewController ()<UITableViewDelegate,UITableViewDataSource,SlideNavigationControllerDelegate,AVAudioPlayerDelegate>

@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) AVAudioPlayer * player;

@property(nonatomic,strong)NSArray * states;


@property(nonatomic,strong)StateManager * sManager;
@property(nonatomic,strong)UserManager * uManager;
@property(nonatomic,assign)BOOL frist;
@end

@implementation HomeViewController
- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}
#pragma - mark  重新父类方法
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];


  
        

        [self saveInfo];


    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.sManager=[StateManager shareManager];
    self.uManager=[UserManager shareManager];
    
    
    
  
    
 
        
    
    
  
  
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(postToken) name:@"deviceToken" object:nil];
    
    self.view.backgroundColor=[UIColor whiteColor];

    
    UIBarButtonItem * rightItem=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(toEditDiary)];
    self.navigationItem.rightBarButtonItem=rightItem;
    self.tableView.rowHeight=UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 100;

    //下拉刷新
    [self.tableView addHeaderWithTarget:self action:@selector(refreshHeader)];
    

}
-(void)saveInfo
{
    @try {
        __weak __block HomeViewController * copy_self=self;
        [self.uManager getUserInfo:nil BlockHandle:^(NSDictionary *dic) {
            
            if([dic[@"success"]isEqualToString:@"0"])
            {
                NSDictionary * info=dic[@"userInfo"];
                [copy_self.uManager saveWithDic:info Name:@"personInfo"];
                [[NSNotificationCenter defaultCenter]postNotificationName:@"changeInfo" object:nil userInfo:info];
                if (info[@"otheruid"]&&info[@"otherTel"]) {
                    
                    
                    @try {
                        NSString * otherTel=info[@"otherTel"];
                        NSDictionary * dic1=@{@"uid":info[@"otheruid"],@"tel":otherTel};
                        [copy_self.uManager getUserInfo:dic1 BlockHandle:^(NSDictionary *dic) {
                            
                            [copy_self refreshHeader];
                            
                        }];
                    }
                    
                    @catch (NSException *exception) {
                        NSLog(@"%s",__FUNCTION__);
                        NSLog(@"%s",__FILE__);
                        NSLog(@"1111");
                    }
                    @finally {
                        ;
                    }
                    
                    
                    
                }
                else
                {
                     [copy_self refreshHeader];
                                    }
            }
            else
            {
                 [copy_self refreshHeader];
            }
        }];
    }
    @catch (NSException *exception) {
        NSLog(@"%s",__FUNCTION__);
    }
    @finally {
        ;
    }
    

}
- (void)refreshHeader
{
   
    if([self respondsToSelector:@selector(updateSomeThing:)]){
        [self updateSomeThing:Refresh_HEADER];
    }
 
    
        
  
}
// 获取状态
- (void)updateSomeThing:(Refresh_TYPE)refreshType
{
    
    [self.sManager getStatesWithUID:self.uManager.uid BlockHandle:^(NSDictionary *dic) {
        
        if (dic==nil) {
            [self.tableView headerEndRefreshing];
            return;
        }
        NSArray * arr;
        id test = dic[@"states"];
        if ([test isKindOfClass:[NSNull class]])
        {
            arr = nil;
            [self.tableView headerEndRefreshing];
        }
        else
        {
            arr = test;
        }

        [self backArrayWithType:arr];
        [self.tableView headerEndRefreshing];
        [self.tableView reloadData];
    }];

}
-(void)backArrayWithType:(NSArray *)arr
{
    NSMutableArray * addArr=[NSMutableArray array];
    for (NSDictionary * dic1 in arr) {
        if ([self.type isEqualToString:@"文字"]) {
            if ([dic1[@"type"]isEqualToString:@""]) {
                [addArr addObject:dic1];
            }
            
        }
        if ([self.type isEqualToString:@"图片"]) {
            if ([dic1[@"type"]isEqualToString:@"image"]) {
                [addArr addObject:dic1];
            }
            
        }
        if ([self.type isEqualToString:@"声音"]) {
            if ([dic1[@"type"]isEqualToString:@"voice"]) {
                [addArr addObject:dic1];
            }
            
        }
        if ([self.type isEqualToString:@"视频"]) {
            if ([dic1[@"type"]isEqualToString:@"video"]) {
                [addArr addObject:dic1];
            }
            
        }
    }
    if (!self.type||[self.type isEqualToString:@"主页"]) {
       
        self.states=arr;
    }
    else
    {
        self.states=[NSArray arrayWithArray:addArr];
    }


}
-(void)toEditDiary
{
    UIStoryboard * s=[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController * vc=[s instantiateViewControllerWithIdentifier:@"editDiary"];
    [self.navigationController pushViewController:vc animated:YES];
}
-(void)postToken
{
    [self.uManager postdeviceToken];
}

//-(void)viewDidAppear:(BOOL)animated
//{
//    [self.tableView reloadData];
//}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.states.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary * dic = self.states[indexPath.row];
    
    NSString * celID = [self cellIDWithDic:dic];

    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:celID forIndexPath:indexPath];
   
    [cell setCellInfo:dic];
    [self pushPersonInfo:cell];
    
    return cell;
    
    

}
-(void)pushPersonInfo:(UITableViewCell *)cell;
{
    [cell setTapBlock:^(NSDictionary *dic) {
        UIStoryboard * s=[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
        SetPersonInfoController * vc=[s instantiateViewControllerWithIdentifier:@"setpersonInfo"];
        vc.dic=dic;
        [self.navigationController pushViewController:vc animated:YES];
    }];
}
-(NSString *)cellIDWithDic:(NSDictionary *)dic
{
    NSString *type=dic[@"type"];
    NSString *identifier;
    if ([type isEqualToString:@""]) {
        identifier= @"textCell";
    }
    else if([type isEqualToString:@"image"])
    {
        NSString * content=dic[@"content"];
        NSRange range=[content rangeOfString:@"|"];
        if (range.length>0) {
            identifier= @"moreImageCell";
        }
        else{
            identifier= @"imageCell";
        }
    }
    else if ([type isEqualToString:@"voice"]) {
        identifier= @"soundCell";
    }
    else if ([type isEqualToString:@"video"])
    {
        identifier= @"vedioCell";
    }
    return identifier;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary * dic=self.states[indexPath.row];
    if ([dic[@"type"]isEqualToString:@"video"]) {
        
        UIStoryboard *s=[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
        MVPlayerControllerViewController *vc=[s instantiateViewControllerWithIdentifier:@"mv"];
        vc.urlStr= dic[@"content"];
        [self.navigationController pushViewController:vc animated:YES];
        
    }
    
}
-(void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:@"deviceToken" object:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
