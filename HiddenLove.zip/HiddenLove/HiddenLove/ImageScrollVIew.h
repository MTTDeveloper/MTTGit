//
//  ImageScrollVIew.h
//  HiddenLove
//
//  Created by mac on 15/3/29.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^ImageBlock)(void);
typedef void(^DelectBlock)(NSUInteger);
@interface ImageScrollVIew : UIScrollView
@property (strong, nonatomic) IBOutlet UIButton *addImageBtn;
@property (strong, nonatomic) ImageBlock  imageBlock;
@property (strong, nonatomic) DelectBlock delectBlock;
-(void)addWithImages:(NSMutableArray *)array;
@end
