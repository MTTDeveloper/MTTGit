//
//  MVPlayerControllerViewController.m
//  视频
//
//  Created by mac on 15/3/26.
//  Copyright (c) 2015年 mac. All rights reserved.
//

#import "MVPlayerControllerViewController.h"
#import <MediaPlayer/MediaPlayer.h>
@interface MVPlayerControllerViewController ()
@property(nonatomic,strong)MPMoviePlayerController * mvController;
@end

@implementation MVPlayerControllerViewController

//-(MPMoviePlayerController *)mvController
//{
//    if (!_mvController) {
//        NSURL * url=[[NSBundle mainBundle]URLForResource:@"xiaopingguo.mp4" withExtension:nil];
//        _mvController=[[MPMoviePlayerController alloc]initWithContentURL:url];
//        _mvController.view.frame=self.view.bounds;
//        [self.view addSubview:_mvController.view];
//        _mvController.view.autoresizingMask=UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
//        
//       
//    }
//    return _mvController;
//}
-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:YES];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
   // self.mvController=[self mvController];
    //self.navigationController.navigationBarHidden=YES;
//    NSURL * url=[[NSBundle mainBundle]URLForResource:@"小苹果.mp4" withExtension:nil];
    NSURL * url;
    if (self.pathUrl) {
        url = [NSURL fileURLWithPath:self.urlStr];
    }
    else{
        url = [NSURL URLWithString:self.urlStr];
    }
    _mvController=[[MPMoviePlayerController alloc]initWithContentURL:url];
  
    _mvController.view.frame=self.view.bounds;
    
    _mvController.view.autoresizingMask=UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
     [self.view addSubview:_mvController.view];
     [_mvController play];
    [self addNotification];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)addNotification
{
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getplayerstates:) name:MPMoviePlayerPlaybackStateDidChangeNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(playerFinish) name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
}
-(void)getplayerstates:(NSNotification *)notifcation
{
    if (_mvController.playbackState==MPMoviePlaybackStatePlaying) {
        self.navigationController.navigationBarHidden=YES;
    }
    else if(_mvController.playbackState==MPMoviePlaybackStatePaused)
    {
        self.navigationController.navigationBarHidden=NO;
    }
}
-(void)playerFinish
{
    
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
