//
//  SoundManager.h
//  HiddenLove
//
//  Created by mac on 15/3/24.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum : NSUInteger {
    SoundDataStateLoading,
    SoundDataStateWaitForPlay,
    SoundDataStatePlaying,
} SoundDataState;

typedef void(^SMBase)(SoundDataState state);



@interface SoundManager : NSObject
+(instancetype)share;

-(void)soundURL:(NSString *)url changeStateBlockHandle:(SMBase)block;

-(void)playORPauseWithURL:(NSString *)url;

-(void)removeBlockHandleWithURL:(NSString *)url;


@end
