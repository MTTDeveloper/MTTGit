//
//  PersonInfoTableViewController.h
//  HiddenLove
//
//  Created by mac on 15/3/15.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonInfoTableViewController : UITableViewController<UITextFieldDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (strong, nonatomic) IBOutlet UIImageView *backgroundImageView;
@property (strong, nonatomic) IBOutlet UITextField *myTelText;

@property (strong, nonatomic) IBOutlet UIImageView *mysexImageView;
@property (strong, nonatomic) IBOutlet UIButton *headImageBtn;
@property (strong, nonatomic) IBOutlet UITextField *myNameText;
@property (strong, nonatomic) IBOutlet UITextField *signText;
@property (strong, nonatomic) IBOutlet UITextField *loveNickName;
@property (strong, nonatomic) IBOutlet UITextField *loveTel;
@property (strong, nonatomic) IBOutlet UIButton *saveBtn;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *editBtn;
@property (copy,nonatomic)NSString * headImageName;
@property (copy,nonatomic)NSString * sex;
@property (assign, nonatomic) BOOL first;
@end
