//
//  ImageManager.m
//  GCSupplier
//
//  Created by Admin on 14-3-14.
//  Copyright (c) 2014年 Admin. All rights reserved.
//

#import "ImageManager.h"

#define MAX_SIZE            960
#define KB_SIZE             1280

@implementation ImageManager
+ (UIImage *)loadImageFromMainBundle:(NSString *)imageName
{
    NSString *bundlePath = [[NSBundle mainBundle] bundlePath];
    NSString *imagePath = [bundlePath stringByAppendingString:[NSString stringWithFormat:@"/%@", imageName]];
    
    UIImage *image = [UIImage imageWithContentsOfFile:imagePath];
    
    return image;
}

+ (UIImage *)compressImage:(UIImage *)image
{
    // 压缩尺寸
    UIImage *newImage;
    float maxSize = MAX(image.size.width, image.size.height);
    if (maxSize > MAX_SIZE)
    {
        UIGraphicsBeginImageContext(CGSizeMake(image.size.width * 960/maxSize, image.size.height * 960/maxSize));
        
        [image drawInRect:CGRectMake(0,0,image.size.width * 960/maxSize, image.size.height * 960/maxSize)];
        
        newImage = UIGraphicsGetImageFromCurrentImageContext();
        
        UIGraphicsEndImageContext();
    } else {
        newImage = image;
    }
    
    // 压缩质量
    float i = 0;
    NSData *newImageData = UIImageJPEGRepresentation(newImage, 1);
    while ([newImageData length]/KB_SIZE >= 100 && i < 10)
    {
        i++;
        newImageData = UIImageJPEGRepresentation(newImage, 1.0f - i/10);
    }
    
    return [UIImage imageWithData:newImageData];
}

+ (UIImage *)compressImage:(UIImage *)image withSize:(float)size
{
    // 压缩尺寸
    CGFloat index = 170;
    UIImage *newImage;
    float maxSize = MAX(image.size.width, image.size.height);
    if (maxSize > index)
    {
        UIGraphicsBeginImageContext(CGSizeMake(image.size.width * index/maxSize, image.size.height * index/maxSize));
        
        [image drawInRect:CGRectMake(0,0,image.size.width * index/maxSize, image.size.height * index/maxSize)];
        
        newImage = UIGraphicsGetImageFromCurrentImageContext();
        
        UIGraphicsEndImageContext();
    } else {
        newImage = image;
    }
    
    // 压缩质量
    float i = 0;
    NSData *newImageData = UIImageJPEGRepresentation(newImage, 1.0);
    while ([newImageData length]/KB_SIZE >= 30 && i < 10)
    {
        i++;
        newImageData = UIImageJPEGRepresentation(newImage, 1.0f - i/10);
    }
    
    return [UIImage imageWithData:newImageData];
}

+ (NSData *)compressImage:(UIImage *)image withBytes:(float)bytes
{

    CGFloat compressQ = 1.0;
    NSData *newImageData = UIImageJPEGRepresentation(image, compressQ);
    // 压缩质量
    float i = 0;
    while ([newImageData length] >= bytes && i < 10)
    {
        i++;
        newImageData = UIImageJPEGRepresentation(image, 1.0f - i/10);
    }
    return newImageData;//[UIImage imageWithData:newImageData];
}

+ (NSData *)compressWithDataImage:(UIImage *)image
{
    CGFloat compressQ = 0.1;
    NSData *newImageData = UIImageJPEGRepresentation(image, 1.0);
    int kMAX = 10;
    int lenght = [newImageData length]/1024;
    if(lenght >= 1024*(kMAX-1) && lenght <= 1024*kMAX)
        compressQ = 0.2;
    else if (lenght >= 1024*(kMAX-2) && lenght < 1024*(kMAX-1))
        compressQ = 0.3;
    else if (lenght >= 1024*(kMAX-3) && lenght < 1024*(kMAX-2))
        compressQ = 0.4;
    else if (lenght >= 1024*(kMAX-8) && lenght < 1024*(kMAX-3))
        compressQ = 0.5;
    else if (lenght >= 1024*(kMAX-1) && lenght < 1024*(kMAX-8))
        compressQ = 0.6;
    else if (lenght <= 200)
        compressQ = 1.0;
    newImageData = UIImageJPEGRepresentation(image, compressQ);
    return newImageData;
}

@end
