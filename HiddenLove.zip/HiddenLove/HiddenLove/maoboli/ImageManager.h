//
//  ImageManager.h
//  GCSupplier
//
//  Created by Admin on 14-3-14.
//  Copyright (c) 2014年 Admin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ImageManager : NSObject

+ (UIImage *)loadImageFromMainBundle:(NSString *)imageName;
+ (UIImage *)compressImage:(UIImage *)image;
+ (UIImage *)compressImage:(UIImage *)image withSize:(float)size;
+ (NSData *)compressImage:(UIImage *)image withBytes:(float)bytes;
//+ (NSData *)compressWithDataImage:(UIImage *)image;
@end
