//
//  FaceBoard.h
//  WeChat
//
//  Created by admin on 15/3/19.
//  Copyright (c) 2015年 刘兆镇. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol  FaceBoardDelegate;
@protocol FaceBoardSource;
@interface FaceBoard : UIView
@property (nonatomic,weak)id<FaceBoardDelegate>delegate;
@property (nonatomic,weak)id<FaceBoardSource>source;
@property (nonatomic,strong)UIScrollView *scrollView;
@end

@protocol FaceBoardDelegate <NSObject>
-(void)faceBoard:(FaceBoard *)faceBoard didTapButtonIndex:(NSInteger)buttonIndex;
@end

@protocol FaceBoardSource <NSObject>
-(NSInteger)numberOfFacesInKeyBoard:(FaceBoard *)faceBoard;
-(UIImage *)faceBoard:(FaceBoard *)faceBoard imageAtButtonIndex:(NSInteger)buttonIndex;
@end
