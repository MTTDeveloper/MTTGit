//
//  VoiceView.h
//  HiddenLove
//
//  Created by mac on 15/3/27.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VoiceView : UIView
@property (nonatomic, copy)   NSString *  audiowavPath;
@property (nonatomic, assign) int audiotime;
-(void)yuanjiao;
@end
