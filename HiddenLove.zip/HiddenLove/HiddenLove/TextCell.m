//
//  TextCell.m
//  HiddenLove
//
//  Created by mac on 15/3/19.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "TextCell.h"

@implementation TextCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setCellInfo:(NSDictionary * )dic
{
    self.text.text=dic[@"text"];
}
@end
