//
//  PersonInfoTableViewController.m
//  HiddenLove
//
//  Created by mac on 15/3/15.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "PersonInfoTableViewController.h"
#import "HeadImageCell.h"
#import "UITableViewCell+add.h"
#import "MUser.h"
#import "LoginViewController.h"
#import "UserManager.h"
#import "ImageManager.h"
#import "HomeViewController.h"
#import "SlideNavigationController.h"
#import "UIButton+AFNetworking.h"
#import "UIImageView+AFNetworking.h"
#import "UIImageView+WebCache.h"
#import "UIImage+ImageEffects.h"
#import "IMGActivityIndicator.h"
@interface PersonInfoTableViewController ()
@property(nonatomic,strong)UserManager * uManager;
@property(nonatomic,strong)NSData * imageData;
@end

@implementation PersonInfoTableViewController
- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return self.first;
}
- (void)viewDidLoad {
    [super viewDidLoad];
  
    self.uManager=[UserManager shareManager];
    if (self.first) {
        [self getUerInfo];
        self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithTitle:@"编辑" style:UIBarButtonItemStylePlain target:self action:@selector(edit:)];
        [self canEditInfo:NO];
        self.saveBtn.hidden=YES;
    }
    else
    {
        [self canEditInfo:YES];
        self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
        self.navigationItem.hidesBackButton=YES;
        self.backgroundImageView.backgroundColor=[MUser hexStringToColor:@"eaf4fc"];
        [self.headImageBtn setBackgroundImage:[UIImage imageNamed:@"weizhitouxiang.png"] forState:UIControlStateNormal];
        self.myNameText.text=@"";
        self.myTelText.text=self.uManager.tel;
        self.signText.text=@"";
        self.loveNickName.text=@"";
        self.loveTel.text=@"";
        self.sex=@"nan";
    }
    
    [self.saveBtn setBackgroundColor:[MUser hexStringToColor:@"3bafda"]];
    self.saveBtn.layer.masksToBounds=YES;
    self.saveBtn.layer.cornerRadius=10;
    self.tableView.rowHeight=UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 100;

}
-(void)canEditInfo:(BOOL)is
{
    self.headImageBtn.userInteractionEnabled=is;
    self.myNameText.userInteractionEnabled=is;
    self.myTelText.userInteractionEnabled=is;
    self.signText.userInteractionEnabled=is;
    self.loveNickName.userInteractionEnabled=is;
    self.loveTel.userInteractionEnabled=is;
    if(is)
    {
        self.mysexImageView.userInteractionEnabled=is;
        UITapGestureRecognizer * tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(changeSex:)];
        
        [self.mysexImageView addGestureRecognizer:tap];
    }
    self.saveBtn.hidden=NO;
    
    
}
-(void)changeSex:(UITapGestureRecognizer *)sender
{
    UIImageView * imageView=(UIImageView *)sender.view;
    if ([self.sex isEqualToString:@"nan"]) {
        imageView.image=[UIImage imageNamed:@"nv.png"];
         self.backgroundImageView.backgroundColor=[MUser hexStringToColor:@"f8f4e6"];
        self.sex=@"nv";
        return;
        
    }
    else
    {
        imageView.image=[UIImage imageNamed:@"nan.png"];
        self.backgroundImageView.backgroundColor=[MUser hexStringToColor:@"eaf4fc"];
        self.sex=@"nan";
    }
}
-(void)viewDidAppear:(BOOL)animated
{
    //[self.tableView reloadData];
    if (self.first) {
   
    }
}
-(void)getUerInfo
{
    [self.uManager getUserInfo:nil BlockHandle:^(NSDictionary *dic) {
        
        if([dic[@"success"]isEqualToString:@"0"])
        {
            NSDictionary * info=dic[@"userInfo"];
            
            [self.headImageBtn setBackgroundImageForState:UIControlStateNormal withURL:[NSURL URLWithString:info[@"headImage"]] placeholderImage:[UIImage imageNamed:@"weizhitouxiang.png"]];
            
            self.myNameText.text=info[@"name"];
            self.sex=info[@"sex"];
            if ([self.sex isEqualToString:@"nv"]) {
                self.mysexImageView.image=[UIImage imageNamed:@"nv.png"];
                self.backgroundImageView.backgroundColor=[MUser hexStringToColor:@"f8f4e6"];
                
            }
            else if([self.sex isEqualToString:@"nan"])
            {
                self.mysexImageView.image=[UIImage imageNamed:@"nan.png"];
                self.backgroundImageView.backgroundColor=[MUser hexStringToColor:@"eaf4fc"];
            }
            self.myTelText.text=info[@"tel"];
            self.signText.text=info[@"sign"];
            self.loveNickName.text=info[@"darling"];
            self.loveTel.text=info[@"otherTel"];
            //[self.tableView reloadData];
        }
        else{}
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma - mark  回调方法
- (IBAction)saveInfo:(id)sender {
    
    NSLog(@"保存");
    NSMutableDictionary * dic=[NSMutableDictionary new];
    [dic setObject:self.myNameText.text forKey:@"name"];
    [dic setObject:self.myTelText.text forKey:@"tel"];
    [dic setObject:self.signText.text forKey:@"sign"];
    [dic setObject:self.loveNickName.text forKey:@"darling"];
    [dic setObject:self.loveTel.text forKey:@"otherTel"];
    [dic setObject:self.sex forKey:@"sex"];
    
    if (self.imageData!=nil) {

       [dic setObject:self.imageData forKeyedSubscript:@"headImage"];
    }
  
    IMGActivityIndicator *indicator = [[IMGActivityIndicator alloc] initWithFrame:CGRectMake(SCREEN_Width/ 2 - 50, SCREEN_Height/2 - 50, 100, 100)];
    [self.view addSubview:indicator];
    [self.uManager savePersonInfoWithDic:dic BlockHandel:^(BOOL isSuccess) {
        
        if (isSuccess) {
           
            UIStoryboard * s=[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
            HomeViewController * vc=[s instantiateViewControllerWithIdentifier:@"home"];
            vc.type=@"主页";
            [self.navigationController pushViewController:vc animated:YES];
        
        }
        else
        {
            [MUser alertViewShowTitle:@"提示" andMessage:@"保存失败" andDelegate:self controltag:1000];
            
        }
        [indicator removeFromSuperview];
        
    }];
   
}


//选择头像
- (IBAction)selectHeadImage:(id)sender
{
    UIActionSheet * sheet=[[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照",@"从手机相册选择",nil];
    [sheet showInView:self.view];
    
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==0) {
        [self takePhoto];
    }
    else if (buttonIndex==1)
    {
        [self LocalPhoto];
    }
}

//开始拍照
-(void)takePhoto
{
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
    {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.allowsEditing = YES;
        picker.sourceType = sourceType;
        
        [self presentViewController:picker animated:YES completion:nil];
        
    }else
    {
        NSLog(@"模拟器中无法打开照相机,请在真机中使用");
    }
}

//打开本地相册
-(void)LocalPhoto
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    
    picker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
    
    picker.delegate = self;
    //设置选择后的图片可被编辑
    picker.allowsEditing = YES;
    [self presentViewController:picker animated:YES completion:nil];
}

//当选择一张图片后进入这里
-(void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    NSString *type = [info objectForKey:UIImagePickerControllerMediaType];
    //当选择的类型是图片
    if ([type isEqualToString:@"public.image"])
    {
        //图片压缩
        UIImage* image =[info objectForKey:@"UIImagePickerControllerEditedImage"];
        self.imageData=UIImagePNGRepresentation(image);
        NSLog(@"%@",self.imageData);
        [self.headImageBtn setBackgroundImage:image forState:UIControlStateNormal];
      //  self.backgroundImageView.image=image;
        //关闭相册界面
        [picker dismissViewControllerAnimated:YES completion:nil];
        
    

       
    }
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    NSLog(@"您取消了选择图片");
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)edit:(id)sender
{
    [self canEditInfo:YES];
}
#pragma mark - Table view data source
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.01;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row==0) {
        return SCREEN_Width-64;
    }
    else if(indexPath.row==4)
    {
        return 260;
    }
    return 44;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
     
    [self.tableView endEditing:YES];
    
}

@end
