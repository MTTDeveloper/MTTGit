//
//  ToolBar.m
//  HiddenLove
//
//  Created by mac on 15/3/31.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "ToolBar.h"
#import "MUser.h"
@interface ToolBar()
@property (strong, nonatomic) IBOutlet UIBarButtonItem *faceItem;
@property (strong, nonatomic) IBOutlet UIBarButtonItem *downItem;
@property (assign, nonatomic) BOOL faceBoard;
@property (nonatomic,strong) UIImageView * faceImage;
@property (nonatomic,strong) UIImageView * downImage;
@end
@implementation ToolBar
-(id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if(self)
    {
        self.faceImage=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 44, 44)];
        self.faceImage.image=[UIImage imageNamed:@"xl.png"];
        [self addSubview:self.faceImage];
   
        self.downImage=[[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_Width-44, 0, 44, 44)];
        self.downImage.image=[UIImage imageNamed:@"xjiantou.png"];
        [self addSubview:self.downImage];
    
        
    }
    return self;
}
-(void)addImages
{
//    UIImageView * imageV=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 44, 44)];
//    imageV.image=[UIImage imageNamed:@"xiaolian1.png"];
//    [self addSubview:imageV];
//    UIImageView * imageV1=[[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_Width-44, 0, 44, 44)];
//    [self addSubview:imageV1];
}
- (IBAction)changeKeyboard:(UIBarButtonItem *)sender {
    if (_faceBoard) {
     self.changeBlock(NO);
        self.faceImage.image=[UIImage imageNamed:@"xl.png"];
        _faceBoard=NO;
        return;
    }
    else{
      self.changeBlock(YES);
        self.faceImage.image=[UIImage imageNamed:@"jianpan.png"];
        _faceBoard=YES;
    }
}
- (IBAction)downKeyboard:(id)sender {
      self.downBlock();
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
