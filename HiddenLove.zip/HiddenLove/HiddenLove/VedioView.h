//
//  VedioView.h
//  HiddenLove
//
//  Created by mac on 15/3/27.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^PlayVideoBlock)(void);
typedef void(^DelectVideoBlock)(void);
@interface VedioView : UIView
@property (nonatomic,copy)NSString * palyUrl;
@property (nonatomic,strong)PlayVideoBlock playVideoBlock;
@property (nonatomic,strong)DelectVideoBlock delectVideoBlock;
-(void)addImages;
@end
