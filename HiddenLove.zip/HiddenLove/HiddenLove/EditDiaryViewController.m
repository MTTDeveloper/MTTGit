//
//  EditDiaryViewController.m
//  HiddenLove
//
//  Created by mac on 15/3/27.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import "EditDiaryViewController.h"
#import "MVPlayerControllerViewController.h"
#import "MainView.h"
#import "VoiceView.h"
#import "VedioView.h"
#import "ImageScrollVIew.h"
#import "MUser.h"
#import "ImageManager.h"
#import "TextView.h"
#import  "StateManager.h"
#import "UserManager.h"
#import "IMGActivityIndicator.h"
@interface EditDiaryViewController ()<UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIActionSheetDelegate,UITextFieldDelegate,UITextViewDelegate>
@property (strong, nonatomic) IBOutlet UITextField *xiangfaText;
@property (strong, nonatomic) IBOutlet UIScrollView *backScrollView;

@property (strong, nonatomic) IBOutlet TextView *textView;
@property (strong, nonatomic) IBOutlet MainView * mainView;
@property (strong, nonatomic) IBOutlet VedioView * vedioView;
@property (strong, nonatomic) IBOutlet VoiceView * voiceView;
@property (strong, nonatomic) ImageScrollVIew * imageScrollView;
@property (strong, nonatomic) NSMutableArray * selectImages;
@property (assign, nonatomic) NSUInteger photoOrVedio;
@property (strong, nonatomic) UIImagePickerController *picker;
@property (strong, nonatomic) StateManager * stateManager;
@property (strong, nonatomic) UserManager * uManger;
@property (assign, nonatomic) BOOL selectInPhotos;

@end

@implementation EditDiaryViewController
- (IBAction)save:(UIBarButtonItem *)sender {
    [self.textView resignFirstResponder];
    NSMutableDictionary * dic=[NSMutableDictionary dictionary];
   NSString * text=[self.textView  contentToString];
    if (text==nil) {
        text=@"";
    }
    
        [dic setObject:text forKey:@"text"];
    if (self.selectImages&&self.selectImages.count>0){
        [dic setObject:@"image" forKey:@"type"];
        [dic setObject:self.selectImages forKey:@"files"];
    }
    if (self.voiceView.audiowavPath&&self.voiceView.audiowavPath.length>0) {
        NSData *wavdata = [NSData dataWithContentsOfFile:self.voiceView.audiowavPath];
        [dic setObject:@"voice" forKey:@"type"];
        NSString * time=[NSString stringWithFormat:@"%ds",self.voiceView.audiotime];
        [dic setObject:time forKey:@"stime"];
        [dic setObject:@[wavdata] forKey:@"files"];
    }
    if (self.vedioView.palyUrl&&self.vedioView.palyUrl.length>0) {
        NSLog(@"%@",self.vedioView.palyUrl);
        NSData *videoData=[NSData dataWithContentsOfFile:self.vedioView.palyUrl];
        [dic setObject:@"video" forKey:@"type"];
        [dic setObject:@[videoData] forKey:@"files"];
    }
    if(!dic[@"type"]||[dic[@"type"]isEqualToString:@""])
    {
        if ([text isEqualToString:@""]) {
            [MUser alertViewShowTitle:@"提示" andMessage:@"您还没有填写内容" andDelegate:self controltag:1000];
            return;
        }
    }
    self.uManger=[UserManager shareManager];
    IMGActivityIndicator *indicator = [[IMGActivityIndicator alloc] initWithFrame:CGRectMake(SCREEN_Width/ 2 - 50, SCREEN_Height/2 - 50, 100, 100)];
    [self.view addSubview:indicator];

    
    
    [self.stateManager postStatesWithUID:self.uManger.uid Dic:dic BlockHandle:^(NSDictionary *dic) {
        
        [indicator removeFromSuperview];
        if([dic[@"success"] isEqualToString:@"0"])
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
        else
        {
            [MUser alertViewShowTitle:@"提示" andMessage:@"发送失败" andDelegate:self controltag:1000];
        }
        
    }];
    
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
     [self addViews];
    
    self.xiangfaText.userInteractionEnabled=NO;
    self.textView.delegate=self;
    self.stateManager=[StateManager shareManager];
    _picker = [[UIImagePickerController alloc] init];
    _picker.delegate=self;
    _picker.allowsEditing = YES;

    self.selectImages=[NSMutableArray array];
    __weak __block EditDiaryViewController * copy_self=self;
    [self.mainView setBtnBlock:^(NSUInteger whichBtn){
        copy_self.photoOrVedio=whichBtn;
        switch (whichBtn) {
            case PhotoBtn:
                [copy_self selectImageOrVedio];
                break;
            case VoivceBtn:
                [copy_self selectVoice];
                break;
            case VedioBtn:
                [copy_self selectImageOrVedio];
                break;
                
            default:
                break;
        }
       }];
    [self.imageScrollView setImageBlock:^{
         [copy_self selectImageOrVedio];
    }];
    [self.imageScrollView setDelectBlock:^(NSUInteger count){
        [copy_self.selectImages removeObjectAtIndex:count];
        [copy_self.imageScrollView addWithImages:copy_self.selectImages];
    }];
   //播放视频
    [self.vedioView setPlayVideoBlock:^
    {
        if ([copy_self.vedioView.palyUrl isEqualToString:@""]) {
            [MUser alertViewShowTitle:@"提示" andMessage:@"当前没有选中视频" andDelegate:copy_self controltag:1000];
        }
        UIStoryboard *s=[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
        MVPlayerControllerViewController *vc=[s instantiateViewControllerWithIdentifier:@"mv"];
        vc.urlStr= copy_self.vedioView.palyUrl;
        vc.pathUrl=YES;
        [copy_self.navigationController pushViewController:vc animated:YES];
    }];
    // 删除视频
    [self.vedioView setDelectVideoBlock:^
    {
        copy_self.vedioView.palyUrl=@"";
        copy_self.backScrollView.contentOffset=CGPointMake(0,0);
    }];
    
}
-(void)addViews
{
    self.mainView=(MainView *)[self initWithName:@"MainView"];
    [self.mainView addImage];
    self.voiceView=(VoiceView *)[self initWithName:@"VoiceView"];
    self.vedioView=(VedioView *)[self initWithName:@"VedioView"];
    [self.vedioView addImages];
   
//    NSArray * array=[[NSBundle mainBundle]loadNibNamed:@"ToolBarView" owner:nil options:nil];
//     self.toolBar = [array lastObject];
    
    self.imageScrollView=(ImageScrollVIew *)[self initWithName:@"ImageScrollView"];
   // self.backScrollView.backgroundColor=[UIColor blackColor];
    self.backScrollView.contentSize=CGSizeMake(SCREEN_Width, 320);
    self.backScrollView.pagingEnabled=YES;
    self.backScrollView.bounces=NO;
    self.backScrollView.scrollEnabled=NO;
    self.backScrollView.showsVerticalScrollIndicator=NO;
    self.backScrollView.contentOffset=CGPointMake(0, 0);
    [self.backScrollView addSubview:self.mainView];
    [self.backScrollView addSubview:self.voiceView];
    [self.voiceView yuanjiao];
    [self.backScrollView addSubview:self.vedioView];
    [self.backScrollView addSubview:self.imageScrollView];
    
    self.mainView.translatesAutoresizingMaskIntoConstraints=NO;
    NSString * width=[NSString stringWithFormat:@"H:|[_mainView(%f)]",SCREEN_Width];
    NSArray * arrMW=[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[_mainView(80)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_mainView)];
    NSArray * arrMH=[NSLayoutConstraint constraintsWithVisualFormat:width options:0 metrics:nil views:NSDictionaryOfVariableBindings(_mainView)];
    [self.backScrollView addConstraints:arrMW];
    [self.backScrollView addConstraints:arrMH];
    
    self.voiceView.translatesAutoresizingMaskIntoConstraints=NO;
    NSString * width1=[NSString stringWithFormat:@"H:|[_voiceView(%f)]",SCREEN_Width];
    NSArray * arrSW=[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-80-[_voiceView(80)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_voiceView)];
    NSArray * arrSH=[NSLayoutConstraint constraintsWithVisualFormat:width1 options:0 metrics:nil views:NSDictionaryOfVariableBindings(_voiceView)];
    [self.view addConstraints:arrSW];
    [self.view addConstraints:arrSH];
    
    self.vedioView.translatesAutoresizingMaskIntoConstraints=NO;
    NSString * width2=[NSString stringWithFormat:@"H:|[_vedioView(%f)]",SCREEN_Width];
    NSArray * arrVW=[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-160-[_vedioView(80)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_vedioView)];
    NSArray * arrVH=[NSLayoutConstraint constraintsWithVisualFormat:width2 options:0 metrics:nil views:NSDictionaryOfVariableBindings(_vedioView)];
    [self.backScrollView addConstraints:arrVW];
    [self.backScrollView addConstraints:arrVH];
    
    self.imageScrollView.translatesAutoresizingMaskIntoConstraints=NO;
    NSString * width3=[NSString stringWithFormat:@"H:|[_imageScrollView(%f)]",SCREEN_Width];
    NSArray * arrIW=[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-240-[_imageScrollView(80)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(_imageScrollView)];
    NSArray * arrIH=[NSLayoutConstraint constraintsWithVisualFormat:width3 options:0 metrics:nil views:NSDictionaryOfVariableBindings(_imageScrollView)];
    [self.backScrollView addConstraints:arrIW];
    [self.backScrollView addConstraints:arrIH];

    self.backScrollView.canCancelContentTouches=NO;
//    self.toolBarView.frame=CGRectMake(0, -88, SCREEN_Width, SCREEN_Height);
//    [self.textview.inputView addSubview:self.toolBarView];
//    self.textview.clipsToBounds=NO;
  //  self.textView.inputAccessoryView=self.toolBarView;

 //   self.textView.inputAccessoryView=self.toolBar;
}
-(id)initWithName:(NSString *)name
{
    NSArray * array=[[NSBundle mainBundle]loadNibNamed:name owner:nil options:nil];
    return [array firstObject];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)selectVoice
{
    self.backScrollView.contentOffset=CGPointMake(0, 80);
    self.backScrollView.exclusiveTouch=NO;
    [self.textView resignFirstResponder];
}
-(void)selectImageOrVedio
{
    [self.textView resignFirstResponder];
    if (self.selectImages.count==9) {
        [MUser alertViewShowTitle:@"提示" andMessage:@"最多只能选择9张图片" andDelegate:self controltag:1000];
    }
    else{
    NSString *str;
    if (self.photoOrVedio==PhotoBtn) {
        str=@"拍照";
    }
    else if (self.photoOrVedio==VedioBtn){
        str=@"拍摄";
    }
    UIActionSheet * sheet=[[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:str,@"从手机相册选择",nil];
    [sheet showInView:self.view];
    }
}
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==0) {
        self.selectInPhotos=YES;
        [self takePhoto];
    }
    else if (buttonIndex==1)
    {
        [self LocalPhoto];
    }
}

//开始拍照
-(void)takePhoto
{
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypeCamera;
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
    {
        NSArray * arr =[UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeCamera];
        if (self.photoOrVedio==PhotoBtn) {
            
              _picker.mediaTypes = @[arr[0]];
        }
        else if (self.photoOrVedio==VedioBtn)
        {
             _picker.mediaTypes = @[arr[1]];
        }
         _picker.sourceType = sourceType;
        [self presentViewController:_picker animated:YES completion:nil];
        
    }else
    {
        NSLog(@"模拟器中无法打开照相机,请在真机中使用");
    }
}

//打开本地相册
-(void)LocalPhoto
{
      _picker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
      NSArray * arr =[UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    if (self.photoOrVedio==PhotoBtn) {
        
        _picker.mediaTypes = @[arr[0]];
    }
    else if (self.photoOrVedio==VedioBtn)
    {
        _picker.mediaTypes = @[arr[1]];
    }
    [self presentViewController:_picker animated:YES completion:nil];
}

//当选择一张图片后进入这里
-(void)imagePickerController:(UIImagePickerController*)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    NSString *type = [info objectForKey:UIImagePickerControllerMediaType];
    //当选择的类型是图片
    if ([type isEqualToString:@"public.image"])
    {
        //图片压缩
        UIImage* image =[ImageManager compressImage:[MUser fixOrientation:[info objectForKey:@"UIImagePickerControllerEditedImage"]]];
        //保存照片到媒体库
        if (self.selectInPhotos) {
         UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
            self.selectInPhotos=NO;
        }
        
        [self.selectImages addObject:image];
        [self.imageScrollView addWithImages:self.selectImages];
        self.imageScrollView.contentSize=CGSizeMake((self.selectImages.count+1)*68+8, 80);
        self.backScrollView.contentOffset=CGPointMake(0, 240);
    }
    else if ([type isEqualToString:@"public.movie"])
    {
        // 判断获取类型：视频
        //获取视频文件的url
        NSURL* mediaURL = [info objectForKey:UIImagePickerControllerMediaURL];
        NSString* path=mediaURL.path;
        //保存视频到媒体库
          if (self.selectInPhotos) {
       UISaveVideoAtPathToSavedPhotosAlbum(path, self, @selector(video:didFinishSavingWithError:contextInfo:), nil);
              self.selectInPhotos=NO;
          }
        self.vedioView.palyUrl=path;
       // NSData * data=[NSData dataWithContentsOfFile:path];
        
        self.backScrollView.contentOffset=CGPointMake(0, 160);
    }
        //关闭相册界面
        [picker dismissViewControllerAnimated:YES completion:nil];
        
        
    
}
- (void)video:(NSString *)videoPath didFinishSavingWithError:(NSError *)error contextInfo: (void *)contextInfo {
    
}
- (void)image: (UIImage *) image didFinishSavingWithError: (NSError *) error contextInfo: (void *) contextInfo
{
}

-(BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    self.xiangfaText.hidden=YES;
    return YES;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
