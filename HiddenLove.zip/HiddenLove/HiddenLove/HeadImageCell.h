//
//  HeadImageCell.h
//  HiddenLove
//
//  Created by mac on 15/3/16.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeadImageCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *backgroundImageView;
@property (strong, nonatomic) IBOutlet UIImageView *bigBlurImageView;
@property (strong, nonatomic) IBOutlet UIImageView *smallBlurImageView;
@property (strong, nonatomic) IBOutlet UIButton *headImageBtn;

@property (strong, nonatomic) IBOutlet UITextField *name;
@property (strong, nonatomic) IBOutlet UITextField *myTel;
@property (strong, nonatomic) IBOutlet UIImageView *mysexImageView;
-(void)setCellInfo:(NSDictionary *)dic;
@end
