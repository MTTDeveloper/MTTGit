//
//  MUser.h
//  HiddenLove
//
//  Created by mac on 15/3/15.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#define IPHONE_Version [[[UIDevice currentDevice] systemVersion] floatValue]
#define SCREEN_Width [UIScreen mainScreen].bounds.size.width
#define SCREEN_Height [UIScreen mainScreen].bounds.size.height
//#define phones @[@"134",@"135",@"136",@"137",@"138",@"139",@"150",@"151",@"152",@"157",@"158",@"159",@"182",@"187",@"188",@"130",@"131",@"132",@"156",@"185",@"186",@"133",@"153",@"180",@"189"]
@interface MUser : NSObject
+(UIColor *) hexStringToColor: (NSString *) stringToConvert;
+(void)alertViewShowTitle:(NSString *)title andMessage:(NSString *)mes andDelegate:(id)obj controltag:(NSInteger)ctag;
+ (UIImage *)fixOrientation:(UIImage *)aImage;
+(UIImage *)thumbnailWithImageWithoutScale:(UIImage *)image size:(CGSize)asize;
@end
