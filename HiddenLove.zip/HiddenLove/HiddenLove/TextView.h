//
//  TextView.h
//  HiddenLove
//
//  Created by mac on 15/3/31.
//  Copyright (c) 2015年 aaa. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FaceBoard.h"
@interface TextView : UITextView
@property (nonatomic, strong)FaceBoard *faceBoard;
-(NSString *)contentToString;

@end
