//
//  ViewController.m
//  Ch-10-01
//
//  Created by Ibokan on 15/9/18.
//  Copyright (c) 2015年 Ibokan. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UIImageView *imageView;
@end
@implementation ViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    NSMutableArray * imageArr = [NSMutableArray array];
    //找到图片，添加进数组
    for (int i = 1; i<=60; i++) {
        NSString * imageName = [NSString stringWithFormat:@"dropdown_anim__000%d@2x.png",i];
        UIImage * image = [UIImage imageNamed:imageName];
        [imageArr addObject:image];
    }
    //imageView要播放的图片数组
    self.imageView.animationImages = imageArr;
    //imageView播放图片数组的时长
    self.imageView.animationDuration = 5;
    //imageView播放图片数组的重复次数
    self.imageView.animationRepeatCount = 2;
}
- (IBAction)startAnimation:(id)sender
{
    [self.imageView startAnimating];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
