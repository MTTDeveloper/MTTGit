//
//  TrasitionViewController.m
//  Ch-10-01
//
//  Created by Ibokan on 15/9/18.
//  Copyright (c) 2015年 Ibokan. All rights reserved.
//

#import "TrasitionViewController.h"

@interface TrasitionViewController ()

@end

@implementation TrasitionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (IBAction)tapFlipFromLeft:(id)sender
{
    //开始一个叫flipleft的动画
    [UIView beginAnimations:@"flipleft" context:nil];
    //动画的持续时间
    [UIView setAnimationDuration:1.5];
    //设置动画的曲线
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    //设置动画的延迟x秒
    //[UIView setAnimationDelay:<#(NSTimeInterval)#>]
    //设置视图是否在开始和结束位置之间自动重复
    //[UIView setAnimationRepeatAutoreverses:YES];
    //设置动画重复次数
    //[UIView setAnimationRepeatCount:MAXFLOAT];
    //设置过渡动画的过渡效果
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self.view cache:YES];
    self.view.backgroundColor = [UIColor cyanColor];
    //完成上面设置的动画效果
    [UIView commitAnimations];
}
- (IBAction)tapFlipFromRight:(id)sender
{
    [UIView beginAnimations:@"flipright" context:nil];
    [UIView setAnimationDuration:1.5];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    [UIView setAnimationRepeatAutoreverses:YES];
    [UIView  setAnimationRepeatCount:1];
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:self.view cache:YES];
    [UIView commitAnimations];
}
- (IBAction)tapCurlUp:(id)sender
{
    [UIView beginAnimations:@"flipUp" context:nil];
    [UIView setAnimationDuration:1.5];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    [UIView setAnimationRepeatAutoreverses:YES];
    [UIView  setAnimationRepeatCount:1];
    [UIView setAnimationTransition:UIViewAnimationTransitionCurlUp forView:self.view cache:YES];
    [UIView commitAnimations];
}
- (IBAction)tapCurlDown:(id)sender
{
    [UIView beginAnimations:@"flipdown" context:nil];
    [UIView setAnimationDuration:1.5];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    [UIView setAnimationRepeatAutoreverses:YES];
    [UIView  setAnimationRepeatCount:1];
    [UIView setAnimationTransition:UIViewAnimationTransitionCurlDown forView:self.view cache:YES];
    [UIView commitAnimations];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
