//
//  ShoppingViewController.m
//  Ch-10-01
//
//  Created by Ibokan on 15/9/18.
//  Copyright (c) 2015年 Ibokan. All rights reserved.
//

#import "ShoppingViewController.h"

@interface ShoppingViewController ()
//商品
@property (strong, nonatomic) IBOutlet UIImageView *shangPin;
//加入购物车按钮
@property (strong, nonatomic) IBOutlet UIButton *button;
//购物车
@property (strong, nonatomic) IBOutlet UIImageView *shoppingCar;
@end
@implementation ShoppingViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (IBAction)tap:(id)sender
{
    [UIView beginAnimations:@"aaa" context:nil];
    //动画持续3秒
    [UIView setAnimationDuration:3];
    //设置回调方法
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(animationstop)];
    //设置动画曲线
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    //商品移动到购物城上方200X轴正中心
    self.shangPin.center = CGPointMake(self.shoppingCar.center.x, 200);
    //在动画过程中按钮透明度渐变成0
    self.button.alpha = 0;
    //完成设置
    [UIView commitAnimations];
    
}
//前一动画结束的回调（商品掉入购物车）
-(void)animationstop
{
    //初始化连接动画
    [UIView beginAnimations:@"bbb" context:nil];
    //持续时间
    [UIView setAnimationDuration:2];
    [UIView setAnimationRepeatCount:5];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDelegate:self];
    //两个中心重合  就把商品放入了购物车
    self.shangPin.center = self.shoppingCar.center;
    [UIView commitAnimations];
}
//设置掉入完成后的回调 购物车晃动
-(void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag
{
    [UIView beginAnimations:@"ccc" context:nil];
    [UIView setAnimationDuration:0.1];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(viewAnimationStop)];
    [UIView setAnimationRepeatAutoreverses:YES];
    //重复两次
    [UIView setAnimationRepeatCount:2];
    //晃动的角度
    self.shoppingCar.transform = CGAffineTransformMakeRotation(M_PI/8);
    [UIView commitAnimations];
}
-(void)viewAnimationStop
{
    self.shoppingCar.transform = CGAffineTransformMakeRotation(0);
    //所有动画结束后把购物车透明度变回1
    self.button.alpha = 1;
    NSLog(@"加入购物车成功");
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
