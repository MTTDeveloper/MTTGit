//
//  MyView.h
//  贝塞尔曲线
//
//  Created by 穆天泰 on 15/9/21.
//  Copyright (c) 2015年 穆天泰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyView : UIView

@end
