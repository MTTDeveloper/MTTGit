//
//  ViewController.m
//  贝塞尔曲线
//
//  Created by 穆天泰 on 15/9/21.
//  Copyright (c) 2015年 穆天泰. All rights reserved.
//

#import "ViewController.h"
#import "MyView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //View大小就是当前屏幕大小
    MyView *myView = [[MyView alloc]initWithFrame:self.view.bounds];
    //设置View背景颜色
    myView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:myView];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
