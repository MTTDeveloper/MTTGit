//
//  main.m
//  贝塞尔曲线
//
//  Created by 穆天泰 on 15/9/21.
//  Copyright (c) 2015年 穆天泰. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
