//
//  MyView.m
//  贝塞尔曲线
//
//  Created by 穆天泰 on 15/9/21.
//  Copyright (c) 2015年 穆天泰. All rights reserved.
//

#import "MyView.h"
@interface MyView()
@property(strong,nonatomic)NSMutableArray *lines;
@property(strong,nonatomic)NSMutableArray *points;
@end
@implementation MyView
//重写initWithFrame方法
-(instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame])
    {
        self.lines =[NSMutableArray array];
    }
    return self;
}
//感应开始点 一触摸就走这个方法
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    //每次开始都从新初始化一个点数组
    self.points=[NSMutableArray array];
    //获取当前触摸事件
    UITouch *touch = [touches anyObject];
    //获取当前触摸事件在屏幕上位置
    CGPoint point = [touch locationInView:self];
    //把point转成对象
    [self.points addObject:NSStringFromCGPoint(point)];
    //把点数组加入线数组
    [self.lines addObject:self.points];
    //自动调用drawRect渲染画图方法
    [self setNeedsDisplay];
}
//获取移动经过的点
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch =[touches anyObject];
    CGPoint point = [touch locationInView:self];
    [self.points addObject:NSStringFromCGPoint(point)];
    [self setNeedsDisplay];
}
//获取最后结束的点
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch =[touches anyObject];
    CGPoint point = [touch locationInView:self];
    [self.points addObject:NSStringFromCGPoint(point)];
    [self setNeedsDisplay];
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.

//渲染从开始到结束所经过的点所构成的线
- (void)drawRect:(CGRect)rect {
    UIBezierPath *bezierPath = [UIBezierPath bezierPath];
    //遍历线数组中的所有点
    for (NSArray *points in self.lines) {
        //开始点是点数组中的第一个对象
        CGPoint start =CGPointFromString(points.firstObject);
        //贝塞尔曲线渲染从开始点开始
        [bezierPath moveToPoint:start];
        //遍历移动所经过的所有点
        for (NSString *stringPoint in points) {
            //获取所经过 的点
            CGPoint point = CGPointFromString(stringPoint);
            //用贝塞尔曲线渲染连接所有经过的点
            [bezierPath addLineToPoint:point];
        }
        //设置贝塞尔曲线颜色
        UIColor *color = [UIColor grayColor];
        [color setStroke];
        ///贝塞尔曲线宽度
        [bezierPath  setLineWidth:5];
        [bezierPath stroke];
        
    }
    }

@end
