//
//  AppDelegate.h
//  ccccccccc
//
//  Created by Roberts on 15/10/26.
//  Copyright © 2015年 iBokan Wisdom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

