//
//  ViewController.m
//  ccccccccc
//
//  Created by Roberts on 15/10/26.
//  Copyright © 2015年 iBokan Wisdom. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate>

@property (strong, nonatomic) UIImagePickerController *picker;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.picker = [[UIImagePickerController alloc] init];
    self.picker.delegate = self;
    
    self.picker.allowsEditing = YES;
}

- (IBAction)tapBtn:(id)sender
{
    UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:@"获取资源路径" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍摄",@"从相册选取", nil];
    
    [sheet showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:
            // 拍摄
        {
            if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                
                NSArray *arr = [UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeCamera];
                self.picker.mediaTypes = arr;
                // 如果只有录视频，则设置mediaTypes
//                self.picker.mediaTypes = @[arr[1]];// 默认第一个是拍照片，第二个是视频
                
                self.picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                [self presentViewController:self.picker animated:YES completion:nil];
            }
            else
            {
                NSLog(@"模拟器不支持");
            }
            
            break;
        }
        case 1:
        {
            self.picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            [self presentViewController:self.picker animated:YES completion:nil];
            // 从相册选取
            break;
        }
            
        default:
            break;
    }
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    NSLog(@"info : %@",info);
    NSString *type = [info objectForKey:UIImagePickerControllerMediaType];
    NSLog(@"type = %@",type);// public.image
    // 选择了图片
    if ([type isEqualToString:@"public.image"])
    {
        // 保存图片到资源库
//        UIImageWriteToSavedPhotosAlbum(<#UIImage * _Nonnull image#>, <#id  _Nullable completionTarget#>, <#SEL  _Nullable completionSelector#>, <#void * _Nullable contextInfo#>)
    }
    // 视频
    else if ([type isEqualToString:@"public.movie"])
    {
        // 获取视频URL
        NSURL *url = [info objectForKey:UIImagePickerControllerMediaURL];
        NSString *path = url.path;
        // 保存视频到资源库
        UISaveVideoAtPathToSavedPhotosAlbum(path, nil, nil, nil);
    }

    [self dismissViewControllerAnimated:YES completion:nil];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
